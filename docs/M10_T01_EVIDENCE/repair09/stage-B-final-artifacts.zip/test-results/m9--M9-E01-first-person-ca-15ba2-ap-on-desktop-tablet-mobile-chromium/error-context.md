# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m9.spec.ts >> [M9-E01] first-person cards stay near player and center dealer without overlap on desktop tablet mobile
- Location: tests\browser\m9.spec.ts:8:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 900
Received:    908.703125
```

# Page snapshot

```yaml
- main [ref=e3]:
  - link "Skip to your hand and actions" [ref=e4] [cursor=pointer]:
    - /url: "#player-decisions"
  - generic [ref=e5]:
    - generic [ref=e6]:
      - paragraph [ref=e7]: An evening at the table
      - heading "Casino Blackjack" [level=1] [ref=e8]
    - paragraph [ref=e9]: Simulation credits only — no real-money gambling.Credits have no redemption value.
  - status [ref=e10]: Your turn
  - generic [ref=e11]:
    - region "Blackjack table" [ref=e12]:
      - region "Dealer" [ref=e13]:
        - heading "Dealer" [level=2] [ref=e14]
        - img "Original illustrated female dealer in professional attire" [ref=e15]
        - generic [ref=e46]:
          - img "4 of clubs" [ref=e48]:
            - generic [ref=e49]:
              - text: "4"
              - generic [aria-hidden] [ref=e50]: ♣
            - generic [aria-hidden] [ref=e51]: ♣
            - generic [aria-hidden] [ref=e52]: "4"
          - img "Hidden dealer card" [ref=e53]: ◆
          - paragraph [ref=e54]: "Visible total: 4"
          - paragraph [ref=e55]: Hole card hidden
      - paragraph [ref=e56]:
        - text: BLACKJACK PAYS 3:2
        - generic [ref=e57]: DEALER STANDS ON ALL 17
      - generic [ref=e58]:
        - region "Seat 1" [ref=e59]:
          - generic [ref=e60]:
            - 'img "Computer guest: Caelan, Male Elf" [ref=e61]'
            - generic [ref=e62]:
              - heading "Caelan" [level=2] [ref=e63]
              - paragraph [ref=e64]: Male Elf
              - paragraph [ref=e65]:
                - text: Seat 1 · Computer
                - generic [ref=e66]: "MAIN: 25 credits"
          - article "Hand A" [ref=e67]:
            - generic [ref=e68]:
              - img "J of hearts" [ref=e69]:
                - generic [ref=e70]:
                  - text: J
                  - generic [aria-hidden] [ref=e71]: ♥
                - generic [aria-hidden] [ref=e72]: ♥
                - generic [aria-hidden] [ref=e73]: J
              - img "5 of diamonds" [ref=e74]:
                - generic [ref=e75]:
                  - text: "5"
                  - generic [aria-hidden] [ref=e76]: ♦
                - generic [aria-hidden] [ref=e77]: ♦
                - generic [aria-hidden] [ref=e78]: "5"
              - img "2 of clubs" [ref=e79]:
                - generic [ref=e80]:
                  - text: "2"
                  - generic [aria-hidden] [ref=e81]: ♣
                - generic [aria-hidden] [ref=e82]: ♣
                - generic [aria-hidden] [ref=e83]: "2"
            - paragraph [ref=e84]: "Total: 17 · Wager: 25"
            - paragraph [ref=e85]: Decisions complete
        - region "Seat 3" [ref=e86]:
          - generic [ref=e87]:
            - 'img "Computer guest: Elaria, Female Elf" [ref=e88]'
            - generic [ref=e89]:
              - heading "Elaria" [level=2] [ref=e90]
              - paragraph [ref=e91]: Female Elf
              - paragraph [ref=e92]:
                - text: Seat 3 · Computer
                - generic [ref=e93]: "MAIN: 25 credits"
          - article "Hand A" [ref=e94]:
            - generic [ref=e95]:
              - img "A of hearts" [ref=e96]:
                - generic [ref=e97]:
                  - text: A
                  - generic [aria-hidden] [ref=e98]: ♥
                - generic [aria-hidden] [ref=e99]: ♥
                - generic [aria-hidden] [ref=e100]: A
              - img "8 of spades" [ref=e101]:
                - generic [ref=e102]:
                  - text: "8"
                  - generic [aria-hidden] [ref=e103]: ♠
                - generic [aria-hidden] [ref=e104]: ♠
                - generic [aria-hidden] [ref=e105]: "8"
            - paragraph [ref=e106]: "Total: 19 · Wager: 25"
            - paragraph [ref=e107]: Decisions complete
        - region "Seat 4" [active] [ref=e108]:
          - generic [ref=e109]:
            - 'img "Your avatar: Roland, Male Human Knight" [ref=e110]'
            - generic [ref=e111]:
              - heading "Roland" [level=2] [ref=e112]: ▸ Roland
              - paragraph [ref=e113]: Male Human Knight
              - paragraph [ref=e114]:
                - text: Seat 4 · You · Human
                - generic [ref=e115]: "MAIN: 100 credits"
          - article "Hand A" [ref=e116]:
            - generic [ref=e117]:
              - heading "Hand A · Current hand" [level=3] [ref=e118]
              - generic [ref=e119]: ACTIVE
            - generic [ref=e120]:
              - img "5 of hearts" [ref=e121]:
                - generic [ref=e122]:
                  - text: "5"
                  - generic [aria-hidden] [ref=e123]: ♥
                - generic [aria-hidden] [ref=e124]: ♥
                - generic [aria-hidden] [ref=e125]: "5"
              - img "4 of spades" [ref=e126]:
                - generic [ref=e127]:
                  - text: "4"
                  - generic [aria-hidden] [ref=e128]: ♠
                - generic [aria-hidden] [ref=e129]: ♠
                - generic [aria-hidden] [ref=e130]: "4"
            - paragraph [ref=e131]: "Total: 9 · Wager: 100"
            - paragraph [ref=e132]: Playing
        - region "Seat 6" [ref=e133]:
          - generic [ref=e134]:
            - 'img "Computer guest: Seraphine, Female Human Knight" [ref=e135]'
            - generic [ref=e136]:
              - heading "Seraphine" [level=2] [ref=e137]
              - paragraph [ref=e138]: Female Human Knight
              - paragraph [ref=e139]:
                - text: Seat 6 · Computer
                - generic [ref=e140]: "MAIN: 25 credits"
          - article "Hand A" [ref=e141]:
            - generic [ref=e142]:
              - img "9 of hearts" [ref=e143]:
                - generic [ref=e144]:
                  - text: "9"
                  - generic [aria-hidden] [ref=e145]: ♥
                - generic [aria-hidden] [ref=e146]: ♥
                - generic [aria-hidden] [ref=e147]: "9"
              - img "6 of diamonds" [ref=e148]:
                - generic [ref=e149]:
                  - text: "6"
                  - generic [aria-hidden] [ref=e150]: ♦
                - generic [aria-hidden] [ref=e151]: ♦
                - generic [aria-hidden] [ref=e152]: "6"
            - paragraph [ref=e153]: "Total: 15 · Wager: 25"
            - paragraph [ref=e154]: Playing
    - generic [ref=e155]:
      - region "Primary actions" [ref=e156]:
        - generic [ref=e157]:
          - button "Hit" [ref=e158] [cursor=pointer]
          - button "Stand" [ref=e159] [cursor=pointer]
          - button "Double" [ref=e160] [cursor=pointer]
          - button "Split" [disabled] [ref=e161]
          - button "Surrender" [ref=e162] [cursor=pointer]
        - group [ref=e163]:
          - generic "Action guidance · Unavailable actions explained" [ref=e164] [cursor=pointer]
      - region "Your credits" [ref=e165]:
        - heading "Your simulation credits" [level=2] [ref=e166]
        - generic [ref=e167]:
          - generic [ref=e168]:
            - term [ref=e169]: Available
            - definition [ref=e170]: "900"
          - generic [ref=e171]:
            - term [ref=e172]: Reserved / current exposure
            - definition [ref=e173]: "100"
          - generic [ref=e174]:
            - term [ref=e175]: Pending return
            - definition [ref=e176]: "0"
  - paragraph [ref=e177]: Existing 6-deck shoe continues · Computer guests play with their own simulation credits.
  - group [ref=e178]:
    - generic "Change Character · Roland" [ref=e179] [cursor=pointer]
    - option "Caelan · Male Elf"
    - option "Elaria · Female Elf"
    - option "Roland · Male Human Knight" [selected]
    - option "Seraphine · Female Human Knight"
    - option "Alaric · Male Mage"
    - option "Nyra · Female Mage"
    - option "Lucien · Male Noble"
    - option "Celestine · Female Noble"
    - option "Garruk · Male Half-Orc Warrior"
    - option "Vesha · Female Half-Orc Warrior"
    - option "Borin · Male Dwarf"
    - option "Brynja · Female Dwarf"
  - group [ref=e180]:
    - generic "Developer / demo tools" [ref=e181] [cursor=pointer]
    - option "Classic Blackjack" [selected]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | async function deal(page: import('@playwright/test').Page) {
  4   |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  5   |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  6   | }
  7   | 
  8   | test('[M9-E01] first-person cards stay near player and center dealer without overlap on desktop tablet mobile', async ({ page }, info) => {
  9   |   for (const viewport of [{ width: 1280, height: 900 }, { width: 768, height: 1024 }, { width: 320, height: 720 }]) {
  10  |     await page.setViewportSize(viewport); await page.goto('/?fixture=player'); await deal(page);
  11  |     await page.evaluate(() => scrollTo(0, 0));
  12  |     const dealer = await page.getByRole('region', { name: 'Dealer', exact: true }).boundingBox();
  13  |     const local = page.getByRole('region', { name: 'Seat 4', exact: true });
  14  |     const own = await local.boundingBox();
  15  |     expect(dealer).not.toBeNull(); expect(own).not.toBeNull();
  16  |     expect(dealer!.y).toBeGreaterThanOrEqual(0);
  17  |     expect(Math.abs(dealer!.x + dealer!.width / 2 - viewport.width / 2)).toBeLessThan(2);
  18  |     expect(own!.y).toBeGreaterThan(dealer!.y + dealer!.height);
  19  |     for (const seat of [1, 3, 6]) {
  20  |       const guest = await page.getByRole('region', { name: `Seat ${seat}`, exact: true }).boundingBox();
  21  |       expect(guest!.y + guest!.height).toBeLessThanOrEqual(own!.y);
  22  |     }
  23  |     const ownCard = await local.locator('.card').first().boundingBox();
  24  |     const guestCard = viewport.width === 320 ? await page.getByRole('region', { name: 'Dealer', exact: true }).locator('.card').first().boundingBox()
  25  |       : await page.getByRole('region', { name: 'Seat 1', exact: true }).locator('.guest-desktop-hand .card').first().boundingBox();
  26  |     expect(ownCard!.width).toBeGreaterThan(guestCard!.width);
  27  |     const title = await local.locator('h3').boundingBox(); const active = await local.locator('.turn-marker').boundingBox();
  28  |     expect(title!.y + title!.height <= active!.y || title!.x + title!.width <= active!.x).toBe(true);
  29  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  30  |     await expect(page.getByRole('button', { name: 'Stand', exact: true })).toBeEnabled();
  31  |     const action = await page.getByRole('button', { name: 'Stand', exact: true }).boundingBox();
  32  |     console.log(JSON.stringify({ viewport, dealer, own, action }));
> 33  |     if (viewport.width === 1280) expect(action!.y + action!.height).toBeLessThanOrEqual(900);
      |                                                                     ^ Error: expect(received).toBeLessThanOrEqual(expected)
  34  |     await page.screenshot({ path: info.outputPath(`table-${viewport.width}.png`), fullPage: true, animations: 'disabled' });
  35  |     await page.screenshot({ path: `docs/images/m9-table-${viewport.width}.png`, fullPage: true, animations: 'disabled' });
  36  |   }
  37  | });
  38  | 
  39  | test('[M9-E02] original characters and compact mobile public guest cards retain reduced motion and secrecy', async ({ page }) => {
  40  |   await page.setViewportSize({ width: 320, height: 720 }); await page.emulateMedia({ reducedMotion: 'reduce' });
  41  |   await page.goto('/?fixture=player');
  42  |   await expect(page.getByRole('img', { name: 'Original illustrated female dealer in professional attire', exact: true })).toBeVisible();
  43  |   await expect(page.getByRole('img', { name: /^Computer guest: / })).toHaveCount(3);
  44  |   await deal(page); await page.evaluate(() => scrollTo(0, 0));
  45  |   const guest = page.getByRole('region', { name: 'Seat 1', exact: true });
  46  |   await expect(guest.locator('.guest-mobile-cards')).not.toHaveAttribute('open', '');
  47  |   await guest.getByText('Cards · 17', { exact: true }).click();
  48  |   await expect(guest.getByRole('img', { name: 'J of hearts', exact: true })).toBeVisible();
  49  |   await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toBeVisible();
  50  |   expect(await page.locator('.local .card').first().evaluate(e => getComputedStyle(e).animationName)).toBe('none');
  51  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  52  | });
  53  | 
  54  | test('[M9-E03] own wager deals once, auto settles, repeats original amount and opens fresh betting', async ({ page }) => {
  55  |   await page.goto('/?fixture=player');
  56  |   await expect(page.getByLabel('Computer MAIN at Seat 1', { exact: true })).toHaveCount(0);
  57  |   await expect(page.getByRole('button', { name: 'Open betting', exact: true })).toHaveCount(0);
  58  |   await deal(page); await expect(page.locator('#player-hand')).toBeFocused();
  59  |   await expect(page.getByRole('button', { name: 'Continue table', exact: true })).toHaveCount(0);
  60  |   await page.getByRole('button', { name: 'Double', exact: true }).click();
  61  |   await expect(page.getByRole('region', { name: 'Your round result', exact: true })).toBeVisible();
  62  |   await expect(page.locator('#player-result')).toBeFocused();
  63  |   await page.screenshot({ path: 'docs/images/m9-results.png', fullPage: true, animations: 'disabled' });
  64  |   await page.getByText('Wager result details', { exact: true }).click();
  65  |   await expect(page.getByText(/Stake: 200 · Returned:/)).toBeVisible();
  66  |   await page.getByRole('button', { name: 'Repeat Bet · 100 credits', exact: true }).click();
  67  |   await expect(page.getByRole('region', { name: 'Seat 4', exact: true }).getByText('MAIN: 100 credits', { exact: true })).toBeVisible();
  68  |   // A subsequent random-seeded round may pause on Insurance, never on a computer.
  69  |   if (await page.getByRole('button', { name: 'Decline', exact: true }).isVisible()) await page.getByRole('button', { name: 'Decline', exact: true }).click();
  70  |   if (await page.getByRole('button', { name: 'Stand', exact: true }).isVisible()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  71  |   await page.getByRole('button', { name: 'Deal Again', exact: true }).click();
  72  |   await expect(page.getByLabel('Your main wager', { exact: false })).toHaveValue('100');
  73  |   await expect(page.getByLabel('Your main wager', { exact: false })).toBeFocused();
  74  |   await expect(page.getByRole('button', { name: 'Deal', exact: true })).toBeEnabled();
  75  |   await expect(page.getByRole('region', { name: 'Seat 4', exact: true }).getByText('Your cards will be dealt here.', { exact: true })).toBeVisible();
  76  | });
  77  | 
  78  | test('[M9-E04] tools start collapsed and seeded replay audit remain deliberately reachable', async ({ page }) => {
  79  |   await page.goto('/?fixture=player');
  80  |   const tools = page.locator('.developer-tools'); await expect(tools).not.toHaveAttribute('open', '');
  81  |   await expect(page.getByRole('region', { name: 'Demo and audit tools', exact: true })).toBeHidden();
  82  |   await tools.locator(':scope > summary').focus(); await page.keyboard.press('Enter');
  83  |   await expect(tools).toHaveAttribute('open', '');
  84  |   await page.getByText('Advanced demo settings', { exact: true }).click();
  85  |   await page.getByLabel('Optional reproducible demo seed', { exact: true }).fill('7');
  86  |   await page.getByRole('button', { name: 'Start new demo session', exact: true }).click();
  87  |   await deal(page);
  88  |   await expect(page.getByRole('button', { name: 'Open manual demo (resets credits)', exact: true })).toBeDisabled();
  89  |   await expect(page.getByLabel('Optional reproducible demo seed', { exact: true })).toHaveCount(0);
  90  |   await page.getByRole('button', { name: 'Stand', exact: true }).click();
  91  |   await page.getByRole('button', { name: 'View replay package', exact: true }).click();
  92  |   const p = JSON.parse(await page.getByLabel('Completed replay JSON', { exact: true }).inputValue());
  93  |   expect(p.configuration.seed).toBe(7); expect(p.commands.at(-1).command.type).toBe('SETTLE');
  94  |   await page.getByRole('button', { name: 'Replay completed session', exact: true }).click();
  95  |   await expect(page.getByRole('region', { name: 'Replay result', exact: true })).toContainText('Original table results are preserved.');
  96  |   await page.getByText(/Public audit history \(/).click();
  97  |   await expect(page.locator('.audit-list')).toContainText('computer-1');
  98  |   await expect(page.locator('.audit-list')).toContainText('local-human');
  99  |   await expect(page.locator('.audit-list')).not.toContainText('deckIndex');
  100 |   await page.getByRole('button', { name: 'Hide replay package', exact: true }).click();
  101 |   await page.getByRole('region', { name: 'Demo and audit tools', exact: true }).screenshot({ path: 'docs/images/m9-tools.png', animations: 'disabled' });
  102 | });
  103 | 
  104 | test('[M9-E05] deliberate manual demo keeps configuration and explicit progress, then returns to player table', async ({ page }) => {
  105 |   await page.goto('/?fixture=player'); await page.getByText('Developer / demo tools', { exact: true }).click();
  106 |   await page.getByRole('button', { name: 'Open manual demo (resets credits)', exact: true }).click();
  107 |   await expect(page.getByRole('region', { name: 'Table setup', exact: true })).toBeVisible();
  108 |   await page.getByRole('button', { name: 'Return to Player Mode (resets credits)', exact: true }).click();
  109 |   await expect(page.locator('.player-mode')).toBeVisible(); await expect(page.locator('.developer-tools')).not.toHaveAttribute('open', '');
  110 |   await expect(page.getByRole('button', { name: 'Deal', exact: true })).toBeVisible();
  111 |   await expect(page.getByRole('region', { name: 'Seat 3', exact: true })).toContainText('MAIN: 25 credits');
  112 | });
  113 | 
  114 | test('[M9-E06] keyboard can wager, reach visible focus, stand and start another round without computer friction', async ({ page }) => {
  115 |   await page.goto('/?fixture=player');
  116 |   await page.keyboard.press('Tab'); await expect(page.getByRole('link', { name: 'Skip to your hand and actions' })).toBeFocused();
  117 |   await page.keyboard.press('Enter'); await expect(page.locator('#player-decisions')).toBeFocused();
  118 |   await page.keyboard.press('Tab'); await expect(page.getByLabel('Your main wager', { exact: false })).toBeFocused();
  119 |   await page.keyboard.press('Control+A'); await page.keyboard.type('100'); await page.keyboard.press('Enter');
  120 |   await expect(page.locator('#player-hand')).toBeFocused();
  121 |   await page.keyboard.press('Tab'); await page.keyboard.press('Tab');
  122 |   await expect(page.getByRole('button', { name: 'Stand', exact: true })).toBeFocused();
  123 |   expect(await page.getByRole('button', { name: 'Stand', exact: true }).evaluate(el => getComputedStyle(el).outlineStyle)).toBe('solid');
  124 |   await page.keyboard.press('Enter'); await expect(page.locator('#player-result')).toBeFocused();
  125 |   await page.keyboard.press('Tab'); await expect(page.getByRole('button', { name: 'Deal Again', exact: true })).toBeFocused();
  126 |   await page.keyboard.press('Enter'); await expect(page.getByLabel('Your main wager', { exact: false })).toBeFocused();
  127 | });
  128 | 
  129 | test('[M9-E07] unconfigured default opens player table and own betting with closed secondary tools', async ({ page }) => {
  130 |   await page.goto('/'); await expect(page.locator('.player-mode')).toBeVisible();
  131 |   await expect(page.getByRole('region', { name: 'Table setup', exact: true })).toHaveCount(0);
  132 |   await expect(page.getByRole('img', { name: /^Computer guest: / })).toHaveCount(3);
  133 |   await expect(page.locator('.developer-tools')).not.toHaveAttribute('open', '');
```