# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m10.spec.ts >> [M10-E01] current casino table anchors retain public players and usable controls at three viewports
- Location: tests\browser\m10.spec.ts:34:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 900
Received:    908.703125
```

# Page snapshot

```yaml
- main [ref=e3]:
  - link "Skip to your hand and actions" [ref=e4] [cursor=pointer]:
    - /url: "#player-decisions"
  - generic [ref=e5]:
    - generic [ref=e6]:
      - paragraph [ref=e7]: An evening at the table
      - heading "Casino Blackjack" [level=1] [ref=e8]
    - paragraph [ref=e9]: Simulation credits only — no real-money gambling.Credits have no redemption value.
  - status [ref=e10]: Your turn
  - generic [ref=e11]:
    - region "Blackjack table" [ref=e12]:
      - region "Dealer" [ref=e13]:
        - heading "Dealer" [level=2] [ref=e14]
        - img "Original illustrated female dealer in professional attire" [ref=e15]
        - generic [ref=e46]:
          - img "4 of clubs" [ref=e48]:
            - generic [ref=e49]:
              - text: "4"
              - generic [aria-hidden] [ref=e50]: ♣
            - generic [aria-hidden] [ref=e51]: ♣
            - generic [aria-hidden] [ref=e52]: "4"
          - img "Hidden dealer card" [ref=e53]: ◆
          - paragraph [ref=e54]: "Visible total: 4"
          - paragraph [ref=e55]: Hole card hidden
      - paragraph [ref=e56]:
        - text: BLACKJACK PAYS 3:2
        - generic [ref=e57]: DEALER STANDS ON ALL 17
      - generic [ref=e58]:
        - region "Seat 1" [ref=e59]:
          - generic [ref=e60]:
            - 'img "Computer guest: Caelan, Male Elf" [ref=e61]'
            - generic [ref=e62]:
              - heading "Caelan" [level=2] [ref=e63]
              - paragraph [ref=e64]: Male Elf
              - paragraph [ref=e65]:
                - text: Seat 1 · Computer
                - generic [ref=e66]: "MAIN: 25 credits"
          - article "Hand A" [ref=e67]:
            - generic [ref=e68]:
              - img "J of hearts" [ref=e69]:
                - generic [ref=e70]:
                  - text: J
                  - generic [aria-hidden] [ref=e71]: ♥
                - generic [aria-hidden] [ref=e72]: ♥
                - generic [aria-hidden] [ref=e73]: J
              - img "5 of diamonds" [ref=e74]:
                - generic [ref=e75]:
                  - text: "5"
                  - generic [aria-hidden] [ref=e76]: ♦
                - generic [aria-hidden] [ref=e77]: ♦
                - generic [aria-hidden] [ref=e78]: "5"
              - img "2 of clubs" [ref=e79]:
                - generic [ref=e80]:
                  - text: "2"
                  - generic [aria-hidden] [ref=e81]: ♣
                - generic [aria-hidden] [ref=e82]: ♣
                - generic [aria-hidden] [ref=e83]: "2"
            - paragraph [ref=e84]: "Total: 17 · Wager: 25"
            - paragraph [ref=e85]: Decisions complete
        - region "Seat 3" [ref=e86]:
          - generic [ref=e87]:
            - 'img "Computer guest: Elaria, Female Elf" [ref=e88]'
            - generic [ref=e89]:
              - heading "Elaria" [level=2] [ref=e90]
              - paragraph [ref=e91]: Female Elf
              - paragraph [ref=e92]:
                - text: Seat 3 · Computer
                - generic [ref=e93]: "MAIN: 25 credits"
          - article "Hand A" [ref=e94]:
            - generic [ref=e95]:
              - img "A of hearts" [ref=e96]:
                - generic [ref=e97]:
                  - text: A
                  - generic [aria-hidden] [ref=e98]: ♥
                - generic [aria-hidden] [ref=e99]: ♥
                - generic [aria-hidden] [ref=e100]: A
              - img "8 of spades" [ref=e101]:
                - generic [ref=e102]:
                  - text: "8"
                  - generic [aria-hidden] [ref=e103]: ♠
                - generic [aria-hidden] [ref=e104]: ♠
                - generic [aria-hidden] [ref=e105]: "8"
            - paragraph [ref=e106]: "Total: 19 · Wager: 25"
            - paragraph [ref=e107]: Decisions complete
        - region "Seat 4" [active] [ref=e108]:
          - generic [ref=e109]:
            - 'img "Your avatar: Roland, Male Human Knight" [ref=e110]'
            - generic [ref=e111]:
              - heading "Roland" [level=2] [ref=e112]: ▸ Roland
              - paragraph [ref=e113]: Male Human Knight
              - paragraph [ref=e114]:
                - text: Seat 4 · You · Human
                - generic [ref=e115]: "MAIN: 100 credits"
          - article "Hand A" [ref=e116]:
            - generic [ref=e117]:
              - heading "Hand A · Current hand" [level=3] [ref=e118]
              - generic [ref=e119]: ACTIVE
            - generic [ref=e120]:
              - img "5 of hearts" [ref=e121]:
                - generic [ref=e122]:
                  - text: "5"
                  - generic [aria-hidden] [ref=e123]: ♥
                - generic [aria-hidden] [ref=e124]: ♥
                - generic [aria-hidden] [ref=e125]: "5"
              - img "4 of spades" [ref=e126]:
                - generic [ref=e127]:
                  - text: "4"
                  - generic [aria-hidden] [ref=e128]: ♠
                - generic [aria-hidden] [ref=e129]: ♠
                - generic [aria-hidden] [ref=e130]: "4"
            - paragraph [ref=e131]: "Total: 9 · Wager: 100"
            - paragraph [ref=e132]: Playing
        - region "Seat 6" [ref=e133]:
          - generic [ref=e134]:
            - 'img "Computer guest: Seraphine, Female Human Knight" [ref=e135]'
            - generic [ref=e136]:
              - heading "Seraphine" [level=2] [ref=e137]
              - paragraph [ref=e138]: Female Human Knight
              - paragraph [ref=e139]:
                - text: Seat 6 · Computer
                - generic [ref=e140]: "MAIN: 25 credits"
          - article "Hand A" [ref=e141]:
            - generic [ref=e142]:
              - img "9 of hearts" [ref=e143]:
                - generic [ref=e144]:
                  - text: "9"
                  - generic [aria-hidden] [ref=e145]: ♥
                - generic [aria-hidden] [ref=e146]: ♥
                - generic [aria-hidden] [ref=e147]: "9"
              - img "6 of diamonds" [ref=e148]:
                - generic [ref=e149]:
                  - text: "6"
                  - generic [aria-hidden] [ref=e150]: ♦
                - generic [aria-hidden] [ref=e151]: ♦
                - generic [aria-hidden] [ref=e152]: "6"
            - paragraph [ref=e153]: "Total: 15 · Wager: 25"
            - paragraph [ref=e154]: Playing
    - generic [ref=e155]:
      - region "Primary actions" [ref=e156]:
        - generic [ref=e157]:
          - button "Hit" [ref=e158] [cursor=pointer]
          - button "Stand" [ref=e159] [cursor=pointer]
          - button "Double" [ref=e160] [cursor=pointer]
          - button "Split" [disabled] [ref=e161]
          - button "Surrender" [ref=e162] [cursor=pointer]
        - group [ref=e163]:
          - generic "Action guidance · Unavailable actions explained" [ref=e164] [cursor=pointer]
      - region "Your credits" [ref=e165]:
        - heading "Your simulation credits" [level=2] [ref=e166]
        - generic [ref=e167]:
          - generic [ref=e168]:
            - term [ref=e169]: Available
            - definition [ref=e170]: "900"
          - generic [ref=e171]:
            - term [ref=e172]: Reserved / current exposure
            - definition [ref=e173]: "100"
          - generic [ref=e174]:
            - term [ref=e175]: Pending return
            - definition [ref=e176]: "0"
  - paragraph [ref=e177]: Existing 6-deck shoe continues · Computer guests play with their own simulation credits.
  - group [ref=e178]:
    - generic "Change Character · Roland" [ref=e179] [cursor=pointer]
    - option "Caelan · Male Elf"
    - option "Elaria · Female Elf"
    - option "Roland · Male Human Knight" [selected]
    - option "Seraphine · Female Human Knight"
    - option "Alaric · Male Mage"
    - option "Nyra · Female Mage"
    - option "Lucien · Male Noble"
    - option "Celestine · Female Noble"
    - option "Garruk · Male Half-Orc Warrior"
    - option "Vesha · Female Half-Orc Warrior"
    - option "Borin · Male Dwarf"
    - option "Brynja · Female Dwarf"
  - group [ref=e180]:
    - generic "Developer / demo tools" [ref=e181] [cursor=pointer]
    - option "Classic Blackjack" [selected]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { copyFileSync, writeFileSync } from 'node:fs';
  3   | 
  4   | const viewports = [{ width: 1280, height: 900 }, { width: 768, height: 1024 }, { width: 320, height: 720 }];
  5   | async function deal(page: Page, fixture = 'player') {
  6   |   await page.goto(`/?fixture=${fixture}`);
  7   |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  8   |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  9   | }
  10  | async function geometry(page: Page) {
  11  |   const data = await page.locator('.casino-table').evaluate(table => {
  12  |     const rect = (el: Element) => { const r = el.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height }; };
  13  |     const anchors = [...table.querySelectorAll('.dealer, .seat')].map(el => ({ label: el.getAttribute('aria-label'), ...rect(el) }));
  14  |     return { table: rect(table), anchors, viewport: { width: innerWidth, height: innerHeight }, scrollWidth: document.documentElement.scrollWidth };
  15  |   });
  16  |   expect(data.scrollWidth).toBeLessThanOrEqual(data.viewport.width);
  17  |   const dealer = data.anchors[0];
  18  |   expect(Math.abs(dealer.x + dealer.width / 2 - data.viewport.width / 2)).toBeLessThan(2);
  19  |   for (let i = 0; i < data.anchors.length; i++) {
  20  |     const a = data.anchors[i];
  21  |     expect(a.x, a.label!).toBeGreaterThanOrEqual(data.table.x);
  22  |     expect(a.x + a.width, a.label!).toBeLessThanOrEqual(data.table.x + data.table.width);
  23  |     for (const b of data.anchors.slice(i + 1)) {
  24  |       expect(a.x + a.width <= b.x + 1 || b.x + b.width <= a.x + 1 || a.y + a.height <= b.y + 1 || b.y + b.height <= a.y + 1,
  25  |         `${a.label} intersects ${b.label}`).toBe(true);
  26  |     }
  27  |   }
  28  |   for (const cards of await page.locator('.seat article .cards:visible').all()) {
  29  |     expect(await cards.evaluate(el => el.scrollWidth <= el.clientWidth)).toBe(true);
  30  |   }
  31  |   return data;
  32  | }
  33  | 
  34  | test('[M10-E01] current casino table anchors retain public players and usable controls at three viewports', async ({ page }) => {
  35  |   const receipts = [];
  36  |   for (const viewport of viewports) {
  37  |     await page.setViewportSize(viewport); await deal(page); await page.evaluate(() => scrollTo(0, 0));
  38  |     await expect(page.locator('[data-anchor="dealer-cards"]')).toBeVisible();
  39  |     await expect(page.locator('[data-anchor="table-centre"]')).toBeVisible();
  40  |     expect(await page.locator('[data-seat-anchor]').evaluateAll(els => els.map(el => el.getAttribute('data-seat-anchor')))).toEqual(['seat-1','seat-3','seat-4','seat-6']);
  41  |     await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toBeVisible();
  42  |     receipts.push(await geometry(page));
  43  |     for (const name of ['Hit','Stand','Double','Split','Surrender']) {
  44  |       const button = page.getByRole('button', { name, exact: true });
  45  |       const box = (await button.boundingBox())!;
  46  |       expect(box.width).toBeGreaterThanOrEqual(44); expect(box.height).toBeGreaterThanOrEqual(44);
  47  |     }
  48  |     const stand = page.getByRole('button', { name: 'Stand', exact: true });
> 49  |     if (viewport.width === 1280) { const box = (await stand.boundingBox())!; expect(box.y + box.height).toBeLessThanOrEqual(900); }
      |                                                                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  50  |     await page.screenshot({ path: `docs/M10_T01_EVIDENCE/table-${viewport.width}.png`, fullPage: true, animations: 'disabled' });
  51  |     await stand.click(); await expect(page.locator('#player-result')).toBeFocused();
  52  |     await page.getByRole('button', { name: 'Deal Again', exact: true }).click();
  53  |     await expect(page.getByLabel('Your main wager', { exact: false })).toBeFocused();
  54  |   }
  55  |   writeFileSync('docs/M10_T01_EVIDENCE/geometry.json', JSON.stringify(receipts, null, 2) + '\n');
  56  | });
  57  | 
  58  | test('[M10-E02] five actual cards and four actual split leaves use vertical flow without overlapping seat regions', async ({ page }) => {
  59  |   for (const viewport of viewports) {
  60  |     await page.setViewportSize(viewport); await deal(page, 'player-five');
  61  |     for (let i = 0; i < 3; i++) await page.getByRole('button', { name: 'Hit', exact: true }).click();
  62  |     await expect(page.locator('#player-hand article .card')).toHaveCount(5); await geometry(page);
  63  |     await page.screenshot({ path: `docs/M10_T01_EVIDENCE/five-cards-${viewport.width}.png`, fullPage: true, animations: 'disabled' });
  64  |     await page.getByRole('button', { name: 'Stand', exact: true }).click(); await expect(page.locator('#player-result')).toBeFocused();
  65  |     await deal(page, 'player-rsa-cap');
  66  |     for (let i = 0; i < 3; i++) await page.getByRole('button', { name: 'Split', exact: true }).click();
  67  |     await expect(page.locator('#player-hand article')).toHaveCount(4); await geometry(page);
  68  |     const ids = await page.locator('#player-hand article').evaluateAll(els => els.map(el => el.getAttribute('data-hand-id')));
  69  |     expect(new Set(ids).size).toBe(4);
  70  |     await page.screenshot({ path: `docs/M10_T01_EVIDENCE/four-leaves-${viewport.width}.png`, fullPage: true, animations: 'disabled' });
  71  |     await expect(page.getByRole('button', { name: 'Deal Again', exact: true })).toBeEnabled();
  72  |   }
  73  | });
  74  | 
  75  | test('[M10-E03] enlarged text failed portraits and reduced motion keep identity cards and keyboard decisions accessible', async ({ page }) => {
  76  |   await page.emulateMedia({ reducedMotion: 'reduce' });
  77  |   await page.route('**/characters/*.png', route => route.abort());
  78  |   for (const viewport of viewports) {
  79  |     await page.setViewportSize(viewport); await deal(page);
  80  |     await page.addStyleTag({ content: 'html { font-size: 200%; }' });
  81  |     await expect(page.locator('#player-hand').getByRole('heading', { name: 'Roland', exact: true })).toBeVisible();
  82  |     await expect(page.locator('#player-hand .character-identity img')).toHaveJSProperty('naturalWidth', 0);
  83  |     await geometry(page);
  84  |     if (viewport.width === 320) {
  85  |       const guest = page.getByRole('region', { name: 'Seat 1', exact: true });
  86  |       await guest.locator('summary').click();
  87  |       await expect(guest.locator('.guest-mobile-cards .card').first()).toBeVisible(); await geometry(page);
  88  |     }
  89  |     await page.screenshot({ path: `docs/M10_T01_EVIDENCE/text-fallback-${viewport.width}.png`, fullPage: true, animations: 'disabled' });
  90  |     await page.locator('#player-hand').focus();
  91  |     const stand = page.getByRole('button', { name: 'Stand', exact: true });
  92  |     for (let i = 0; i < 8 && !await stand.evaluate(el => el === document.activeElement); i++) await page.keyboard.press('Tab');
  93  |     await expect(stand).toBeFocused();
  94  |     expect(await stand.evaluate(el => getComputedStyle(el).outlineStyle)).toBe('solid');
  95  |     expect(await page.locator('#player-hand .card').first().evaluate(el => getComputedStyle(el).animationName)).toBe('none');
  96  |     await page.keyboard.press('Enter'); await expect(page.locator('#player-result')).toBeFocused();
  97  |   }
  98  | });
  99  | 
  100 | test('[M10-E04] the table scene owns coherent local cards controls and exact credits through betting and play', async ({ page }, info) => {
  101 |   for (const viewport of viewports) {
  102 |     await page.setViewportSize(viewport); await page.goto('/?fixture=player');
  103 |     const scene = page.locator('.table-scene');
  104 |     await expect(scene.getByRole('region', { name: 'Your wager', exact: true })).toBeVisible();
  105 |     const save = async (state: string) => {
  106 |       const filename = `scene-${state}-${viewport.width}.png`, path = info.outputPath(filename);
  107 |       await page.screenshot({ path, fullPage: true, animations: 'disabled' });
  108 |       copyFileSync(path, `docs/M10_T01_EVIDENCE/repair09/${filename}`);
  109 |     };
  110 |     await page.evaluate(() => scrollTo(0, 0)); await save('open');
  111 |     await page.getByLabel('Your main wager', { exact: false }).fill('100');
  112 |     await scene.getByRole('button', { name: 'Deal', exact: true }).click();
  113 |     const own = scene.getByRole('region', { name: 'Seat 4', exact: true });
  114 |     await expect(own.getByRole('img', { name: 'Your avatar: Roland, Male Human Knight', exact: true })).toBeVisible();
  115 |     await expect(own.getByRole('img', { name: '5 of hearts', exact: true })).toBeVisible();
  116 |     await expect(own.getByRole('img', { name: '4 of spades', exact: true })).toBeVisible();
  117 |     await expect(own.getByText('MAIN: 100 credits', { exact: true })).toBeVisible();
  118 |     await expect(scene.getByRole('region', { name: 'Your credits', exact: true }).locator('dd')).toHaveText(['900', '100', '0']);
  119 |     const positions = await scene.evaluate(el => {
  120 |       const rect = (selector: string) => { const r = el.querySelector(selector)!.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height }; };
  121 |       return { own: rect('#player-hand'), dock: rect('.player-dock'), table: rect('.casino-table') };
  122 |     });
  123 |     expect(Math.abs(positions.own.x + positions.own.width / 2 - viewport.width / 2)).toBeLessThan(2);
  124 |     expect(Math.abs(positions.dock.x + positions.dock.width / 2 - viewport.width / 2)).toBeLessThan(2);
  125 |     expect(positions.dock.y).toBeGreaterThanOrEqual(positions.own.y + positions.own.height);
  126 |     expect(positions.dock.y - positions.own.y - positions.own.height).toBeLessThanOrEqual(32);
  127 |     expect(positions.table.width).toBeGreaterThan(viewport.width * 0.8);
  128 |     await expect(scene.getByRole('region', { name: 'House rules', exact: true })).toHaveCount(0);
  129 |     await expect(scene.getByLabel('House rules', { exact: true })).toContainText('BLACKJACK PAYS 3:2');
  130 |     await expect(scene.getByLabel('House rules', { exact: true })).toContainText('DEALER STANDS ON ALL 17');
  131 |     expect(await scene.locator('.dealer > .casino-person').evaluate(el => getComputedStyle(el).animationName)).toBe('none');
  132 |     await geometry(page); await page.evaluate(() => scrollTo(0, 0)); await save('dealt');
  133 |     await scene.getByRole('button', { name: 'Stand', exact: true }).click();
  134 |     await expect(scene.locator('#player-result')).toBeFocused();
  135 |     await scene.getByRole('button', { name: 'Deal Again', exact: true }).click();
  136 |     await expect(scene.getByLabel('Your main wager', { exact: false })).toBeFocused();
  137 |   }
  138 | });
  139 | 
```