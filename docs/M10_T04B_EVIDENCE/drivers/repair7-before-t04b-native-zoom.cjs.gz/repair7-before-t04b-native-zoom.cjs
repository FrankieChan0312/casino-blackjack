const {chromium,expect}=require('@playwright/test'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const dir=path.resolve('docs/M10_T04B_EVIDENCE/visuals'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'cbg-m10a-t01-human-zoom-')),extension=path.join(temp,'extension');fs.mkdirSync(extension);
fs.writeFileSync(path.join(extension,'manifest.json'),JSON.stringify({manifest_version:3,name:'Local Blackjack actual zoom verification',version:'1.0',host_permissions:['http://127.0.0.1/*'],background:{service_worker:'background.js'}}));
fs.writeFileSync(path.join(extension,'background.js'),'chrome.runtime.onInstalled.addListener(() => {});\n');
(async()=>{let context;const r={start:cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim(),method:'Isolated headed Chromium persistent profile; native chrome.tabs.setZoom/getZoom. No CSS zoom/font-size/device-scale/page-scale emulation.',references:['https://developer.chrome.com/docs/extensions/reference/api/tabs#method-setZoom','https://playwright.dev/docs/chrome-extensions'],profile:temp,scenarios:[]};try{
 context=await chromium.launchPersistentContext(path.join(temp,'profile'),{channel:'chromium',headless:false,viewport:null,args:['--disable-extensions-except='+extension,'--load-extension='+extension,'--window-size=1280,1000']});
 const worker=context.serviceWorkers()[0]||await context.waitForEvent('serviceworker',{timeout:10000});const page=await context.newPage();await page.goto('http://127.0.0.1:4181/?fixture=player');
 const cdp=await context.newCDPSession(page),windowInfo=await cdp.send('Browser.getWindowForTarget');r.nativeWindow=windowInfo;const nativeWidth=await page.evaluate(()=>innerWidth);await cdp.send('Browser.setWindowBounds',{windowId:windowInfo.windowId,bounds:{width:windowInfo.bounds.width+(1280-nativeWidth)}});
 await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(1280);
 r.baseline=await page.evaluate(()=>({innerWidth,innerHeight,outerWidth,outerHeight,dpr:devicePixelRatio,fontSize:getComputedStyle(document.documentElement).fontSize,cssZoom:getComputedStyle(document.documentElement).zoom,visualScale:visualViewport.scale,screen:{width:screen.width,height:screen.height,availWidth:screen.availWidth,availHeight:screen.availHeight}}));
 r.viewportLimit='Native Windows browser viewport is recorded as observed. The1280x900 primary-play requirement is independently checked in Chromium tests; native zoom proves factor2.0 with unchanged root font/CSS zoom and observed halved CSS viewport.';
 r.tabZoom=await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});await chrome.tabs.setZoomSettings(tab.id,{mode:'automatic',scope:'per-tab'});await chrome.tabs.setZoom(tab.id,2);return{tabId:tab.id,zoom:await chrome.tabs.getZoom(tab.id),settings:await chrome.tabs.getZoomSettings(tab.id)};});expect(r.tabZoom.zoom).toBe(2);
 await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(640);r.zoomMetrics=await page.evaluate(()=>({innerWidth,innerHeight,outerWidth,outerHeight,dpr:devicePixelRatio,fontSize:getComputedStyle(document.documentElement).fontSize,cssZoom:getComputedStyle(document.documentElement).zoom,visualScale:visualViewport.scale}));expect(r.zoomMetrics.dpr/r.baseline.dpr).toBe(2);expect(r.zoomMetrics.fontSize).toBe(r.baseline.fontSize);expect(r.zoomMetrics.cssZoom).toBe(r.baseline.cssZoom);
 for(const fixture of ['player','player-five','player-split','player-rsa-cap']){
  await page.goto('http://127.0.0.1:4181/?fixture='+fixture);
  const configuredZoom=await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});await chrome.tabs.setZoom(tab.id,2);return chrome.tabs.getZoom(tab.id);});expect(configuredZoom).toBe(2);await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(640);
  await page.getByLabel('Your main wager',{exact:false}).fill('100');await page.getByRole('button',{name:'Deal',exact:true}).click();
  if(fixture==='player-five'){for(let i=0;i<3;i++)await page.getByRole('button',{name:'Hit',exact:true}).click();await expect(page.locator('#player-hand article .card')).toHaveCount(5);}
  if(fixture==='player-split'){await page.getByRole('button',{name:'Split',exact:true}).click();await expect(page.locator('#player-hand article')).toHaveCount(2);}
  if(fixture==='player-rsa-cap'){for(let i=0;i<3;i++)await page.getByRole('button',{name:'Split',exact:true}).click();await expect(page.locator('#player-hand article')).toHaveCount(4);}
  await expect(page.getByRole('region',{name:'Your credits',exact:true})).toBeVisible();await expect(page.locator('.credits dt')).toHaveText(['Available','Reserved / current exposure','Pending return']);const geometry=await page.locator('.casino-table').evaluate(table=>{const rect=el=>{const b=el.getBoundingClientRect();return{x:b.x,y:b.y,width:b.width,height:b.height};};return{table:rect(table),regions:[...table.querySelectorAll('.dealer,.seat')].map(el=>({name:el.getAttribute('aria-label'),...rect(el)})),innerWidth,scrollWidth:document.documentElement.scrollWidth,cards:[...document.querySelectorAll('#player-hand article .cards')].map(el=>({clientWidth:el.clientWidth,scrollWidth:el.scrollWidth})),clips:[...document.querySelectorAll('#player-hand,.player-dock')].map(el=>({name:el.id||el.className,overflow:getComputedStyle(el).overflow,clientHeight:el.clientHeight,scrollHeight:el.scrollHeight}))};});expect(geometry.scrollWidth).toBeLessThanOrEqual(geometry.innerWidth);for(const c of geometry.cards)expect(c.scrollWidth).toBeLessThanOrEqual(c.clientWidth);for(const c of geometry.clips)expect(['hidden','clip']).not.toContain(c.overflow);
  for(let i=0;i<geometry.regions.length;i++){const a=geometry.regions[i];for(const b of geometry.regions.slice(i+1))expect(a.x+a.width<=b.x+1||b.x+b.width<=a.x+1||a.y+a.height<=b.y+1||b.y+b.height<=a.y+1,a.name+' intersects '+b.name).toBe(true);}
  expect(geometry.innerWidth).toBe(640);
  const screenshots=[];
  for(const [position,selector] of [['top',null],['hand','#player-hand'],['controls','.player-dock']]){
    if(selector)await page.locator(selector).scrollIntoViewIfNeeded();else await page.evaluate(()=>scrollTo(0,0));
    await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    const image=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});
    const name='zoom200-'+fixture+'-'+position+'.png';fs.writeFileSync(path.join(dir,name),Buffer.from(image.data,'base64'));screenshots.push(name);
  }
  const beforeKeyboardZoom=await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});return chrome.tabs.getZoom(tab.id);});expect(beforeKeyboardZoom).toBe(2);expect(await page.evaluate(()=>innerWidth)).toBe(640);
  const targetName=fixture==='player-rsa-cap'?'Deal Again':'Stand',keyboardTarget=page.getByRole('button',{name:targetName,exact:true});await page.locator(fixture==='player-rsa-cap'?'#player-result':'#player-hand').focus();for(let i=0;i<12&&!await keyboardTarget.evaluate(el=>el===document.activeElement);i++)await page.keyboard.press('Tab');await expect(keyboardTarget).toBeFocused();const box=await keyboardTarget.boundingBox();expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);const focusBefore=await page.evaluate(()=>({tag:document.activeElement.tagName,text:document.activeElement.textContent,scrollY,innerWidth}));await page.keyboard.press('Enter');if(fixture==='player-rsa-cap')await expect(page.getByLabel('Your main wager',{exact:false})).toBeFocused();else if(fixture==='player-split')await expect(page.locator('#player-hand')).toBeFocused();else await expect(page.locator('#player-result')).toBeFocused();r.scenarios.push({fixture,status:'PASS',zoom:await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});return chrome.tabs.getZoom(tab.id);}),geometry,keyboardTarget:targetName,button:box,screenshots,focusBefore,configuredZoom,beforeKeyboardZoom});
 }
 
 await page.goto('http://127.0.0.1:4181/?fixture=player');
 await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});await chrome.tabs.setZoom(tab.id,2);});
 await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(640);
 const dealer=page.getByRole('region',{name:'Dealer',exact:true});
 const captures=[];
 const capture=async state=>{await dealer.scrollIntoViewIfNeeded();await page.evaluate(()=>scrollTo(0,0));const pixels=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});const name='zoom200-dealer-'+state+'.png';fs.writeFileSync(path.join(dir,name),Buffer.from(pixels.data,'base64'));captures.push(name);};
 await expect(dealer.getByText('Waiting for the initial deal',{exact:true})).toBeVisible();await capture('idle');
 await page.getByLabel('Your main wager',{exact:false}).fill('100');await page.getByRole('button',{name:'Deal',exact:true}).click();
 await expect(dealer.locator('.dealer-total')).toHaveText('Visible total: 4');await expect(dealer.locator('.dealer-state')).toHaveText('Hole card hidden');await capture('hidden');
 await page.locator('#player-hand').focus();const stand=page.getByRole('button',{name:'Stand',exact:true});for(let i=0;i<8&&!await stand.evaluate(el=>el===document.activeElement);i++)await page.keyboard.press('Tab');await expect(stand).toBeFocused();await page.keyboard.press('Enter');await expect(page.locator('#player-result')).toBeFocused();
 await expect(dealer.locator('.dealer-card-lane .card')).toHaveCount(3);await expect(dealer.locator('.dealer-total')).toHaveText('Total: 23');await expect(dealer.locator('.dealer-state')).toHaveText('Bust');await expect(dealer.getByRole('img',{name:'Hidden dealer card',exact:true})).toHaveCount(0);await capture('revealed-three');
 r.dealerStates={status:'PASS',zoom:await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});return chrome.tabs.getZoom(tab.id);}),screenshots:captures,geometry:await dealer.evaluate(el=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,total:el.querySelector('.dealer-total').textContent,status:el.querySelector('.dealer-state').textContent,children:[...el.querySelectorAll('.dealer-card-lane,.dealer-total,.dealer-state,.dealer-shoe,.table-inscription')].map(child=>({className:child.className,clientWidth:child.clientWidth,scrollWidth:child.scrollWidth}))}))};
 expect(r.dealerStates.zoom).toBe(2);expect(r.dealerStates.geometry.scrollWidth).toBeLessThanOrEqual(640);for(const box of r.dealerStates.geometry.children)expect(box.scrollWidth).toBeLessThanOrEqual(box.clientWidth);

 r.controlScenarios=[];
 for(const state of ['open','insurance','even-money','unaffordable']){
  await page.goto('http://127.0.0.1:4181/?fixture='+(['insurance','unaffordable'].includes(state)?'player-ace':state==='even-money'?'player-even-money':'player'));
  const zoom=await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});await chrome.tabs.setZoom(tab.id,2);return chrome.tabs.getZoom(tab.id);});expect(zoom).toBe(2);await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(640);
  await page.getByLabel('Your main wager',{exact:false}).fill(state==='unaffordable'?'1000':'100');
  if(state!=='open')await page.getByRole('button',{name:'Deal',exact:true}).click();
  else {await page.getByRole('button',{name:'Choose 25 credits',exact:true}).click();await expect(page.getByLabel('Your main wager',{exact:false})).toHaveValue('25');}
  const surface=page.locator(state==='open'?"[data-control-surface='betting']":"[data-control-surface='insurance']");
  const geometry=await surface.evaluate(el=>({innerWidth,scrollWidth:document.documentElement.scrollWidth,controls:[...el.querySelectorAll('button,input,summary')].filter(el=>el.checkVisibility()).map(el=>({text:el.textContent||el.getAttribute('aria-label'),width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height,clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,disabled:el.disabled||false}))}));
  expect(geometry.scrollWidth).toBeLessThanOrEqual(640);for(const control of geometry.controls){expect(control.width).toBeGreaterThanOrEqual(44);expect(control.height).toBeGreaterThanOrEqual(44);expect(control.scrollWidth).toBeLessThanOrEqual(control.clientWidth);}
  if(state==='unaffordable')await expect(page.getByRole('button',{name:'Buy Insurance',exact:true})).toBeDisabled();
  const screenshots=[];for(const [position,selector]of [['hand','#player-hand'],['controls',state==='open'?"[data-control-surface='betting']":"[data-control-surface='insurance']"]]){await page.locator(selector).scrollIntoViewIfNeeded();const pixels=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});const name='zoom200-control-'+state+'-'+position+'.png';fs.writeFileSync(path.join(dir,name),Buffer.from(pixels.data,'base64'));screenshots.push(name);}
  const name=state==='open'?'Deal':state==='even-money'?'Take Even Money':'Decline',target=page.getByRole('button',{name,exact:true});await page.locator(state==='open'?'#player-decisions':'.decision').focus();for(let i=0;i<12&&!await target.evaluate(el=>el===document.activeElement);i++)await page.keyboard.press('Tab');await expect(target).toBeFocused();expect(await target.evaluate(el=>getComputedStyle(el).outlineStyle)).toBe('solid');await page.keyboard.press('Enter');await expect(page.locator(state==='even-money'?'#player-result':'#player-hand')).toBeFocused();
  r.controlScenarios.push({state,status:'PASS',zoom,geometry,keyboardTarget:name,screenshots});
 }
 r.roundCompleteScenarios=[];
 for(const [fixture,amount,net,available] of [['player','100','100','1,100'],['player-loss','100','-100','900'],['player-push','100','0','1,000'],['player-loss','1000','-1,000','0']]){
  await page.goto('http://127.0.0.1:4181/?fixture='+fixture);
  const zoom=await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});await chrome.tabs.setZoom(tab.id,2);return chrome.tabs.getZoom(tab.id);});expect(zoom).toBe(2);await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(640);
  await page.getByLabel('Your main wager',{exact:false}).fill(amount);await page.getByRole('button',{name:'Deal',exact:true}).click();await page.getByRole('button',{name:'Stand',exact:true}).click();
  const surface=page.locator('#player-result');await expect(surface).toBeFocused();await expect(page.locator('.round-net')).toHaveText('Net result: '+net+' credits');await expect(page.locator('.credits dd')).toHaveText([available,'0','0']);
  const geometry=await surface.evaluate(el=>({innerWidth,scrollWidth:document.documentElement.scrollWidth,controls:[...el.querySelectorAll('button,summary')].filter(el=>el.checkVisibility()).map(el=>({text:el.textContent,width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height,clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,disabled:el.disabled||false}))}));
  expect(geometry.scrollWidth).toBeLessThanOrEqual(640);for(const control of geometry.controls){expect(control.width).toBeGreaterThanOrEqual(44);expect(control.height).toBeGreaterThanOrEqual(44);expect(control.scrollWidth).toBeLessThanOrEqual(control.clientWidth);}
  const screenshots=[];for(const [position,selector]of [['hand','#player-hand'],['controls','#player-result']]){await page.locator(selector).scrollIntoViewIfNeeded();const pixels=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});const name='zoom200-complete-'+fixture+'-'+amount+'-'+position+'.png';fs.writeFileSync(path.join(dir,name),Buffer.from(pixels.data,'base64'));screenshots.push(name);}
  await surface.locator('summary').focus();await page.keyboard.press('Enter');await expect(surface.locator('details')).toHaveAttribute('open','');await expect(surface.locator('details')).toContainText('Deal Again opens betting. Repeat Bet deals your original main wager only. Balances and the existing shoe continue.');
  expect(await surface.evaluate(el=>el.scrollWidth<=el.clientWidth)).toBe(true);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  await surface.locator('details').scrollIntoViewIfNeeded();const pixels=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});const name='zoom200-complete-'+fixture+'-'+amount+'-expanded.png';fs.writeFileSync(path.join(dir,name),Buffer.from(pixels.data,'base64'));screenshots.push(name);
  await surface.locator('summary').focus();await page.keyboard.press('Space');await expect(surface.locator('details')).not.toHaveAttribute('open','');
  if(amount==='1000')await expect(page.getByRole('button',{name:'Repeat Bet · 1,000 credits',exact:true})).toBeDisabled();
  await surface.focus();await page.keyboard.press('Tab');await expect(page.getByRole('button',{name:'Deal Again',exact:true})).toBeFocused();await page.keyboard.press('Enter');await expect(page.getByLabel('Your main wager',{exact:false})).toBeFocused();
  r.roundCompleteScenarios.push({fixture,amount,net,available,status:'PASS',zoom,geometry,screenshots,disclosureKeyboard:'Enter/Space PASS',nextRoundFocus:'Native Tab/Enter Deal Again -> wager PASS'});
 }

 r.formalPortraits=[];
 const approved=['noble_female','knight_female','mage_female','elf_female','halforc_female'],labels=['Celestine','Seraphine','Nyra','Elaria','Vesha'];
 const zoomTo=async factor=>{await worker.evaluate(async factor=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});await chrome.tabs.setZoom(tab.id,factor);},factor);await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(1280/factor);};
 const captureFormal=async(id,count,factor)=>{
   await zoomTo(factor);const zone=page.getByRole('region',{name:'Dealer',exact:true});
   await expect(zone).toHaveAttribute('data-dealer-character',id);const portrait=zone.getByRole('img',{name:'Dealer: '+labels[approved.indexOf(id)],exact:true});
   await expect(portrait).toHaveJSProperty('naturalWidth',240);await expect(portrait).toHaveJSProperty('naturalHeight',320);
   const actual=await worker.evaluate(async()=>{const [tab]=await chrome.tabs.query({url:'http://127.0.0.1:4181/*'});return chrome.tabs.getZoom(tab.id);});expect(actual).toBe(factor);
   const geometry=await zone.evaluate(el=>({innerWidth,scroll:document.documentElement.scrollWidth,rootFont:getComputedStyle(document.documentElement).fontSize,cssZoom:getComputedStyle(document.documentElement).zoom,
     contents:[...el.querySelectorAll('.dealer-card-lane,.dealer-total,.dealer-state,.dealer-shoe,.table-inscription')].map(c=>({name:c.className,width:c.clientWidth,scroll:c.scrollWidth}))}));
   expect(geometry.scroll).toBeLessThanOrEqual(geometry.innerWidth);expect(geometry.rootFont).toBe('16px');expect(geometry.cssZoom).toBe('1');for(const c of geometry.contents)expect(c.scroll).toBeLessThanOrEqual(c.width);
   await page.evaluate(()=>scrollTo(0,0));const pixels=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false}),name='formal-'+id+'-'+count+'-native'+factor+'.png';fs.writeFileSync(path.join(dir,name),Buffer.from(pixels.data,'base64'));
   r.formalPortraits.push({id,count,zoom:actual,geometry,screenshot:name,status:'PASS'});
 };
 await page.goto('http://127.0.0.1:4181/?fixture=player-setup');
 for(let ordinal=0;ordinal<5;ordinal++){
   if(ordinal)await page.getByRole('button',{name:'New table · reset to 1000 credits',exact:true}).click();
   await page.getByLabel('Total players').selectOption('1');await page.getByRole('button',{name:'Start table',exact:true}).click();await captureFormal(approved[ordinal],1,2);
 }
 for(const [count,id] of [[4,'noble_female'],[4,'mage_female'],[7,'halforc_female']]){
   await page.getByRole('button',{name:'New table · reset to 1000 credits',exact:true}).click();await page.getByLabel('Total players').selectOption(String(count));await page.getByRole('button',{name:'Start table',exact:true}).click();
   await captureFormal(id,count,1);await captureFormal(id,count,2);
 }
 r.status='PASS';r.exitCode=0;
}catch(e){r.status='FAIL';r.exitCode=1;r.failure=String(e);console.error(e);process.exitCode=1;}finally{r.end=cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim();fs.writeFileSync(path.join(dir,'zoom200.json'),JSON.stringify(r,null,2)+'\n');if(context)await context.close();console.log(JSON.stringify({status:r.status,zoom:r.tabZoom,baseline:r.baseline,metrics:r.zoomMetrics,scenarios:r.scenarios.map(s=>s.fixture)}));}})();
