const fs=require('node:fs'),cp=require('node:child_process');
const dir='docs/M10_T04B_EVIDENCE',[phase,kind]=process.argv.slice(2),commands={
 typecheck:'& npm.cmd run typecheck; exit $LASTEXITCODE',lint:'& npm.cmd run lint; exit $LASTEXITCODE',
 unit:'& npm.cmd test -- tests/m10 tests/pa1 tests/ra1 tests/m9; exit $LASTEXITCODE',
 assets:'& node scripts/verify-dealer-assets.mjs; exit $LASTEXITCODE',
 pa1:'& node scripts/verify-character-assets.mjs; exit $LASTEXITCODE',
};
if(!commands[kind]||!/^[a-z0-9-]+$/.test(phase))throw Error('Unknown check');
const stamp=()=>cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim();
const fd=fs.openSync(dir+'/'+phase+'.log','wx'),start=stamp();
const child=cp.spawnSync('powershell.exe',['-NoProfile','-Command',commands[kind]],{stdio:['ignore',fd,fd]});fs.closeSync(fd);
const r={phase,start,end:stamp(),command:commands[kind],status:child.error?'BLOCKED':child.status===0?'PASS':'FAIL',exitCode:child.status,error:child.error?String(child.error):null};
fs.writeFileSync(dir+'/'+phase+'.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify(r));console.log(fs.readFileSync(dir+'/'+phase+'.log','utf8').split(/\r?\n/).slice(-20).join('\n'));process.exitCode=child.status??1;
