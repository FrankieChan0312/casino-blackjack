const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto'),zlib=require('node:zlib'),cp=require('node:child_process');
const root='docs/M10_T04B_EVIDENCE',hash=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(JSON.parse(fs.readFileSync(root+'/unified-final.json')).status,'FAIL');
for(const f of JSON.parse(fs.readFileSync(root+'/repair8-before-versions.json')).files)assert.equal(hash(fs.readFileSync(f.path)),f.sha256);
fs.writeFileSync('scripts/verify-dealer-assets.mjs',fs.readFileSync('.git/t04b-optimized-audit.mjs'));
const records=[];
for(const plan of [{file:'tests/browser/m10a/controlIntegration.spec.ts',tag:'M10A-CB10',loop:"  for (const viewport of viewports) for (const state of ['insurance', 'even-money', 'complete-win', 'complete-loss', 'complete-push']) {"},{file:'tests/browser/m10a/t08.spec.ts',tag:'M10A-T08-B02',loop:"  for(const viewport of viewports)for(const state of ['split','five','insurance','even-money','complete','pending']) {"}]){
 const before=fs.readFileSync(plan.file,'utf8'),entry=JSON.parse(fs.readFileSync(root+'/repair9-before-versions.json')).files.find(f=>f.path===plan.file);assert.equal(hash(Buffer.from(before)),entry.sha256);
 const header=before.split(/\r?\n/).find(line=>line.startsWith("test('["+plan.tag+"]"));assert.ok(header);
 const nextHeader='for (const viewport of viewports) '+header.replace("test('["+plan.tag+"]",'test(`['+plan.tag+'-${viewport.width}]').replace("', async",'`, async');
 const nextLoop=plan.loop.replace(/for\s*\(const viewport of viewports\)\s*/, '');
 assert.equal(before.split(header).length,2);assert.equal(before.split(plan.loop).length,2);
 const after=before.replace(header,nextHeader).replace(plan.loop,nextLoop);assert.equal(after.replace(nextHeader,header).replace(nextLoop,plan.loop),before);
 fs.writeFileSync(plan.file,after);records.push({path:plan.file,beforeSha256:entry.sha256,afterSha256:hash(Buffer.from(after)),changes:'Only test header and outer viewport loop moved to module parameterization',inverseTransformationByteEquality:'PASS',assertionAndScenarioBodies:'UNCHANGED',perCaseTimeoutMs:30000,skipRetryAdded:false});
}
const title='public-only module and empty production configuration have no gameplay, timers or animation dependency',d='tests/m10/dealerPresentation.test.tsx';fs.writeFileSync(d,fs.readFileSync(d,'utf8').replace(title,'public-only module and production formal configuration have no gameplay, timers or animation dependency'));
let runner=fs.readFileSync('.git/t04b-runner.cjs','utf8');runner=runner.replace('const commands = {','const commands = {\n  matrix: \'& npm.cmd run test:e2e -- tests/browser/m10a/controlIntegration.spec.ts tests/browser/m10a/t08.spec.ts --grep "M10A-CB10|M10A-T08-B02"; exit $LASTEXITCODE\',').replace("'dealer','formal'].includes(kind)","'dealer','formal','matrix'].includes(kind)");fs.writeFileSync('.git/t04b-runner.cjs',runner);
const r={timestamp:cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim(),records,decoderChange:'Selected predictor only; identical10-file decoded JSON candidate proof retained',testTitleCorrection:'D10 now names its existing approved formal production assertion truthfully; assertions unchanged',affectedVerification:'NOT RUN'};fs.writeFileSync(root+'/repair89-fix.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify({timestamp:r.timestamp,fixed:2,assertionBodies:'UNCHANGED'}));
