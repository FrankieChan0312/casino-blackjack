$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$evidenceRoot = Join-Path (Get-Location) 'docs/M10_T04B_EVIDENCE'
$patterns = @('-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----','\b(ghp|github_pat)_[A-Za-z0-9_]{20,}\b','\bsk-[A-Za-z0-9_-]{20,}\b','\bAKIA[A-Z0-9]{16}\b','https?://[^\s/]+:[^\s/]+@')
$counts = @{plaintext=0;gzip=0;zipEntries=0}
$allFiles = Get-ChildItem -LiteralPath $evidenceRoot -File -Recurse
foreach ($taskFile in $allFiles) {
  if ($taskFile.Extension -eq '.gz') {
    $inputStream = [System.IO.File]::OpenRead($taskFile.FullName)
    $decoder = [System.IO.Compression.GZipStream]::new($inputStream,[System.IO.Compression.CompressionMode]::Decompress)
    $reader = [System.IO.StreamReader]::new($decoder)
    try { $content = $reader.ReadToEnd(); foreach ($pattern in $patterns) {if ($content -match $pattern) {throw "Sensitive pattern in gzip: $($taskFile.Name)"}}; $counts.gzip++ }
    finally {$reader.Dispose();$decoder.Dispose();$inputStream.Dispose()}
  } elseif ($taskFile.Extension -eq '.zip') {
    $archive = [System.IO.Compression.ZipFile]::OpenRead($taskFile.FullName)
    try {foreach ($entry in $archive.Entries) {if ($entry.FullName.EndsWith('/')) {continue};$reader=[System.IO.StreamReader]::new($entry.Open());try {$content=$reader.ReadToEnd();foreach ($pattern in $patterns) {if ($content -match $pattern) {throw "Sensitive pattern in trace: $($taskFile.Name)/$($entry.FullName)"}};$counts.zipEntries++}finally {$reader.Dispose()}}}
    finally {$archive.Dispose()}
  } elseif ($taskFile.Extension -in @('.md','.txt','.json','.jsonl','.log')) {
    $content = [System.IO.File]::ReadAllText($taskFile.FullName)
    foreach ($pattern in $patterns) {if ($content -match $pattern) {throw "Sensitive pattern in text: $($taskFile.Name)"}}
    $counts.plaintext++
  }
}
$receipt = @{timestamp=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K');status='PASS';exitCode=0;counts=$counts;sensitivePatternFindings=@();review='Original task/resume and local fixture traces inspected as project records; repository owner/public project paths are intentional. No real accounts, cookies, third-party/customer data or session chat dump.'}
$receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'publication-privacy.json') -Encoding utf8
$receipt | ConvertTo-Json -Compress -Depth 8
