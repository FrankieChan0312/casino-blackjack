const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process'),zlib=require('node:zlib');
const dir='docs/M10_T04_EVIDENCE',hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const timestamp=cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim();
const phase=JSON.parse(fs.readFileSync(dir+'/t04a-20261005-repair1-dealer.json'));
fs.mkdirSync(dir+'/screenshots',{recursive:true});
const images=phase.testScopedOutputs.filter(f=>/dealer-table.*\.png$/.test(f.path)).map(f=>{const name=path.basename(f.path);fs.copyFileSync(dir+'/'+f.retainedAt,dir+'/screenshots/'+name);return {name,sha256:f.sha256,sourcePhase:phase.phase};});
fs.writeFileSync(dir+'/screenshots/index.json',JSON.stringify({timestamp,images},null,2)+'\n');
const archives=[];
for(const name of fs.readdirSync(dir+'/generated').filter(f=>f.endsWith('.md'))){const p=dir+'/generated/'+name,raw=fs.readFileSync(p),packed=zlib.gzipSync(raw);fs.writeFileSync(p+'.gz',packed);if(hash(zlib.gunzipSync(packed))!==hash(raw))throw Error('Archive mismatch');archives.push({path:'generated/'+name,retainedAt:'generated/'+name+'.gz',originalSha256:hash(raw),compressedSha256:hash(packed),reason:'Preserve exact raw Markdown source excerpts without staged trailing-space errors'});fs.unlinkSync(p);}
fs.writeFileSync(dir+'/generated-archives.json',JSON.stringify({timestamp,archives},null,2)+'\n');
const source=JSON.parse(fs.readFileSync('docs/PA1_SOURCE_AUDIT.json')).files,production=JSON.parse(fs.readFileSync('art/character-production.json')).files;
const shortlist=['noble_male','noble_female','elf_male'].map((id,index)=>({rank:index+1,id,approval:'NOT YET RECORDED',original:source.find(f=>f.name===id+'.png'),canonicalProduction:production.find(f=>f.id===id)}));
fs.writeFileSync(dir+'/shortlist/receipts.json',JSON.stringify({timestamp,artwork:'NOT CREATED',sourceCommand:'node scripts/preview-character-sources.mjs',sourceCommandExitCode:0,shortlist},null,2)+'\n');
const failed=JSON.parse(fs.readFileSync(dir+'/t04a-20261005-first-dealer.json'));
fs.writeFileSync(dir+'/repair-ledger.json',JSON.stringify({task:'M10-T04',cumulative:1,maximum:10,cycles:[{cycle:1,failurePhase:failed.phase,status:failed.status,exitCode:failed.exitCode,hypothesis:'Single-player seed7 public Ace Insurance requires Decline before an available Stand; new test missed the decision.',fix:'Test-only actual Insurance/Stand/committed-result helper; retains all identity/state/card/order assertions.',rerunPhase:phase.phase,rerunStatus:phase.status,rerunExitCode:phase.exitCode}]},null,2)+'\n');
for(const file of ['docs/M10_T04.md']){const text=fs.readFileSync(file,'utf8').replace('Repair count: M10-T04 0/10.','Repair count: M10-T04 1/10.');fs.writeFileSync(file,text);}
const note=`## M10-T04-A focused checkpoint — ${timestamp}\n\nRepair1/10 closed: first new Chromium fixture incorrectly attempted Stand during actual single-player Insurance; original FAIL/exit1 retained. Targeted test-only sequence repair passed9/9 Chromium, focused19 files/146 Vitest, typecheck/lint PASS/0. No source repair or assertion weakening.18 new fallback/text200 screenshots retained for review; artwork NOT CREATED. Full gate pending. M10-T02/T03 human ACCEPTED; T05/Motion/animation NOT STARTED.\n\n`;
fs.writeFileSync('docs/STATE.md',note+fs.readFileSync('docs/STATE.md','utf8'));
fs.appendFileSync('docs/DEVELOPMENT_LOG.md','\n'+note);
console.log(JSON.stringify({timestamp,images:images.length,archivedFailedContexts:archives.length,repair:1}));
