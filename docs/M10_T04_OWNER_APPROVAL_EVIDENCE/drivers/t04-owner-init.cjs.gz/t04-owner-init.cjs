const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto');
const task='M10_T04_OWNER_APPROVAL',dir='docs/'+task+'_EVIDENCE';
const git=(...args)=>cp.execFileSync('git',args,{encoding:'utf8',maxBuffer:32*1024*1024}).trim();
const stamp=()=>cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim();
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const baseline=git('rev-parse','HEAD');
if(baseline!=='a888bd36bc88deb249c83584279da13a18322ce5'||git('branch','--show-current')!=='main'||git('status','--porcelain','-uall'))throw Error('Unexpected baseline');
if(git('remote','get-url','origin')!=='https://github.com/FrankieChan0312/casino-blackjack.git'||git('ls-remote','origin','refs/heads/main').split(/\s/)[0]!==baseline||git('rev-list','--left-right','--count','HEAD...origin/main')!=='0\t0')throw Error('Unexpected publication target/parity');
const files=git('ls-files').split('\n').map(path=>({path,sha256:hash(fs.readFileSync(path))})),timestamp=stamp();
if(fs.existsSync(dir))throw Error('Occupied checkpoint evidence directory');
fs.mkdirSync(dir);
const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n');
write(dir+'/before.json',{timestamp,baseline,branch:'main',remoteHead:baseline,ahead:0,behind:0,workingTree:'CLEAN',untracked:0,files});
const allowed=['README.md','docs/STATE.md','docs/PLAN.md','docs/DEVELOPMENT_LOG.md','docs/LAB_MANUAL.md','docs/M10_T04.md','docs/'+task+'.md'];
write(dir+'/scope.json',{task,timestamp,allowed,additionalAllowedPrefix:dir+'/',noProductChanges:true});
fs.copyFileSync('C:/Users/user/.codex/attachments/34d2c794-5727-4bed-a563-cb41aa4983b4/貼上的文字.txt',dir+'/owner-authorization.txt');
const assetFiles=git('ls-files','art','public').split('\n');
const production='public/characters/dealer/noble_female/formal.png',derived='art/source/dealers/noble_female/formal.png';
if(fs.existsSync(production)||fs.existsSync(derived)||assetFiles.some(p=>/dealer|formal/i.test(p)))throw Error('Unexpected formal candidate: inspect approval/provenance before proceeding');
const original='art/source/characters/PA1_character_sources/noble_female.png',canonical='public/characters/noble_female.png';
write(dir+'/approved-direction.json',{timestamp,status:'FORMAL DEALER ARTWORK REQUIRED',identity:{name:'Celestine',characterId:'noble_female',ownerApproval:dir+'/owner-authorization.txt',preferred:true},role:'dealer',variant:'formal',format:'png',transparent:true,width:240,height:320,aspectRatio:'3:4',plannedProduction:production,plannedPublicUrl:'/characters/dealer/noble_female/formal.png',plannedDerivedSource:derived,artworkPresent:false,sha256:null,derivedProvenance:null,approvedFinalArtwork:false,runtimeDescriptorRegistered:false,original:{path:original,sha256:hash(fs.readFileSync(original))},canonicalPlayer:{path:canonical,sha256:hash(fs.readFileSync(canonical))},originalProvenanceReference:'docs/PA1_SOURCE_AUDIT.json',direction:{preserve:['recognisable face','hair identity and silhouette','feminine noble identity','established character-art style'],outfit:['black or deep-charcoal tailored waistcoat / tuxedo-inspired formalwear','white shirt','restrained gold accents','premium evening-table appearance','clean readable upper-body silhouette','natural hands and forearms'],reduce:['oversized crown or head ornamentation','ceremonial sleeve decoration','details interfering with cards or DealerZone'],avoid:['green-dominant clothing','heavy armour','exaggerated casino accessories','excessive jewellery','sexualised redesign','unrecognisable face']},presentationStates:['IDLE','DEALING','WAITING_PLAYER','REVEALING','DRAWING','SETTLING'],animationImplemented:false});
write(dir+'/asset-inventory.json',{timestamp,status:'PASS',exitCode:0,method:'git ls-files art public plus actual expected-path existence checks; clean untracked baseline',files:assetFiles.map(path=>({path,sha256:hash(fs.readFileSync(path))})),productionExists:false,derivedSourceExists:false,formalCandidateFiles:[],note:'24 PA1 PNGs and two existing production/audit JSON files; no approved Dealer formal asset'});
const contract=`# M10-T04 owner approval — Celestine formal Dealer direction

Task ID: M10-T04-OWNER-APPROVAL. Milestone: M10-T04; documentation/contract checkpoint after T04-A, before artwork-dependent T04-B. Start: ${timestamp}; baseline main/${baseline}, origin/live parity0/0, CLEAN/untracked0. [Exact owner request](${task}_EVIDENCE/owner-authorization.txt).

Recommended model: GPT Sol6.1; reasoning/effort: High. Both supported by current client tool metadata; actual selected runtime model/effort NOT VERIFIED. No delegation.

## Task contract

Scope: record the explicit initial identity and outfit-direction approval, preserve the existing deterministic assignment policy, inventory actual assets, establish the exact separate destination and verify existing fallback/product preservation. Only separately approved artwork with known provenance would permit T04-B integration; none exists in the inspected repository.

Non-goals: creating, synthesizing, downloading or substituting artwork; modifying PA1 images/manifests/provenance; changing product source/tests/dependencies/runtime configuration, gameplay, participant counts, seating, UI or accepted historical evidence. Motion, animation, T05 and deployment remain outside this checkpoint.

Acceptance: Celestine owner approval and the precise formal contract recorded; missing artwork reported truthfully; exact future paths established without creating fake files or hashes; existing identity/fallback tests and read-only PA1 verification pass; all incoming product/domain/artwork bytes unchanged; inspected documentation diff normally committed/pushed to authorized main with local/live remote parity0/0, CLEAN/untracked0.

Step -> verification: baseline/inventory -> exact Git state and incoming hashes; record approval/contract -> source-backed roster ID, real PA1 hashes and documentation tests; verify existing shell -> Dealer unit/Chromium fallback checks and PA1 decoder/reproduction; inspect scoped diff/protected bytes -> same-session review; normal commit/push -> checked exits and live parity/clean proof. Full unified verification is NOT RUN in this documentation-only checkpoint; prior T04-A full PASS remains historical evidence on unchanged executable bytes.

Stop conditions: authority conflict, unknown overlapping changes, unavailable required check, protected semantic/asset drift, sensitive-data handling, repair limit or unauthorized Git/deployment. Absent formal artwork stops T04-B integration as explicitly required by the owner. This completes the approval-record task without claiming T04-B completion.

## Owner decision and deterministic assignment

**INITIAL DEALER AVATAR: CELESTINE — OWNER APPROVED.** Canonical ID: noble_female. This supersedes the earlier T04-A identity-selection-pending statements only; its implementation, verification, failed attempts and repair history remain unchanged. The supplied request identifies the accepted T04-A result but does not approve nonexistent finished formal artwork or claim full T04 artwork/motion acceptance.

Celestine is the approved preferred identity for future T04-B configuration. Use her if she is absent from every occupied human/computer identity. If seated, choose the first eligible ID in the established canonical roster order. Preserve the stronger T04-A occupied-seat exclusion, including Sitting Out; funded gameplay participation does not redefine identity occupancy. Never duplicate the Dealer with a seated player.

Keep the selected identity stable from Start through normal rounds, avatar changes and resize, until a new table/demo reset. Assignment consumes zero gameplay RNG and issues no commands. Participant counts, real seats/turn order, cards/shoe, strategies, accounting/settlement, replay/digest/journal remain unchanged. Production main.tsx remains unconfigured and renders the established temporary Dealer while the approved formal asset is absent; no Celestine portrait integration is claimed.

## Approved formal-variant direction and pending manifest

Identity Celestine / noble_female; role dealer; variant formal; transparent PNG RGBA8, production240x320,3:4. Preserve her recognisable face, hair identity/silhouette, feminine noble identity and established art style. Use elegant black/deep-charcoal tailored waistcoat or tuxedo-inspired casino formalwear, white shirt and restrained gold accents. Aim for a premium evening table, readable clean upper-body/dealer-table crop, transparent exterior and natural hands/forearms for later dealing presentation.

Reduce oversized crown/head ornaments and ceremonial sleeve decoration where necessary. Remove details that obscure cards or DealerZone readability. Avoid green-dominant clothing blending into felt, heavy armour, exaggerated casino accessories, excessive jewellery, sexualised redesign and unrecognisable facial changes.

| Future canonical destination | Exact path |
| --- | --- |
| Separate production asset | public/characters/dealer/noble_female/formal.png |
| Public asset URL | /characters/dealer/noble_female/formal.png |
| Separate derived source | art/source/dealers/noble_female/formal.png |

These are planned paths only; no directory/image/usable runtime descriptor is created. The [pending approval manifest](${task}_EVIDENCE/approved-direction.json) deliberately records artworkPresent=false, sha256=null, derivedProvenance=null and approvedFinalArtwork=false. It is documentary evidence, not an executable DealerFormalAsset registry or licensing claim. The existing [T04-A asset gate](M10_T04.md) still requires actual decode/CRC/alpha/dimensions, source/output SHA256, derivation/provenance/rights evidence, identity comparison and owner approval of the finished variant, then DealerZone visual/accessibility/responsive/native200% checks before integration. If exclusion selects another identity, missing formal art for that identity retains the existing fallback; never display Celestine art for a different characterId.

## PA1 preservation and artwork prerequisite

Original source: art/source/characters/PA1_character_sources/noble_female.png. Accepted player portrait: public/characters/noble_female.png. Their real baseline SHA256 values, unchanged provenance reference and all26 asset inventory hashes are retained in the pending manifest/inventory. They remain immutable; the player portrait must never be relabelled as formal Dealer art. All other PA1 sources/production files/manifests and accepted evidence are protected as well.

**FORMAL CELESTINE DEALER ARTWORK NOT YET PRESENT — ASSET REQUIRED.** Inventory found twelve PA1 sources, twelve player PNGs and two existing production/audit JSON files, with no separate formal candidate. **FORMAL DEALER ARTWORK REQUIRED.** T04-B is ready for the approved identity/direction but its artwork prerequisite is BLOCKED by the absent approved PNG and provenance. Asset decoding/integration/visual acceptance for the nonexistent formal file are BLOCKED, not PASS or NOT APPLICABLE.

## Presentation and delivery boundary

Retain IDLE, DEALING, WAITING_PLAYER, REVEALING, DRAWING, SETTLING as presentation-only static hooks. **ANIMATION NOT IMPLEMENTED.** Production still uses actual synchronous public facts and the established fallback; later event feeds/gesture timing remain separately scoped. No Motion installation. M10-T05 NOT STARTED. Deployment NOT RUN.

Cumulative M10-T04 repairs remain3/10, all earlier cycles closed; this approval checkpoint adds0 cycles. Same-session review and verification initially NOT RUN; execution receipts follow below. Genuinely fresh separate-session review NOT COMPLETED (unavailable).

Next action: **WAITING FOR APPROVED CELESTINE FORMAL DEALER ASSET**. Owner identity/outfit-direction approval is recorded; finished-artwork approval, T04-B integration and full T04 acceptance remain separate events.
`;
fs.writeFileSync('docs/'+task+'.md',contract);
const current=`## M10-T04 owner approval — ${timestamp}

**M10-T04_OWNER_APPROVAL_RECORDED. INITIAL DEALER AVATAR: CELESTINE — OWNER APPROVED** (noble_female). Approved preferred identity uses the unchanged zero-gameplay-RNG policy: exclude every occupied human/computer identity, including Sitting Out; if Celestine is seated choose the first eligible canonical roster ID; retain the assignment within the table/session. Formal direction: separate transparent240x320 PNG,3:4, identity-preserving black/deep-charcoal formalwear, white shirt, restrained gold accents. Immutable PA1 source/player portraits/provenance preserved.

**FORMAL CELESTINE DEALER ARTWORK NOT YET PRESENT — ASSET REQUIRED.** Expected public/characters/dealer/noble_female/formal.png; separately derived source art/source/dealers/noble_female/formal.png. No actual asset/descriptor or production activation. T04-B artwork integration BLOCKED by the absent approved PNG/provenance. Verification initially NOT RUN; receipts follow. Cumulative T04 repairs3/10 unchanged, approval checkpoint adds0. Earlier T04-A pending-selection statements are historical and superseded only for this explicit owner decision. [Approval contract](${task}.md).

WAITING FOR APPROVED CELESTINE FORMAL DEALER ASSET. M10-T05 NOT STARTED; MOTION NOT INSTALLED; ANIMATION NOT IMPLEMENTED; DEPLOYMENT NOT RUN.

`;
for(const p of ['docs/STATE.md','docs/PLAN.md'])fs.writeFileSync(p,current+fs.readFileSync(p,'utf8'));
fs.writeFileSync('README.md',current.replace('('+task+'.md)','(docs/'+task+'.md)')+fs.readFileSync('README.md','utf8'));
fs.appendFileSync('docs/M10_T04.md',`\n## Subsequent owner approval — ${timestamp}\n\nINITIAL DEALER AVATAR: CELESTINE — OWNER APPROVED (noble_female). This owner decision supersedes the historical identity-selection-pending statements above; T04-A history/evidence/repairs3/10 remain intact. Separate formal direction and exact pending paths are now recorded in the [owner approval contract](${task}.md). FORMAL CELESTINE DEALER ARTWORK NOT YET PRESENT — ASSET REQUIRED. No artwork/production configuration is created; existing fallback retained. T04-B awaits the approved separate PNG/provenance. ANIMATION NOT IMPLEMENTED; T05/Motion/deployment remain unstarted.\n`);
fs.appendFileSync('docs/DEVELOPMENT_LOG.md',`\n## ${timestamp} — M10-T04 owner approval baseline and asset prerequisite\n\nMain/${baseline}=origin/main=live remote,0/0,CLEAN/untracked0. Required authorities and T04-A contract/source/tests read; all incoming tracked files hashed before changes. Explicit owner decision approves Celestine/noble_female and formal outfit direction, with normal main commit/push authorized. Actual asset inventory has26 files:12 PA1 sources,12 player portraits,2 existing production/audit manifests; no formal Dealer candidate at either separate planned path. Record the precise path and pending manifest with null artwork hash/provenance, preserve stronger occupied-seat exclusion, and stop T04-B artwork integration. No source/tests/assets/dependencies/settings changes. Scope files: README, STATE, PLAN, DEVELOPMENT_LOG, LAB_MANUAL, M10_T04, new owner-approval contract and its evidence. Verification/review initially NOT RUN. T04 repairs3/10 unchanged;0 added.\n`);
fs.appendFileSync('docs/LAB_MANUAL.md',`\n## M10-T04 owner approval: direction is not asset evidence\n\nCelestine is owner-approved as the preferred Dealer identity and her separate formal variant has an approved outfit direction. Neither establishes that the finished PNG exists, decodes, preserves identity or has traceable derivation rights. A pending manifest records null artwork hash/provenance rather than inventing them. Protect the accepted PA1 original/player portrait, retain the generic fallback, then wait for a separately approved formal asset before T04-B integration. Identity occupancy includes Sitting Out even though funded participation determines who receives cards. This documentation checkpoint changes neither concept in gameplay.\n`);
console.log(JSON.stringify({timestamp,baseline,files:files.length,assetFiles:assetFiles.length,task,status:'OWNER_APPROVAL_RECORDED_ART_REQUIRED'}));
