const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),Module=require('node:module'),ts=require('typescript'),assert=require('node:assert/strict');
const dir='docs/M10_T04_OWNER_APPROVAL_EVIDENCE',baseline=JSON.parse(fs.readFileSync(dir+'/before.json')).baseline;
const stamp=()=>cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim();
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
// Transpile the exact current TypeScript modules in memory, without changing source or installing dependencies.
const load=(path,dependency)=>{const m=new Module(path);m.require=p=>{assert.equal(p,'./characters.js');return dependency;};m._compile(ts.transpileModule(fs.readFileSync(path,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,path);return m.exports;};
const chars=load('src/presentation/characters.ts'),dealer=load('src/presentation/dealerPresentation.ts',chars),rows=[];
assert.equal(chars.characters.find(c=>c.id==='noble_female').name,'Celestine');
const seats=[[4],[3,4],[3,4,6],[1,3,4,6],[1,3,4,5,6],[1,2,3,4,5,6],[1,2,3,4,5,6,7]];
const firstFree=['elf_male','elf_female','knight_male','knight_female','mage_male','mage_female','noble_male'];
const oldRandom=Math.random,oldEntropy=crypto.webcrypto.getRandomValues;let entropyCalls=0;
Math.random=()=>{entropyCalls++;throw Error('Unexpected random selection');};crypto.webcrypto.getRandomValues=()=>{entropyCalls++;throw Error('Unexpected entropy selection');};
try{for(let i=0;i<7;i++){
 const guests=seats[i].filter(n=>n!==4),eligible=dealer.createDealerTableIdentity(guests,()=>0,'knight_male','noble_female');
 assert.equal(eligible.characterId,'noble_female');assert.deepEqual(eligible.lineup,chars.createCharacterLineup(guests,()=>0,'knight_male'));
 const collision=dealer.createDealerTableIdentity(guests,()=>0,'noble_female','noble_female');assert.equal(collision.characterId,firstFree[i]);
 const ids=[collision.lineup.human,...Object.values(collision.lineup.guests)];assert.equal(ids.length,i+1);assert(!ids.includes(collision.characterId));
 for(const c of chars.characters)assert.equal(dealer.changeDealerTableHuman(eligible,c.id).characterId,'noble_female');
 rows.push({count:i+1,unseatedPreferred:eligible.characterId,seatedCelestineFallback:collision.characterId,expectedLiteralFallback:firstFree[i],playerCount:ids.length});
 }assert.equal(dealer.assignDealerIdentity({human:'knight_male',guests:{1:'noble_female',3:'elf_male'}},'noble_female'),'elf_female');assert.equal(entropyCalls,0);
}finally{Math.random=oldRandom;crypto.webcrypto.getRandomValues=oldEntropy;}
const manifest=JSON.parse(fs.readFileSync(dir+'/approved-direction.json'));
assert.equal(manifest.identity.characterId,'noble_female');assert.equal(manifest.role,'dealer');assert.equal(manifest.variant,'formal');assert.equal(manifest.format,'png');assert.equal(manifest.transparent,true);assert.equal(manifest.width,240);assert.equal(manifest.height,320);assert.equal(manifest.aspectRatio,'3:4');assert.equal(manifest.artworkPresent,false);assert.equal(manifest.sha256,null);assert.equal(manifest.derivedProvenance,null);assert.equal(manifest.approvedFinalArtwork,false);assert.equal(manifest.runtimeDescriptorRegistered,false);
assert.equal(manifest.plannedProduction,'public/characters/dealer/noble_female/formal.png');assert.equal(manifest.plannedDerivedSource,'art/source/dealers/noble_female/formal.png');
for(const p of [manifest.plannedProduction,manifest.plannedDerivedSource])assert.equal(fs.existsSync(p),false);
for(const v of [manifest.original,manifest.canonicalPlayer])assert.equal(hash(fs.readFileSync(v.path)),v.sha256);
assert(fs.existsSync(manifest.originalProvenanceReference));assert.deepEqual(manifest.presentationStates,dealer.DEALER_PRESENTATION_STATES);
const history=[];
for(const p of ['README.md','docs/STATE.md','docs/PLAN.md','docs/M10_T04.md','docs/DEVELOPMENT_LOG.md','docs/LAB_MANUAL.md']){
 const old=cp.execFileSync('git',['show',baseline+':'+p],{maxBuffer:32*1024*1024}),now=fs.readFileSync(p),kind=['README.md','docs/STATE.md','docs/PLAN.md'].includes(p)?'prefix-added':'suffix-added';
 assert(kind==='prefix-added'?now.subarray(now.length-old.length).equals(old):now.subarray(0,old.length).equals(old),p+' historical bytes changed');history.push({path:p,existingBytesPreserved:true,method:kind});
}
const doc=fs.readFileSync('docs/M10_T04_OWNER_APPROVAL.md','utf8'),links=[...doc.matchAll(/\]\(([^)]+)\)/g)].map(m=>m[1]);for(const p of links)assert(fs.existsSync('docs/'+p),'Missing contract link: '+p);
const r={timestamp:stamp(),status:'PASS',exitCode:0,method:'Exact TypeScript source transpiled in memory; explicit independent first-free collision fixtures for counts1-7; no source/test/tool/dependency changes',rows,guestCollisionExpected:'elf_female',entropyCalls,gameplayCommandsIssued:0,historyPreservation:history,contractLinks:links,manifestValidation:'PASS',sourceHashes:['src/presentation/characters.ts','src/presentation/dealerPresentation.ts'].map(path=>({path,sha256:hash(fs.readFileSync(path))}))};
fs.writeFileSync(dir+'/celestine-contract-probe.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify({timestamp:r.timestamp,status:r.status,counts:rows.length,entropyCalls,historyFiles:history.length,links:links.length}));
