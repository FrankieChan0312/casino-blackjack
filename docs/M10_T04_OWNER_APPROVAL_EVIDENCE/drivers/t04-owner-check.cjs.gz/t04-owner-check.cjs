const fs=require('node:fs'),cp=require('node:child_process');
const dir='docs/M10_T04_OWNER_APPROVAL_EVIDENCE',kind=process.argv[2];
const commands={identity:'& npm.cmd test -- tests/m10/dealerPresentation.test.tsx; exit $LASTEXITCODE',assets:'& node scripts/verify-character-assets.mjs; exit $LASTEXITCODE'};
if(!commands[kind])throw Error('Unknown check');
const stamp=()=>cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim();
const fd=fs.openSync(dir+'/owner-'+kind+'.log','wx'),start=stamp();
const child=cp.spawnSync('powershell.exe',['-NoProfile','-Command',commands[kind]],{stdio:['ignore',fd,fd]});fs.closeSync(fd);
const record={start,end:stamp(),command:commands[kind],exitCode:child.status,status:child.error?'BLOCKED':child.status===0?'PASS':'FAIL',error:child.error?String(child.error):null};
fs.writeFileSync(dir+'/owner-'+kind+'.json',JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify(record));console.log(fs.readFileSync(dir+'/owner-'+kind+'.log','utf8').split(/\r?\n/).slice(-16).join('\n'));process.exitCode=child.status??1;
