# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m10\initialDeal.spec.ts >> [T06-B02-4-1280] checkpoint captures actual start/first/second/settled
- Location: tests\browser\m10\initialDeal.spec.ts:58:103

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-deal-target="round-1/seat-1:0"]')
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('[data-deal-target="round-1/seat-1:0"]') with timeout 5000ms
  - waiting for locator('[data-deal-target="round-1/seat-1:0"]')
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- main [ref=e3]:
  - link "Skip to your hand and actions" [ref=e4] [cursor=pointer]:
    - /url: "#player-decisions"
  - region "Blackjack game scene" [ref=e5]:
    - generic [ref=e6]:
      - heading "Casino Blackjack" [level=1] [ref=e8]
      - paragraph [ref=e9]: Simulation credits only — no real-money gambling.Credits have no redemption value.
    - generic [ref=e10]:
      - region "Blackjack table" [ref=e11]:
        - region "Dealer" [ref=e12]:
          - 'img "Dealer: Celestine" [ref=e13]'
          - heading "Dealer" [level=2] [ref=e14]
          - group "Dealer hand" [ref=e15]:
            - generic [ref=e16]:
              - img "4 of clubs" [ref=e18]:
                - generic [ref=e19]:
                  - text: "4"
                  - generic [aria-hidden] [ref=e20]: ♣
                - generic [aria-hidden] [ref=e21]: ♣
                - generic [aria-hidden] [ref=e22]: "4"
              - img "Hidden dealer card" [ref=e23]: ◆
            - paragraph [ref=e24]: "Visible total: 4"
            - paragraph [ref=e25]: Hole card hidden
          - group "Shoe and deal origin" [ref=e26]:
            - paragraph [ref=e28]:
              - text: Shoe · Deal origin
              - generic [ref=e29]: 6 decks
          - paragraph [ref=e30]:
            - text: BLACKJACK PAYS 3:2
            - generic [ref=e31]: DEALER STANDS ON ALL 17
        - generic [ref=e32]:
          - region "Seat 1" [ref=e33]:
            - generic [ref=e34]:
              - generic [ref=e35]:
                - 'img "Computer guest: Caelan, Male Elf" [ref=e36]'
                - generic [ref=e37]:
                  - heading "Caelan" [level=2] [ref=e38]
                  - paragraph [ref=e39]: Male Elf
                  - paragraph [ref=e40]: Seat 1 · Computer
              - group [ref=e41]:
                - article "Hand A" [ref=e42]:
                  - generic [ref=e43]:
                    - img "J of hearts" [ref=e44]:
                      - generic [ref=e45]:
                        - text: J
                        - generic [aria-hidden] [ref=e46]: ♥
                      - generic [aria-hidden] [ref=e47]: ♥
                      - generic [aria-hidden] [ref=e48]: J
                    - img "5 of diamonds" [ref=e49]:
                      - generic [ref=e50]:
                        - text: "5"
                        - generic [aria-hidden] [ref=e51]: ♦
                      - generic [aria-hidden] [ref=e52]: ♦
                      - generic [aria-hidden] [ref=e53]: "5"
                    - img "2 of clubs" [ref=e54]:
                      - generic [ref=e55]:
                        - text: "2"
                        - generic [aria-hidden] [ref=e56]: ♣
                      - generic [aria-hidden] [ref=e57]: ♣
                      - generic [aria-hidden] [ref=e58]: "2"
                  - generic [ref=e59]:
                    - paragraph [ref=e60]: "17"
                    - paragraph [ref=e61]: Decisions complete
                    - paragraph [ref=e62]: "MAIN: 25 credits"
          - region "Seat 3" [ref=e63]:
            - generic [ref=e64]:
              - generic [ref=e65]:
                - 'img "Computer guest: Elaria, Female Elf" [ref=e66]'
                - generic [ref=e67]:
                  - heading "Elaria" [level=2] [ref=e68]
                  - paragraph [ref=e69]: Female Elf
                  - paragraph [ref=e70]: Seat 3 · Computer
              - group [ref=e71]:
                - article "Hand A" [ref=e72]:
                  - generic [ref=e73]:
                    - img "A of hearts" [ref=e74]:
                      - generic [ref=e75]:
                        - text: A
                        - generic [aria-hidden] [ref=e76]: ♥
                      - generic [aria-hidden] [ref=e77]: ♥
                      - generic [aria-hidden] [ref=e78]: A
                    - img "8 of spades" [ref=e79]:
                      - generic [ref=e80]:
                        - text: "8"
                        - generic [aria-hidden] [ref=e81]: ♠
                      - generic [aria-hidden] [ref=e82]: ♠
                      - generic [aria-hidden] [ref=e83]: "8"
                  - generic [ref=e84]:
                    - paragraph [ref=e85]: "19"
                    - paragraph [ref=e86]: Decisions complete
                    - paragraph [ref=e87]: "MAIN: 25 credits"
          - region "Seat 4" [active] [ref=e88]:
            - group "Your player HUD" [ref=e89]:
              - generic [ref=e90]:
                - generic [ref=e91]:
                  - 'img "Your avatar: Roland, Male Human Knight" [ref=e92]'
                  - generic [ref=e93]:
                    - paragraph [ref=e94]: YOU
                    - heading "Roland" [level=2] [ref=e95]: ▸ Roland
                    - paragraph [ref=e96]: Male Human Knight
                    - paragraph [ref=e97]: Seat 4 · You · Human
                - paragraph [ref=e98]: "MAIN: 100 credits"
              - article "Hand A" [ref=e100]:
                - generic [ref=e101]:
                  - heading "Hand A · Current hand" [level=3] [ref=e102]
                  - generic [ref=e103]: ACTIVE
                - generic [ref=e104]:
                  - img "5 of hearts" [ref=e105]:
                    - generic [ref=e106]:
                      - text: "5"
                      - generic [aria-hidden] [ref=e107]: ♥
                    - generic [aria-hidden] [ref=e108]: ♥
                    - generic [aria-hidden] [ref=e109]: "5"
                  - img "4 of spades" [ref=e110]:
                    - generic [ref=e111]:
                      - text: "4"
                      - generic [aria-hidden] [ref=e112]: ♠
                    - generic [aria-hidden] [ref=e113]: ♠
                    - generic [aria-hidden] [ref=e114]: "4"
                - generic [ref=e115]:
                  - paragraph [ref=e116]:
                    - text: "Total:"
                    - strong [ref=e117]: "9"
                  - paragraph [ref=e118]: "Wager: 100 credits"
                  - paragraph [ref=e119]: Playing
          - region "Seat 6" [ref=e120]:
            - generic [ref=e121]:
              - generic [ref=e122]:
                - 'img "Computer guest: Seraphine, Female Human Knight" [ref=e123]'
                - generic [ref=e124]:
                  - heading "Seraphine" [level=2] [ref=e125]
                  - paragraph [ref=e126]: Female Human Knight
                  - paragraph [ref=e127]: Seat 6 · Computer
              - group [ref=e128]:
                - article "Hand A" [ref=e129]:
                  - generic [ref=e130]:
                    - img "9 of hearts" [ref=e131]:
                      - generic [ref=e132]:
                        - text: "9"
                        - generic [aria-hidden] [ref=e133]: ♥
                      - generic [aria-hidden] [ref=e134]: ♥
                      - generic [aria-hidden] [ref=e135]: "9"
                    - img "6 of diamonds" [ref=e136]:
                      - generic [ref=e137]:
                        - text: "6"
                        - generic [aria-hidden] [ref=e138]: ♦
                      - generic [aria-hidden] [ref=e139]: ♦
                      - generic [aria-hidden] [ref=e140]: "6"
                  - generic [ref=e141]:
                    - paragraph [ref=e142]: "15"
                    - paragraph [ref=e143]: Playing
                    - paragraph [ref=e144]: "MAIN: 25 credits"
      - region "Your gameplay controls" [ref=e145]:
        - generic [ref=e146]:
          - status [ref=e147]: Your turn
          - generic [ref=e148]: · Hand A
        - region "Primary actions" [ref=e149]:
          - generic [ref=e150]:
            - button "Hit" [ref=e151] [cursor=pointer]
            - button "Stand" [ref=e152] [cursor=pointer]
            - button "Double" [ref=e153] [cursor=pointer]
            - button "Split" [disabled] [ref=e154]
            - button "Surrender" [ref=e155] [cursor=pointer]
          - group [ref=e156]:
            - generic "Action guidance · Unavailable actions explained" [ref=e157] [cursor=pointer]
        - region "Your credits" [ref=e158]:
          - heading "Credits" [level=2] [ref=e159]
          - generic [ref=e160]:
            - generic [ref=e161]:
              - term [ref=e162]: Available
              - definition [ref=e163]: "900"
            - generic [ref=e164]:
              - term [ref=e165]: Reserved / current exposure
              - definition [ref=e166]: "100"
            - generic [ref=e167]:
              - term [ref=e168]: Pending return
              - definition [ref=e169]: "0"
    - paragraph [ref=e170]: Existing 6-deck shoe continues · Computer guests play with their own simulation credits.
  - complementary "Table preferences and demo tools" [ref=e171]:
    - generic [ref=e172]:
      - paragraph [ref=e173]: 4 players · 1 human · 3 computer guests
      - button "New table · reset to 1000 credits" [disabled] [ref=e174]
    - group [ref=e175]:
      - generic "Change Character · Roland" [ref=e176] [cursor=pointer]
      - option "Caelan · Male Elf"
      - option "Elaria · Female Elf"
      - option "Roland · Male Human Knight" [selected]
      - option "Seraphine · Female Human Knight"
      - option "Alaric · Male Mage"
      - option "Nyra · Female Mage"
      - option "Lucien · Male Noble"
      - option "Celestine · Female Noble · Dealer (reserved for this table)" [disabled]
      - option "Garruk · Male Half-Orc Warrior"
      - option "Vesha · Female Half-Orc Warrior"
      - option "Borin · Male Dwarf"
      - option "Brynja · Female Dwarf"
    - group [ref=e177]:
      - generic "Developer / demo tools" [ref=e178] [cursor=pointer]
      - option "Classic Blackjack" [selected]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { writeFileSync, mkdirSync } from 'node:fs';
  3   | import { Buffer } from 'node:buffer';
  4   | 
  5   | test.use({ reducedMotion: 'no-preference' });
  6   | const seats: Record<number, number[]> = { 1: [4], 4: [1,3,4,6], 7: [1,2,3,4,5,6,7] };
  7   | type Trace = { arrivals: string[]; flights: string[]; duplicate: boolean; overlap: boolean; started: number; finished: number; paused: boolean; checkpoints: string[]; interruptions: string[]; pauseStates: string[][] };
  8   | async function setup(page: Page, count: number) {
  9   |   await page.goto('/?fixture=player-setup');
  10  |   await page.getByLabel('Total players', { exact: true }).selectOption(String(count));
  11  |   await page.getByRole('button', { name: 'Start table', exact: true }).click();
  12  |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  13  | }
  14  | async function observe(page: Page, checkpoints: string[] = []) {
  15  |   await page.evaluate(checkpoints => {
  16  |     const trace: Trace = { arrivals: [], flights: [], duplicate: false, overlap: false, started: performance.now(), finished: 0, paused: false, checkpoints, interruptions: [], pauseStates: [] };
  17  |     (window as unknown as { dealTrace: Trace }).dealTrace = trace;
  18  |     window.addEventListener('resize', () => trace.interruptions.push('resize'));
  19  |     document.addEventListener('visibilitychange', () => trace.interruptions.push(`visibility:${document.hidden}`));
  20  |     new MutationObserver(records => {
  21  |       for (const record of records) for (const node of record.addedNodes) if (node instanceof HTMLElement && node.dataset.initialDealFlight) {
  22  |         const target = node.dataset.dealTarget!;
  23  |         if (trace.flights.includes(target)) trace.duplicate = true;
  24  |         trace.flights.push(target);
  25  |         trace.overlap ||= document.querySelectorAll('[data-initial-deal-flight]').length > 1;
  26  |         if (trace.checkpoints.includes(target)) {
  27  |           const animations = node.getAnimations({ subtree: true }); animations.forEach(animation => animation.pause()); trace.paused = true;
  28  |           trace.pauseStates.push(animations.map(animation => animation.playState));
  29  |         }
  30  |       }
  31  |       for (const element of document.querySelectorAll<HTMLElement>('[data-card-slot][data-deal-visible="true"]')) {
  32  |         const key = element.dataset.cardSlot!;
  33  |         if (Number(key.slice(key.lastIndexOf(':') + 1)) < 2 && !trace.arrivals.includes(key)) trace.arrivals.push(key);
  34  |       }
  35  |       if (document.querySelector('[data-initial-deal-running="false"]') && trace.flights.length) trace.finished = performance.now();
  36  |     }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-deal-visible','data-initial-deal-running'] });
  37  |   }, checkpoints);
  38  | }
  39  | const trace = (page: Page) => page.evaluate(() => (window as unknown as { dealTrace: Trace }).dealTrace);
  40  | for (const count of [1,4,7]) test(`[T06-B01-${count}] real FULL_MOTION two-pass order, one clone, no premature arrival`, async ({ page }, info) => {
  41  |   await setup(page, count); await observe(page);
  42  |   const dealer = await page.locator('[data-dealer-character]').getAttribute('data-dealer-character');
  43  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  44  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  45  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-presentation-state', 'DEALING');
  46  |   await expect(page.locator('[data-card-slot][data-deal-visible="true"]')).toHaveCount(0);
  47  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  48  |   const result = await trace(page), order = [0,1].flatMap(index => [...seats[count].map(seat => `round-1/seat-${seat}:${index}`), `dealer:${index}`]);
  49  |   expect(result.flights).toEqual(order); expect(result.arrivals).toEqual(order);
  50  |   expect(result.duplicate).toBe(false); expect(result.overlap).toBe(false);
  51  |   expect(result.finished - result.started).toBeLessThan(4000);
  52  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  53  |   await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toHaveCount(1);
  54  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  55  |   writeFileSync(info.outputPath('sequence.json'), JSON.stringify(result, null, 2));
  56  | });
  57  | 
  58  | for (const [count,width,height] of [[1,1280,900],[4,1280,900],[7,1280,900],[7,768,1024],[7,320,720]]) test(`[T06-B02-${count}-${width}] checkpoint captures actual start/first/second/settled`, async ({ page }, info) => {
  59  |   const root = 'docs/M10_T06_EVIDENCE/screenshots'; mkdirSync(root, { recursive: true });
  60  |     await page.setViewportSize({ width, height }); await setup(page, count);
  61  |     const checkpoints = count === 1 ? ['round-1/seat-4:0','dealer:0','round-1/seat-4:1','dealer:1']
  62  |       : [`round-1/seat-${seats[count][0]}:0`, `round-1/seat-${seats[count][Math.floor(count/2)]}:0`, `round-1/seat-${seats[count][0]}:1`, `round-1/seat-${seats[count][Math.floor(count/2)]}:1`];
  63  |     await observe(page, checkpoints); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  64  |     for (const [index,target] of checkpoints.entries()) {
  65  |       await expect.poll(async () => (await trace(page)).paused && await page.locator(`[data-deal-target="${target}"]`).count() === 1).toBe(true);
  66  |       const before = await trace(page);
  67  |       const cdp = await page.context().newCDPSession(page);
  68  |       const clip = await page.evaluate(() => ({ x: 0, y: 0, width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight, scale: 1 }));
  69  |       const capture = await cdp.send('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: true, clip });
  70  |       await cdp.detach();
  71  |       writeFileSync(`${root}/${count}-${width}-${['start','mid-first-pass','end-first-pass','mid-second-pass'][index]}.png`, Buffer.from(capture.data, 'base64'));
  72  |       writeFileSync(info.outputPath(`capture-${index}.json`), JSON.stringify({ before, after: await trace(page) }, null, 2));
> 73  |       await expect(page.locator(`[data-deal-target="${target}"]`)).toHaveCount(1);
      |                                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  74  |       await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  75  |       await page.evaluate(() => {
  76  |         const trace = (window as unknown as { dealTrace: Trace }).dealTrace;
  77  |         trace.paused = false; document.querySelectorAll<HTMLElement>('[data-initial-deal-flight]').forEach(element => element.getAnimations({ subtree: true }).forEach(animation => animation.play()));
  78  |       });
  79  |     }
  80  |     await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  81  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  82  |     await page.screenshot({ path: `${root}/${count}-${width}-settled.png`, fullPage: true });
  83  |     writeFileSync(`${root}/${count}-${width}-sequence.json`, JSON.stringify(await trace(page), null, 2));
  84  | });
  85  | 
  86  | test('[T06-B03] skip/keyboard legal action settles before dispatch; new round/new table never replay stale cards', async ({ page }) => {
  87  |   await page.goto('/?fixture=player-split'); await observe(page);
  88  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  89  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  90  |   await page.getByRole('button', { name: 'Split', exact: true }).focus(); await page.keyboard.press('Enter');
  91  |   await expect(page.locator('#player-hand article')).toHaveCount(2); await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  92  |   await expect(page.locator('#player-hand [data-deal-visible="false"]')).toHaveCount(0);
  93  |   for (let index = 0; index < 2; index++) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  94  |   const dealer = await page.locator('.dealer-zone').getAttribute('data-dealer-character');
  95  |   await page.getByRole('button', { name: /^Repeat Bet/ }).click();
  96  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  97  |   await page.getByRole('button', { name: 'Skip animations', exact: true }).click();
  98  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  99  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  100 |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  101 |   if (await page.getByRole('button', { name: 'Decline', exact: true }).count()) await page.getByRole('button', { name: 'Decline', exact: true }).click();
  102 |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  103 |   await page.getByRole('button', { name: 'New table · reset to 1000 credits', exact: true }).click();
  104 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0); await expect(page.locator('[data-card-slot]')).toHaveCount(0);
  105 | });
  106 | 
  107 | test('[T06-B04] resize/background/text200 settle safely, keep native focus and bounded geometry', async ({ page }) => {
  108 |   await setup(page, 7); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  109 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(1);
  110 |   await page.setViewportSize({ width: 768, height: 1024 });
  111 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  112 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  113 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  114 |   await page.goto('/?fixture=player-split'); await page.addStyleTag({ content: 'html {font-size: 200%}' });
  115 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  116 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange')); });
  117 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  118 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  119 |   const stand = page.getByRole('button', { name: 'Stand', exact: true }); await stand.focus(); await expect(stand).toBeFocused();
  120 |   const box = await stand.boundingBox(); expect(box!.width).toBeGreaterThanOrEqual(44); expect(box!.height).toBeGreaterThanOrEqual(44);
  121 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  122 | });
  123 | 
  124 | test('[T06-B05] reduced preference settles without flights; IMMEDIATE uses the identical authoritative result', async ({ page }) => {
  125 |   await page.emulateMedia({ reducedMotion: 'reduce' }); await setup(page, 7); await observe(page);
  126 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  127 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  128 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  129 |   expect((await trace(page)).flights).toEqual([]);
  130 |   const result = await page.evaluate(async () => {
  131 |     const fixtureUrl = '/tests/browser/fixtures.ts', providerUrl = '/src/ui/PresentationProvider.tsx';
  132 |     const { createFixtureController } = await import(fixtureUrl), { createPresentationRuntime, connectPresentation } = await import(providerUrl);
  133 |     const receipts = [];
  134 |     for (const mode of ['IMMEDIATE','REDUCED_MOTION']) {
  135 |       const controller = createFixtureController('player'), runtime = createPresentationRuntime();
  136 |       const disconnect = connectPresentation(controller.presentation, runtime, mode);
  137 |       controller.dispatch({ type: 'DEAL', amount: 200 });
  138 |       receipts.push({ authority: controller.getSnapshot(), projection: runtime.initialDeal.getSnapshot().pending, active: runtime.timeline.getSnapshot().activeId });
  139 |       disconnect();
  140 |     }
  141 |     return receipts;
  142 |   });
  143 |   expect(result[0]).toEqual(result[1]); expect(result[0].active).toBeNull(); expect(result[0].projection).toEqual([]);
  144 |   await page.screenshot({ path: 'docs/M10_T06_EVIDENCE/reduced-seven-settled.png', fullPage: true });
  145 | });
  146 | 
  147 | test('[T06-B06] real Provider unmount cancels the active flight, leaves authority and late callbacks unchanged', async ({ page }) => {
  148 |   await page.goto('/?fixture=player');
  149 |   const result = await page.evaluate(async () => {
  150 |     const providerUrl = '/src/ui/PresentationProvider.tsx', cardsUrl = '/src/ui/Cards.tsx', fixtureUrl = '/tests/browser/fixtures.ts';
  151 |     const reactUrl = '/node_modules/.vite/deps/react.js', rootUrl = '/node_modules/.vite/deps/react-dom_client.js';
  152 |     const { PresentationProvider, usePresentationAnchor, usePresentationRuntime } = await import(providerUrl), { Cards, HiddenDealerCard } = await import(cardsUrl);
  153 |     const { createFixtureController } = await import(fixtureUrl), { default: React } = await import(reactUrl), { default: ReactDOM } = await import(rootUrl);
  154 |     const controller = createFixtureController('player-split'); controller.dispatch({ type: 'DEAL', amount: 200 });
  155 |     const authority = JSON.stringify(controller.getSnapshot()), hand = controller.getSnapshot().round.seats.find((seat: { seatNumber: number }) => seat.seatNumber === 4).hands[0];
  156 |     const host = document.createElement('div'); document.body.append(host); const root = ReactDOM.createRoot(host);
  157 |     let runtime: ReturnType<typeof usePresentationRuntime>;
  158 |     function Probe() {
  159 |       runtime = usePresentationRuntime(); const origin = usePresentationAnchor('deal-origin');
  160 |       return React.createElement('div', null, React.createElement('div', { ref: origin }, 'Shoe'), React.createElement(Cards, { cards: hand.cards, ownerId: hand.handId }), React.createElement(HiddenDealerCard));
  161 |     }
  162 |     const started = new Promise<void>(resolve => {
  163 |       const observer = new MutationObserver(() => { if (document.querySelector('[data-initial-deal-flight]')) { observer.disconnect(); resolve(); } });
  164 |       observer.observe(document.body, { subtree: true, childList: true });
  165 |     });
  166 |     root.render(React.createElement(PresentationProvider, { feed: controller.presentation }, React.createElement(Probe))); await started;
  167 |     const active = runtime!.timeline.getSnapshot().activeId; root.unmount(); host.remove();
  168 |     await Promise.resolve();
  169 |     return { active, remaining: document.querySelectorAll('[data-initial-deal-flight]').length, snapshot: runtime!.timeline.getSnapshot(), same: JSON.stringify(controller.getSnapshot()) === authority };
  170 |   });
  171 |   expect(result.active).not.toBeNull(); expect(result.remaining).toBe(0); expect(result.snapshot).toMatchObject({ activeId: null, pending: 0 }); expect(result.same).toBe(true);
  172 | });
  173 | 
```