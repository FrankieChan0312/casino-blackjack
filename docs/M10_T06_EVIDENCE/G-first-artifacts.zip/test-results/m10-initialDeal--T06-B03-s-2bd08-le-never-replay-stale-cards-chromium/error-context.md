# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m10\initialDeal.spec.ts >> [T06-B03] skip/keyboard legal action settles before dispatch; new round/new table never replay stale cards
- Location: tests\browser\m10\initialDeal.spec.ts:75:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Repeat Bet', exact: true })

```

# Page snapshot

```yaml
- main [ref=e3]:
  - link "Skip to your hand and actions" [ref=e4] [cursor=pointer]:
    - /url: "#player-decisions"
  - region "Blackjack game scene" [ref=e5]:
    - generic [ref=e6]:
      - heading "Casino Blackjack" [level=1] [ref=e8]
      - paragraph [ref=e9]: Simulation credits only — no real-money gambling.Credits have no redemption value.
    - generic [ref=e10]:
      - region "Blackjack table" [ref=e11]:
        - region "Dealer" [ref=e12]:
          - 'img "Dealer: Celestine" [ref=e13]'
          - heading "Dealer" [level=2] [ref=e14]
          - group "Dealer hand" [ref=e15]:
            - generic [ref=e17]:
              - img "10 of clubs" [ref=e18]:
                - generic [ref=e19]:
                  - text: "10"
                  - generic [aria-hidden] [ref=e20]: ♣
                - generic [aria-hidden] [ref=e21]: ♣
                - generic [aria-hidden] [ref=e22]: "10"
              - img "9 of diamonds" [ref=e23]:
                - generic [ref=e24]:
                  - text: "9"
                  - generic [aria-hidden] [ref=e25]: ♦
                - generic [aria-hidden] [ref=e26]: ♦
                - generic [aria-hidden] [ref=e27]: "9"
            - paragraph [ref=e28]: "Total: 19"
            - paragraph [ref=e29]: Dealer complete
          - group "Shoe and deal origin" [ref=e30]:
            - paragraph [ref=e32]:
              - text: Shoe · Deal origin
              - generic [ref=e33]: 6 decks
          - paragraph [ref=e34]:
            - text: BLACKJACK PAYS 3:2
            - generic [ref=e35]: DEALER STANDS ON ALL 17
        - generic [ref=e36]:
          - region "Seat 1" [ref=e37]:
            - generic [ref=e38]:
              - generic [ref=e39]:
                - 'img "Computer guest: Caelan, Male Elf" [ref=e40]'
                - generic [ref=e41]:
                  - heading "Caelan" [level=2] [ref=e42]
                  - paragraph [ref=e43]: Male Elf
                  - paragraph [ref=e44]: Seat 1 · Computer
              - group [ref=e45]:
                - article "Hand A" [ref=e46]:
                  - generic [ref=e47]:
                    - img "10 of clubs" [ref=e48]:
                      - generic [ref=e49]:
                        - text: "10"
                        - generic [aria-hidden] [ref=e50]: ♣
                      - generic [aria-hidden] [ref=e51]: ♣
                      - generic [aria-hidden] [ref=e52]: "10"
                    - img "7 of diamonds" [ref=e53]:
                      - generic [ref=e54]:
                        - text: "7"
                        - generic [aria-hidden] [ref=e55]: ♦
                      - generic [aria-hidden] [ref=e56]: ♦
                      - generic [aria-hidden] [ref=e57]: "7"
                  - generic [ref=e58]:
                    - paragraph [ref=e59]: "17"
                    - paragraph [ref=e60]: Loss
                    - paragraph [ref=e61]: "MAIN: 25 credits"
          - region "Seat 3" [ref=e62]:
            - generic [ref=e63]:
              - generic [ref=e64]:
                - 'img "Computer guest: Elaria, Female Elf" [ref=e65]'
                - generic [ref=e66]:
                  - heading "Elaria" [level=2] [ref=e67]
                  - paragraph [ref=e68]: Female Elf
                  - paragraph [ref=e69]: Seat 3 · Computer
              - group [ref=e70]:
                - article "Hand A" [ref=e71]:
                  - generic [ref=e72]:
                    - img "10 of diamonds" [ref=e73]:
                      - generic [ref=e74]:
                        - text: "10"
                        - generic [aria-hidden] [ref=e75]: ♦
                      - generic [aria-hidden] [ref=e76]: ♦
                      - generic [aria-hidden] [ref=e77]: "10"
                    - img "7 of hearts" [ref=e78]:
                      - generic [ref=e79]:
                        - text: "7"
                        - generic [aria-hidden] [ref=e80]: ♥
                      - generic [aria-hidden] [ref=e81]: ♥
                      - generic [aria-hidden] [ref=e82]: "7"
                  - generic [ref=e83]:
                    - paragraph [ref=e84]: "17"
                    - paragraph [ref=e85]: Loss
                    - paragraph [ref=e86]: "MAIN: 25 credits"
          - region "Seat 4" [ref=e87]:
            - group "Your player HUD" [ref=e88]:
              - generic [ref=e89]:
                - generic [ref=e90]:
                  - 'img "Your avatar: Roland, Male Human Knight" [ref=e91]'
                  - generic [ref=e92]:
                    - paragraph [ref=e93]: YOU
                    - heading "Roland" [level=2] [ref=e94]
                    - paragraph [ref=e95]: Male Human Knight
                    - paragraph [ref=e96]: Seat 4 · You · Human
                - paragraph [ref=e97]: "MAIN: 25 credits"
              - generic [ref=e98]:
                - article "Hand A" [ref=e99]:
                  - heading "Hand A" [level=3] [ref=e101]
                  - generic [ref=e102]:
                    - img "8 of hearts" [ref=e103]:
                      - generic [ref=e104]:
                        - text: "8"
                        - generic [aria-hidden] [ref=e105]: ♥
                      - generic [aria-hidden] [ref=e106]: ♥
                      - generic [aria-hidden] [ref=e107]: "8"
                    - img "2 of hearts" [ref=e108]:
                      - generic [ref=e109]:
                        - text: "2"
                        - generic [aria-hidden] [ref=e110]: ♥
                      - generic [aria-hidden] [ref=e111]: ♥
                      - generic [aria-hidden] [ref=e112]: "2"
                  - generic [ref=e113]:
                    - paragraph [ref=e114]:
                      - text: "Total:"
                      - strong [ref=e115]: "10"
                    - paragraph [ref=e116]: "Wager: 25 credits"
                    - paragraph [ref=e117]: Loss
                - article "Hand B" [ref=e118]:
                  - heading "Hand B" [level=3] [ref=e120]
                  - generic [ref=e121]:
                    - img "8 of spades" [ref=e122]:
                      - generic [ref=e123]:
                        - text: "8"
                        - generic [aria-hidden] [ref=e124]: ♠
                      - generic [aria-hidden] [ref=e125]: ♠
                      - generic [aria-hidden] [ref=e126]: "8"
                    - img "3 of spades" [ref=e127]:
                      - generic [ref=e128]:
                        - text: "3"
                        - generic [aria-hidden] [ref=e129]: ♠
                      - generic [aria-hidden] [ref=e130]: ♠
                      - generic [aria-hidden] [ref=e131]: "3"
                  - generic [ref=e132]:
                    - paragraph [ref=e133]:
                      - text: "Total:"
                      - strong [ref=e134]: "11"
                    - paragraph [ref=e135]: "Wager: 25 credits"
                    - paragraph [ref=e136]: Loss
          - region "Seat 6" [ref=e137]:
            - generic [ref=e138]:
              - generic [ref=e139]:
                - 'img "Computer guest: Seraphine, Female Human Knight" [ref=e140]'
                - generic [ref=e141]:
                  - heading "Seraphine" [level=2] [ref=e142]
                  - paragraph [ref=e143]: Female Human Knight
                  - paragraph [ref=e144]: Seat 6 · Computer
              - group [ref=e145]:
                - article "Hand A" [ref=e146]:
                  - generic [ref=e147]:
                    - img "10 of spades" [ref=e148]:
                      - generic [ref=e149]:
                        - text: "10"
                        - generic [aria-hidden] [ref=e150]: ♠
                      - generic [aria-hidden] [ref=e151]: ♠
                      - generic [aria-hidden] [ref=e152]: "10"
                    - img "7 of clubs" [ref=e153]:
                      - generic [ref=e154]:
                        - text: "7"
                        - generic [aria-hidden] [ref=e155]: ♣
                      - generic [aria-hidden] [ref=e156]: ♣
                      - generic [aria-hidden] [ref=e157]: "7"
                  - generic [ref=e158]:
                    - paragraph [ref=e159]: "17"
                    - paragraph [ref=e160]: Loss
                    - paragraph [ref=e161]: "MAIN: 25 credits"
      - region "Your gameplay controls" [ref=e162]:
        - status [ref=e164]: Round complete
        - region "Your round result" [active] [ref=e165]:
          - paragraph [ref=e166]: "Net result: -50 credits"
          - generic [ref=e167]:
            - button "Deal Again" [ref=e168] [cursor=pointer]
            - button "Repeat Bet · 25 credits" [ref=e169] [cursor=pointer]
          - group [ref=e170]:
            - generic "Wager result details" [ref=e171] [cursor=pointer]
        - region "Your credits" [ref=e172]:
          - heading "Credits" [level=2] [ref=e173]
          - generic [ref=e174]:
            - generic [ref=e175]:
              - term [ref=e176]: Available
              - definition [ref=e177]: "950"
            - generic [ref=e178]:
              - term [ref=e179]: Reserved / current exposure
              - definition [ref=e180]: "0"
            - generic [ref=e181]:
              - term [ref=e182]: Pending return
              - definition [ref=e183]: "0"
    - paragraph [ref=e184]: Existing 6-deck shoe continues · Computer guests play with their own simulation credits.
  - complementary "Table preferences and demo tools" [ref=e185]:
    - generic [ref=e186]:
      - paragraph [ref=e187]: 4 players · 1 human · 3 computer guests
      - button "New table · reset to 1000 credits" [ref=e188] [cursor=pointer]
    - group [ref=e189]:
      - generic "Change Character · Roland" [ref=e190] [cursor=pointer]
      - option "Caelan · Male Elf"
      - option "Elaria · Female Elf"
      - option "Roland · Male Human Knight" [selected]
      - option "Seraphine · Female Human Knight"
      - option "Alaric · Male Mage"
      - option "Nyra · Female Mage"
      - option "Lucien · Male Noble"
      - option "Celestine · Female Noble · Dealer (reserved for this table)" [disabled]
      - option "Garruk · Male Half-Orc Warrior"
      - option "Vesha · Female Half-Orc Warrior"
      - option "Borin · Male Dwarf"
      - option "Brynja · Female Dwarf"
    - group [ref=e191]:
      - generic "Developer / demo tools" [ref=e192] [cursor=pointer]
      - option "Classic Blackjack (v1.2 · Re-split Aces)"
      - option "Five-Card Charlie Demo (v1.2 · Re-split Aces)"
      - option "Classic Blackjack" [selected]
      - option "Five-Card Charlie Demo"
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { writeFileSync, mkdirSync } from 'node:fs';
  3   | 
  4   | test.use({ reducedMotion: 'no-preference' });
  5   | const seats: Record<number, number[]> = { 1: [4], 4: [1,3,4,6], 7: [1,2,3,4,5,6,7] };
  6   | type Trace = { arrivals: string[]; flights: string[]; duplicate: boolean; overlap: boolean; started: number; finished: number; paused: boolean; checkpoints: string[] };
  7   | async function setup(page: Page, count: number) {
  8   |   await page.goto('/?fixture=player-setup');
  9   |   await page.getByLabel('Total players', { exact: true }).selectOption(String(count));
  10  |   await page.getByRole('button', { name: 'Start table', exact: true }).click();
  11  |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  12  | }
  13  | async function observe(page: Page, checkpoints: string[] = []) {
  14  |   await page.evaluate(checkpoints => {
  15  |     const trace: Trace = { arrivals: [], flights: [], duplicate: false, overlap: false, started: performance.now(), finished: 0, paused: false, checkpoints };
  16  |     (window as unknown as { dealTrace: Trace }).dealTrace = trace;
  17  |     new MutationObserver(records => {
  18  |       for (const record of records) for (const node of record.addedNodes) if (node instanceof HTMLElement && node.dataset.initialDealFlight) {
  19  |         const target = node.dataset.dealTarget!;
  20  |         if (trace.flights.includes(target)) trace.duplicate = true;
  21  |         trace.flights.push(target);
  22  |         trace.overlap ||= document.querySelectorAll('[data-initial-deal-flight]').length > 1;
  23  |         if (trace.checkpoints.includes(target)) {
  24  |           node.getAnimations({ subtree: true }).forEach(animation => animation.pause()); trace.paused = true;
  25  |         }
  26  |       }
  27  |       for (const element of document.querySelectorAll<HTMLElement>('[data-card-slot][data-deal-visible="true"]')) {
  28  |         const key = element.dataset.cardSlot!;
  29  |         if (Number(key.slice(key.lastIndexOf(':') + 1)) < 2 && !trace.arrivals.includes(key)) trace.arrivals.push(key);
  30  |       }
  31  |       if (document.querySelector('[data-initial-deal-running="false"]') && trace.flights.length) trace.finished = performance.now();
  32  |     }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-deal-visible','data-initial-deal-running'] });
  33  |   }, checkpoints);
  34  | }
  35  | const trace = (page: Page) => page.evaluate(() => (window as unknown as { dealTrace: Trace }).dealTrace);
  36  | for (const count of [1,4,7]) test(`[T06-B01-${count}] real FULL_MOTION two-pass order, one clone, no premature arrival`, async ({ page }, info) => {
  37  |   await setup(page, count); await observe(page);
  38  |   const dealer = await page.locator('[data-dealer-character]').getAttribute('data-dealer-character');
  39  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  40  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  41  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-presentation-state', 'DEALING');
  42  |   await expect(page.locator('[data-card-slot][data-deal-visible="true"]')).toHaveCount(0);
  43  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  44  |   const result = await trace(page), order = [0,1].flatMap(index => [...seats[count].map(seat => `round-1/seat-${seat}:${index}`), `dealer:${index}`]);
  45  |   expect(result.flights).toEqual(order); expect(result.arrivals).toEqual(order);
  46  |   expect(result.duplicate).toBe(false); expect(result.overlap).toBe(false);
  47  |   expect(result.finished - result.started).toBeLessThan(4000);
  48  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  49  |   await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toHaveCount(1);
  50  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  51  |   writeFileSync(info.outputPath('sequence.json'), JSON.stringify(result, null, 2));
  52  | });
  53  | 
  54  | test('[T06-B02] checkpoint captures actual start/first/second/settled 1/4/7 and tablet/mobile', async ({ page }) => {
  55  |   const root = 'docs/M10_T06_EVIDENCE/screenshots'; mkdirSync(root, { recursive: true });
  56  |   for (const [count,width,height] of [[1,1280,900],[4,1280,900],[7,1280,900],[7,768,1024],[7,320,720]]) {
  57  |     await page.setViewportSize({ width, height }); await setup(page, count);
  58  |     const checkpoints = [`round-1/seat-${seats[count][0]}:0`, 'dealer:0', `round-1/seat-${seats[count][Math.floor(count/2)]}:1`];
  59  |     await observe(page, checkpoints); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  60  |     for (const [index,target] of checkpoints.entries()) {
  61  |       await expect.poll(async () => (await trace(page)).paused && await page.locator(`[data-deal-target="${target}"]`).count() === 1).toBe(true);
  62  |       await page.screenshot({ path: `${root}/${count}-${width}-${['start','end-first-pass','mid-second-pass'][index]}.png`, fullPage: true });
  63  |       await page.evaluate(() => {
  64  |         const trace = (window as unknown as { dealTrace: Trace }).dealTrace;
  65  |         trace.paused = false; document.querySelectorAll<HTMLElement>('[data-initial-deal-flight]').forEach(element => element.getAnimations({ subtree: true }).forEach(animation => animation.play()));
  66  |       });
  67  |     }
  68  |     await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  69  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  70  |     await page.screenshot({ path: `${root}/${count}-${width}-settled.png`, fullPage: true });
  71  |     writeFileSync(`${root}/${count}-${width}-sequence.json`, JSON.stringify(await trace(page), null, 2));
  72  |   }
  73  | });
  74  | 
  75  | test('[T06-B03] skip/keyboard legal action settles before dispatch; new round/new table never replay stale cards', async ({ page }) => {
  76  |   await page.goto('/?fixture=player-split'); await observe(page);
  77  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  78  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  79  |   await page.getByRole('button', { name: 'Split', exact: true }).focus(); await page.keyboard.press('Enter');
  80  |   await expect(page.locator('#player-hand article')).toHaveCount(2); await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  81  |   await expect(page.locator('#player-hand [data-deal-visible="false"]')).toHaveCount(0);
  82  |   for (let index = 0; index < 2; index++) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  83  |   const dealer = await page.locator('.dealer-zone').getAttribute('data-dealer-character');
> 84  |   await page.getByRole('button', { name: 'Repeat Bet', exact: true }).click();
      |                                                                       ^ Error: locator.click: Test timeout of 30000ms exceeded.
  85  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  86  |   await page.getByRole('button', { name: 'Skip animations', exact: true }).click();
  87  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  88  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  89  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  90  |   if (await page.getByRole('button', { name: 'Decline', exact: true }).count()) await page.getByRole('button', { name: 'Decline', exact: true }).click();
  91  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  92  |   await page.getByRole('button', { name: 'New table · reset to 1000 credits', exact: true }).click();
  93  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0); await expect(page.locator('[data-card-slot]')).toHaveCount(0);
  94  | });
  95  | 
  96  | test('[T06-B04] resize/background/text200 settle safely, keep native focus and bounded geometry', async ({ page }) => {
  97  |   await setup(page, 7); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  98  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(1);
  99  |   await page.setViewportSize({ width: 768, height: 1024 });
  100 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  101 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  102 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  103 |   await page.goto('/?fixture=player-split'); await page.addStyleTag({ content: 'html {font-size: 200%}' });
  104 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  105 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange')); });
  106 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  107 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  108 |   const stand = page.getByRole('button', { name: 'Stand', exact: true }); await stand.focus(); await expect(stand).toBeFocused();
  109 |   const box = await stand.boundingBox(); expect(box!.width).toBeGreaterThanOrEqual(44); expect(box!.height).toBeGreaterThanOrEqual(44);
  110 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  111 | });
  112 | 
  113 | test('[T06-B05] reduced preference settles without flights; IMMEDIATE uses the identical authoritative result', async ({ page }) => {
  114 |   await page.emulateMedia({ reducedMotion: 'reduce' }); await setup(page, 7); await observe(page);
  115 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  116 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  117 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  118 |   expect((await trace(page)).flights).toEqual([]);
  119 |   const result = await page.evaluate(async () => {
  120 |     const fixtureUrl = '/tests/browser/fixtures.ts', providerUrl = '/src/ui/PresentationProvider.tsx';
  121 |     const { createFixtureController } = await import(fixtureUrl), { createPresentationRuntime, connectPresentation } = await import(providerUrl);
  122 |     const receipts = [];
  123 |     for (const mode of ['IMMEDIATE','REDUCED_MOTION']) {
  124 |       const controller = createFixtureController('player'), runtime = createPresentationRuntime();
  125 |       const disconnect = connectPresentation(controller.presentation, runtime, mode);
  126 |       controller.dispatch({ type: 'DEAL', amount: 200 });
  127 |       receipts.push({ authority: controller.getSnapshot(), projection: runtime.initialDeal.getSnapshot().pending, active: runtime.timeline.getSnapshot().activeId });
  128 |       disconnect();
  129 |     }
  130 |     return receipts;
  131 |   });
  132 |   expect(result[0]).toEqual(result[1]); expect(result[0].active).toBeNull(); expect(result[0].projection).toEqual([]);
  133 |   await page.screenshot({ path: 'docs/M10_T06_EVIDENCE/reduced-seven-settled.png', fullPage: true });
  134 | });
  135 | 
  136 | test('[T06-B06] real Provider unmount cancels the active flight, leaves authority and late callbacks unchanged', async ({ page }) => {
  137 |   await page.goto('/?fixture=player');
  138 |   const result = await page.evaluate(async () => {
  139 |     const providerUrl = '/src/ui/PresentationProvider.tsx', cardsUrl = '/src/ui/Cards.tsx', fixtureUrl = '/tests/browser/fixtures.ts';
  140 |     const reactUrl = '/node_modules/.vite/deps/react.js', rootUrl = '/node_modules/.vite/deps/react-dom_client.js';
  141 |     const { PresentationProvider, usePresentationAnchor, usePresentationRuntime } = await import(providerUrl), { Cards, HiddenDealerCard } = await import(cardsUrl);
  142 |     const { createFixtureController } = await import(fixtureUrl), { default: React } = await import(reactUrl), { default: ReactDOM } = await import(rootUrl);
  143 |     const controller = createFixtureController('player-split'); controller.dispatch({ type: 'DEAL', amount: 200 });
  144 |     const authority = JSON.stringify(controller.getSnapshot()), hand = controller.getSnapshot().round.seats.find((seat: { seatNumber: number }) => seat.seatNumber === 4).hands[0];
  145 |     const host = document.createElement('div'); document.body.append(host); const root = ReactDOM.createRoot(host);
  146 |     let runtime: ReturnType<typeof usePresentationRuntime>;
  147 |     function Probe() {
  148 |       runtime = usePresentationRuntime(); const origin = usePresentationAnchor('deal-origin');
  149 |       return React.createElement('div', null, React.createElement('div', { ref: origin }, 'Shoe'), React.createElement(Cards, { cards: hand.cards, ownerId: hand.handId }), React.createElement(HiddenDealerCard));
  150 |     }
  151 |     const started = new Promise<void>(resolve => {
  152 |       const observer = new MutationObserver(() => { if (document.querySelector('[data-initial-deal-flight]')) { observer.disconnect(); resolve(); } });
  153 |       observer.observe(document.body, { subtree: true, childList: true });
  154 |     });
  155 |     root.render(React.createElement(PresentationProvider, { feed: controller.presentation }, React.createElement(Probe))); await started;
  156 |     const active = runtime!.timeline.getSnapshot().activeId; root.unmount(); host.remove();
  157 |     await Promise.resolve();
  158 |     return { active, remaining: document.querySelectorAll('[data-initial-deal-flight]').length, snapshot: runtime!.timeline.getSnapshot(), same: JSON.stringify(controller.getSnapshot()) === authority };
  159 |   });
  160 |   expect(result.active).not.toBeNull(); expect(result.remaining).toBe(0); expect(result.snapshot).toMatchObject({ activeId: null, pending: 0 }); expect(result.same).toBe(true);
  161 | });
  162 | 
```