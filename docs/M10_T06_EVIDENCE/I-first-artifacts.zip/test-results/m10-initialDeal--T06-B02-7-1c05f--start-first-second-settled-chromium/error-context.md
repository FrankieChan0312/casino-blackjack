# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m10\initialDeal.spec.ts >> [T06-B02-7-320] checkpoint captures actual start/first/second/settled
- Location: tests\browser\m10\initialDeal.spec.ts:54:103

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- main [ref=e3]:
  - link "Skip to your hand and actions" [ref=e4] [cursor=pointer]:
    - /url: "#player-decisions"
  - region "Blackjack game scene" [ref=e5]:
    - generic [ref=e6]:
      - heading "Casino Blackjack" [level=1] [ref=e8]
      - paragraph [ref=e9]: Simulation credits only — no real-money gambling.Credits have no redemption value.
    - generic [ref=e10]:
      - region "Blackjack table" [ref=e11]:
        - region "Dealer" [ref=e12]:
          - 'img "Dealer: Celestine" [ref=e13]'
          - heading "Dealer" [level=2] [ref=e14]
          - group "Dealer hand" [ref=e15]:
            - generic [ref=e16]:
              - img "4 of spades" [ref=e18]:
                - generic [ref=e19]:
                  - text: "4"
                  - generic [aria-hidden] [ref=e20]: ♠
                - generic [aria-hidden] [ref=e21]: ♠
                - generic [aria-hidden] [ref=e22]: "4"
              - img "Hidden dealer card" [ref=e23]: ◆
            - paragraph [ref=e24]: "Visible total: 4"
            - paragraph [ref=e25]: Hole card hidden
          - group "Shoe and deal origin" [ref=e26]:
            - paragraph [ref=e28]:
              - text: Shoe · Deal origin
              - generic [ref=e29]: 6 decks
          - paragraph [ref=e30]:
            - text: BLACKJACK PAYS 3:2
            - generic [ref=e31]: DEALER STANDS ON ALL 17
        - generic [ref=e32]:
          - region "Seat 1" [ref=e33]:
            - generic [ref=e34]:
              - generic [ref=e35]:
                - 'img "Computer guest: Caelan, Male Elf" [ref=e36]'
                - generic [ref=e37]:
                  - heading "Caelan" [level=2] [ref=e38]
                  - paragraph [ref=e39]: Male Elf
                  - paragraph [ref=e40]: Seat 1 · Computer
              - paragraph [ref=e41]: "MAIN: 25 credits"
              - group [ref=e42]:
                - generic "Cards · 19" [ref=e43] [cursor=pointer]
          - region "Seat 2" [ref=e44]:
            - generic [ref=e45]:
              - generic [ref=e46]:
                - 'img "Computer guest: Elaria, Female Elf" [ref=e47]'
                - generic [ref=e48]:
                  - heading "Elaria" [level=2] [ref=e49]
                  - paragraph [ref=e50]: Female Elf
                  - paragraph [ref=e51]: Seat 2 · Computer
              - paragraph [ref=e52]: "MAIN: 25 credits"
              - group [ref=e53]:
                - generic "Cards · 21" [ref=e54] [cursor=pointer]
          - region "Seat 3" [ref=e55]:
            - generic [ref=e56]:
              - generic [ref=e57]:
                - 'img "Computer guest: Seraphine, Female Human Knight" [ref=e58]'
                - generic [ref=e59]:
                  - heading "Seraphine" [level=2] [ref=e60]
                  - paragraph [ref=e61]: Female Human Knight
                  - paragraph [ref=e62]: Seat 3 · Computer
              - paragraph [ref=e63]: "MAIN: 25 credits"
              - group [ref=e64]:
                - generic "Cards · 19" [ref=e65] [cursor=pointer]
          - region "Seat 4" [active] [ref=e66]:
            - group "Your player HUD" [ref=e67]:
              - generic [ref=e68]:
                - generic [ref=e69]:
                  - 'img "Your avatar: Roland, Male Human Knight" [ref=e70]'
                  - generic [ref=e71]:
                    - paragraph [ref=e72]: YOU
                    - heading "Roland" [level=2] [ref=e73]: ▸ Roland
                    - paragraph [ref=e74]: Male Human Knight
                    - paragraph [ref=e75]: Seat 4 · You · Human
                - paragraph [ref=e76]: "MAIN: 100 credits"
              - article "Hand A" [ref=e78]:
                - generic [ref=e79]:
                  - heading "Hand A · Current hand" [level=3] [ref=e80]
                  - generic [ref=e81]: ACTIVE
                - generic [ref=e82]:
                  - img "9 of hearts" [ref=e83]:
                    - generic [ref=e84]:
                      - text: "9"
                      - generic [aria-hidden] [ref=e85]: ♥
                    - generic [aria-hidden] [ref=e86]: ♥
                    - generic [aria-hidden] [ref=e87]: "9"
                  - img "K of spades" [ref=e88]:
                    - generic [ref=e89]:
                      - text: K
                      - generic [aria-hidden] [ref=e90]: ♠
                    - generic [aria-hidden] [ref=e91]: ♠
                    - generic [aria-hidden] [ref=e92]: K
                - generic [ref=e93]:
                  - paragraph [ref=e94]:
                    - text: "Total:"
                    - strong [ref=e95]: "19"
                  - paragraph [ref=e96]: "Wager: 100 credits"
                  - paragraph [ref=e97]: Playing
          - region "Seat 5" [ref=e98]:
            - generic [ref=e99]:
              - generic [ref=e100]:
                - 'img "Computer guest: Alaric, Male Mage" [ref=e101]'
                - generic [ref=e102]:
                  - heading "Alaric" [level=2] [ref=e103]
                  - paragraph [ref=e104]: Male Mage
                  - paragraph [ref=e105]: Seat 5 · Computer
              - paragraph [ref=e106]: "MAIN: 25 credits"
              - group [ref=e107]:
                - generic "Cards · 13" [ref=e108] [cursor=pointer]
          - region "Seat 6" [ref=e109]:
            - generic [ref=e110]:
              - generic [ref=e111]:
                - 'img "Computer guest: Nyra, Female Mage" [ref=e112]'
                - generic [ref=e113]:
                  - heading "Nyra" [level=2] [ref=e114]
                  - paragraph [ref=e115]: Female Mage
                  - paragraph [ref=e116]: Seat 6 · Computer
              - paragraph [ref=e117]: "MAIN: 25 credits"
              - group [ref=e118]:
                - generic "Cards · 15" [ref=e119] [cursor=pointer]
          - region "Seat 7" [ref=e120]:
            - generic [ref=e121]:
              - generic [ref=e122]:
                - 'img "Computer guest: Lucien, Male Noble" [ref=e123]'
                - generic [ref=e124]:
                  - heading "Lucien" [level=2] [ref=e125]
                  - paragraph [ref=e126]: Male Noble
                  - paragraph [ref=e127]: Seat 7 · Computer
              - paragraph [ref=e128]: "MAIN: 25 credits"
              - group [ref=e129]:
                - generic "Cards · 18" [ref=e130] [cursor=pointer]
      - region "Your gameplay controls" [ref=e131]:
        - generic [ref=e132]:
          - status [ref=e133]: Your turn
          - generic [ref=e134]: · Hand A
        - region "Primary actions" [ref=e135]:
          - generic [ref=e136]:
            - button "Hit" [ref=e137] [cursor=pointer]
            - button "Stand" [ref=e138] [cursor=pointer]
            - button "Double" [ref=e139] [cursor=pointer]
            - button "Split" [disabled] [ref=e140]
            - button "Surrender" [ref=e141] [cursor=pointer]
          - group [ref=e142]:
            - generic "Action guidance · Unavailable actions explained" [ref=e143] [cursor=pointer]
        - region "Your credits" [ref=e144]:
          - heading "Credits" [level=2] [ref=e145]
          - generic [ref=e146]:
            - generic [ref=e147]:
              - term [ref=e148]: Available
              - definition [ref=e149]: "900"
            - generic [ref=e150]:
              - term [ref=e151]: Reserved / current exposure
              - definition [ref=e152]: "100"
            - generic [ref=e153]:
              - term [ref=e154]: Pending return
              - definition [ref=e155]: "0"
    - paragraph [ref=e156]: Existing 6-deck shoe continues · Computer guests play with their own simulation credits.
  - complementary "Table preferences and demo tools" [ref=e157]:
    - generic [ref=e158]:
      - paragraph [ref=e159]: 7 players · 1 human · 6 computer guests
      - button "New table · reset to 1000 credits" [disabled] [ref=e160]
    - group [ref=e161]:
      - generic "Change Character · Roland" [ref=e162] [cursor=pointer]
      - option "Caelan · Male Elf"
      - option "Elaria · Female Elf"
      - option "Roland · Male Human Knight" [selected]
      - option "Seraphine · Female Human Knight"
      - option "Alaric · Male Mage"
      - option "Nyra · Female Mage"
      - option "Lucien · Male Noble"
      - option "Celestine · Female Noble · Dealer (reserved for this table)" [disabled]
      - option "Garruk · Male Half-Orc Warrior"
      - option "Vesha · Female Half-Orc Warrior"
      - option "Borin · Male Dwarf"
      - option "Brynja · Female Dwarf"
    - group [ref=e163]:
      - generic "Developer / demo tools" [ref=e164] [cursor=pointer]
      - option "Classic Blackjack" [selected]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { writeFileSync, mkdirSync } from 'node:fs';
  3   | 
  4   | test.use({ reducedMotion: 'no-preference' });
  5   | const seats: Record<number, number[]> = { 1: [4], 4: [1,3,4,6], 7: [1,2,3,4,5,6,7] };
  6   | type Trace = { arrivals: string[]; flights: string[]; duplicate: boolean; overlap: boolean; started: number; finished: number; paused: boolean; checkpoints: string[] };
  7   | async function setup(page: Page, count: number) {
  8   |   await page.goto('/?fixture=player-setup');
  9   |   await page.getByLabel('Total players', { exact: true }).selectOption(String(count));
  10  |   await page.getByRole('button', { name: 'Start table', exact: true }).click();
  11  |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  12  | }
  13  | async function observe(page: Page, checkpoints: string[] = []) {
  14  |   await page.evaluate(checkpoints => {
  15  |     const trace: Trace = { arrivals: [], flights: [], duplicate: false, overlap: false, started: performance.now(), finished: 0, paused: false, checkpoints };
  16  |     (window as unknown as { dealTrace: Trace }).dealTrace = trace;
  17  |     new MutationObserver(records => {
  18  |       for (const record of records) for (const node of record.addedNodes) if (node instanceof HTMLElement && node.dataset.initialDealFlight) {
  19  |         const target = node.dataset.dealTarget!;
  20  |         if (trace.flights.includes(target)) trace.duplicate = true;
  21  |         trace.flights.push(target);
  22  |         trace.overlap ||= document.querySelectorAll('[data-initial-deal-flight]').length > 1;
  23  |         if (trace.checkpoints.includes(target)) {
  24  |           node.getAnimations({ subtree: true }).forEach(animation => animation.pause()); trace.paused = true;
  25  |         }
  26  |       }
  27  |       for (const element of document.querySelectorAll<HTMLElement>('[data-card-slot][data-deal-visible="true"]')) {
  28  |         const key = element.dataset.cardSlot!;
  29  |         if (Number(key.slice(key.lastIndexOf(':') + 1)) < 2 && !trace.arrivals.includes(key)) trace.arrivals.push(key);
  30  |       }
  31  |       if (document.querySelector('[data-initial-deal-running="false"]') && trace.flights.length) trace.finished = performance.now();
  32  |     }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-deal-visible','data-initial-deal-running'] });
  33  |   }, checkpoints);
  34  | }
  35  | const trace = (page: Page) => page.evaluate(() => (window as unknown as { dealTrace: Trace }).dealTrace);
  36  | for (const count of [1,4,7]) test(`[T06-B01-${count}] real FULL_MOTION two-pass order, one clone, no premature arrival`, async ({ page }, info) => {
  37  |   await setup(page, count); await observe(page);
  38  |   const dealer = await page.locator('[data-dealer-character]').getAttribute('data-dealer-character');
  39  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  40  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  41  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-presentation-state', 'DEALING');
  42  |   await expect(page.locator('[data-card-slot][data-deal-visible="true"]')).toHaveCount(0);
  43  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  44  |   const result = await trace(page), order = [0,1].flatMap(index => [...seats[count].map(seat => `round-1/seat-${seat}:${index}`), `dealer:${index}`]);
  45  |   expect(result.flights).toEqual(order); expect(result.arrivals).toEqual(order);
  46  |   expect(result.duplicate).toBe(false); expect(result.overlap).toBe(false);
  47  |   expect(result.finished - result.started).toBeLessThan(4000);
  48  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  49  |   await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toHaveCount(1);
  50  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  51  |   writeFileSync(info.outputPath('sequence.json'), JSON.stringify(result, null, 2));
  52  | });
  53  | 
  54  | for (const [count,width,height] of [[1,1280,900],[4,1280,900],[7,1280,900],[7,768,1024],[7,320,720]]) test(`[T06-B02-${count}-${width}] checkpoint captures actual start/first/second/settled`, async ({ page }) => {
  55  |   const root = 'docs/M10_T06_EVIDENCE/screenshots'; mkdirSync(root, { recursive: true });
  56  |     await page.setViewportSize({ width, height }); await setup(page, count);
  57  |     const checkpoints = [`round-1/seat-${seats[count][0]}:0`, 'dealer:0', `round-1/seat-${seats[count][Math.floor(count/2)]}:1`];
  58  |     await observe(page, checkpoints); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  59  |     for (const [index,target] of checkpoints.entries()) {
> 60  |       await expect.poll(async () => (await trace(page)).paused && await page.locator(`[data-deal-target="${target}"]`).count() === 1).toBe(true);
      |                                                                                                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  61  |       await page.screenshot({ path: `${root}/${count}-${width}-${['start','end-first-pass','mid-second-pass'][index]}.png`, fullPage: true });
  62  |       await page.evaluate(() => {
  63  |         const trace = (window as unknown as { dealTrace: Trace }).dealTrace;
  64  |         trace.paused = false; document.querySelectorAll<HTMLElement>('[data-initial-deal-flight]').forEach(element => element.getAnimations({ subtree: true }).forEach(animation => animation.play()));
  65  |       });
  66  |     }
  67  |     await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  68  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  69  |     await page.screenshot({ path: `${root}/${count}-${width}-settled.png`, fullPage: true });
  70  |     writeFileSync(`${root}/${count}-${width}-sequence.json`, JSON.stringify(await trace(page), null, 2));
  71  | });
  72  | 
  73  | test('[T06-B03] skip/keyboard legal action settles before dispatch; new round/new table never replay stale cards', async ({ page }) => {
  74  |   await page.goto('/?fixture=player-split'); await observe(page);
  75  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  76  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  77  |   await page.getByRole('button', { name: 'Split', exact: true }).focus(); await page.keyboard.press('Enter');
  78  |   await expect(page.locator('#player-hand article')).toHaveCount(2); await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  79  |   await expect(page.locator('#player-hand [data-deal-visible="false"]')).toHaveCount(0);
  80  |   for (let index = 0; index < 2; index++) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  81  |   const dealer = await page.locator('.dealer-zone').getAttribute('data-dealer-character');
  82  |   await page.getByRole('button', { name: /^Repeat Bet/ }).click();
  83  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  84  |   await page.getByRole('button', { name: 'Skip animations', exact: true }).click();
  85  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  86  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  87  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  88  |   if (await page.getByRole('button', { name: 'Decline', exact: true }).count()) await page.getByRole('button', { name: 'Decline', exact: true }).click();
  89  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  90  |   await page.getByRole('button', { name: 'New table · reset to 1000 credits', exact: true }).click();
  91  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0); await expect(page.locator('[data-card-slot]')).toHaveCount(0);
  92  | });
  93  | 
  94  | test('[T06-B04] resize/background/text200 settle safely, keep native focus and bounded geometry', async ({ page }) => {
  95  |   await setup(page, 7); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  96  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(1);
  97  |   await page.setViewportSize({ width: 768, height: 1024 });
  98  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  99  |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  100 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  101 |   await page.goto('/?fixture=player-split'); await page.addStyleTag({ content: 'html {font-size: 200%}' });
  102 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  103 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange')); });
  104 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  105 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  106 |   const stand = page.getByRole('button', { name: 'Stand', exact: true }); await stand.focus(); await expect(stand).toBeFocused();
  107 |   const box = await stand.boundingBox(); expect(box!.width).toBeGreaterThanOrEqual(44); expect(box!.height).toBeGreaterThanOrEqual(44);
  108 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  109 | });
  110 | 
  111 | test('[T06-B05] reduced preference settles without flights; IMMEDIATE uses the identical authoritative result', async ({ page }) => {
  112 |   await page.emulateMedia({ reducedMotion: 'reduce' }); await setup(page, 7); await observe(page);
  113 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  114 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  115 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  116 |   expect((await trace(page)).flights).toEqual([]);
  117 |   const result = await page.evaluate(async () => {
  118 |     const fixtureUrl = '/tests/browser/fixtures.ts', providerUrl = '/src/ui/PresentationProvider.tsx';
  119 |     const { createFixtureController } = await import(fixtureUrl), { createPresentationRuntime, connectPresentation } = await import(providerUrl);
  120 |     const receipts = [];
  121 |     for (const mode of ['IMMEDIATE','REDUCED_MOTION']) {
  122 |       const controller = createFixtureController('player'), runtime = createPresentationRuntime();
  123 |       const disconnect = connectPresentation(controller.presentation, runtime, mode);
  124 |       controller.dispatch({ type: 'DEAL', amount: 200 });
  125 |       receipts.push({ authority: controller.getSnapshot(), projection: runtime.initialDeal.getSnapshot().pending, active: runtime.timeline.getSnapshot().activeId });
  126 |       disconnect();
  127 |     }
  128 |     return receipts;
  129 |   });
  130 |   expect(result[0]).toEqual(result[1]); expect(result[0].active).toBeNull(); expect(result[0].projection).toEqual([]);
  131 |   await page.screenshot({ path: 'docs/M10_T06_EVIDENCE/reduced-seven-settled.png', fullPage: true });
  132 | });
  133 | 
  134 | test('[T06-B06] real Provider unmount cancels the active flight, leaves authority and late callbacks unchanged', async ({ page }) => {
  135 |   await page.goto('/?fixture=player');
  136 |   const result = await page.evaluate(async () => {
  137 |     const providerUrl = '/src/ui/PresentationProvider.tsx', cardsUrl = '/src/ui/Cards.tsx', fixtureUrl = '/tests/browser/fixtures.ts';
  138 |     const reactUrl = '/node_modules/.vite/deps/react.js', rootUrl = '/node_modules/.vite/deps/react-dom_client.js';
  139 |     const { PresentationProvider, usePresentationAnchor, usePresentationRuntime } = await import(providerUrl), { Cards, HiddenDealerCard } = await import(cardsUrl);
  140 |     const { createFixtureController } = await import(fixtureUrl), { default: React } = await import(reactUrl), { default: ReactDOM } = await import(rootUrl);
  141 |     const controller = createFixtureController('player-split'); controller.dispatch({ type: 'DEAL', amount: 200 });
  142 |     const authority = JSON.stringify(controller.getSnapshot()), hand = controller.getSnapshot().round.seats.find((seat: { seatNumber: number }) => seat.seatNumber === 4).hands[0];
  143 |     const host = document.createElement('div'); document.body.append(host); const root = ReactDOM.createRoot(host);
  144 |     let runtime: ReturnType<typeof usePresentationRuntime>;
  145 |     function Probe() {
  146 |       runtime = usePresentationRuntime(); const origin = usePresentationAnchor('deal-origin');
  147 |       return React.createElement('div', null, React.createElement('div', { ref: origin }, 'Shoe'), React.createElement(Cards, { cards: hand.cards, ownerId: hand.handId }), React.createElement(HiddenDealerCard));
  148 |     }
  149 |     const started = new Promise<void>(resolve => {
  150 |       const observer = new MutationObserver(() => { if (document.querySelector('[data-initial-deal-flight]')) { observer.disconnect(); resolve(); } });
  151 |       observer.observe(document.body, { subtree: true, childList: true });
  152 |     });
  153 |     root.render(React.createElement(PresentationProvider, { feed: controller.presentation }, React.createElement(Probe))); await started;
  154 |     const active = runtime!.timeline.getSnapshot().activeId; root.unmount(); host.remove();
  155 |     await Promise.resolve();
  156 |     return { active, remaining: document.querySelectorAll('[data-initial-deal-flight]').length, snapshot: runtime!.timeline.getSnapshot(), same: JSON.stringify(controller.getSnapshot()) === authority };
  157 |   });
  158 |   expect(result.active).not.toBeNull(); expect(result.remaining).toBe(0); expect(result.snapshot).toMatchObject({ activeId: null, pending: 0 }); expect(result.same).toBe(true);
  159 | });
  160 | 
```