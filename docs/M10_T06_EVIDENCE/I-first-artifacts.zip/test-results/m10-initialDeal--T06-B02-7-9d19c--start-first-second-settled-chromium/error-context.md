# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m10\initialDeal.spec.ts >> [T06-B02-7-1280] checkpoint captures actual start/first/second/settled
- Location: tests\browser\m10\initialDeal.spec.ts:54:103

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- main [ref=e3]:
  - link "Skip to your hand and actions" [ref=e4] [cursor=pointer]:
    - /url: "#player-decisions"
  - region "Blackjack game scene" [ref=e5]:
    - generic [ref=e6]:
      - heading "Casino Blackjack" [level=1] [ref=e8]
      - paragraph [ref=e9]: Simulation credits only — no real-money gambling.Credits have no redemption value.
    - generic [ref=e10]:
      - region "Blackjack table" [ref=e11]:
        - region "Dealer" [ref=e12]:
          - 'img "Dealer: Celestine" [ref=e13]'
          - heading "Dealer" [level=2] [ref=e14]
          - group "Dealer hand" [ref=e15]:
            - generic [ref=e16]:
              - img "4 of spades" [ref=e18]:
                - generic [ref=e19]:
                  - text: "4"
                  - generic [aria-hidden] [ref=e20]: ♠
                - generic [aria-hidden] [ref=e21]: ♠
                - generic [aria-hidden] [ref=e22]: "4"
              - img "Hidden dealer card" [ref=e23]: ◆
            - paragraph [ref=e24]: "Visible total: 4"
            - paragraph [ref=e25]: Hole card hidden
          - group "Shoe and deal origin" [ref=e26]:
            - paragraph [ref=e28]:
              - text: Shoe · Deal origin
              - generic [ref=e29]: 6 decks
          - paragraph [ref=e30]:
            - text: BLACKJACK PAYS 3:2
            - generic [ref=e31]: DEALER STANDS ON ALL 17
        - generic [ref=e32]:
          - region "Seat 1" [ref=e33]:
            - generic [ref=e34]:
              - generic [ref=e35]:
                - 'img "Computer guest: Caelan, Male Elf" [ref=e36]'
                - generic [ref=e37]:
                  - heading "Caelan" [level=2] [ref=e38]
                  - paragraph [ref=e39]: Male Elf
                  - paragraph [ref=e40]: Seat 1 · Computer
              - group [ref=e41]:
                - article "Hand A" [ref=e42]:
                  - generic [ref=e43]:
                    - img "J of hearts" [ref=e44]:
                      - generic [ref=e45]:
                        - text: J
                        - generic [aria-hidden] [ref=e46]: ♥
                      - generic [aria-hidden] [ref=e47]: ♥
                      - generic [aria-hidden] [ref=e48]: J
                    - img "6 of diamonds" [ref=e49]:
                      - generic [ref=e50]:
                        - text: "6"
                        - generic [aria-hidden] [ref=e51]: ♦
                      - generic [aria-hidden] [ref=e52]: ♦
                      - generic [aria-hidden] [ref=e53]: "6"
                    - img "3 of spades" [ref=e54]:
                      - generic [ref=e55]:
                        - text: "3"
                        - generic [aria-hidden] [ref=e56]: ♠
                      - generic [aria-hidden] [ref=e57]: ♠
                      - generic [aria-hidden] [ref=e58]: "3"
                  - generic [ref=e59]:
                    - paragraph [ref=e60]: "19"
                    - paragraph [ref=e61]: Decisions complete
                    - paragraph [ref=e62]: "MAIN: 25 credits"
          - region "Seat 2" [ref=e63]:
            - generic [ref=e64]:
              - generic [ref=e65]:
                - 'img "Computer guest: Elaria, Female Elf" [ref=e66]'
                - generic [ref=e67]:
                  - heading "Elaria" [level=2] [ref=e68]
                  - paragraph [ref=e69]: Female Elf
                  - paragraph [ref=e70]: Seat 2 · Computer
              - group [ref=e71]:
                - article "Hand A" [ref=e72]:
                  - generic [ref=e73]:
                    - img "A of hearts" [ref=e74]:
                      - generic [ref=e75]:
                        - text: A
                        - generic [aria-hidden] [ref=e76]: ♥
                      - generic [aria-hidden] [ref=e77]: ♥
                      - generic [aria-hidden] [ref=e78]: A
                    - img "K of clubs" [ref=e79]:
                      - generic [ref=e80]:
                        - text: K
                        - generic [aria-hidden] [ref=e81]: ♣
                      - generic [aria-hidden] [ref=e82]: ♣
                      - generic [aria-hidden] [ref=e83]: K
                  - generic [ref=e84]:
                    - paragraph [ref=e85]: "21"
                    - paragraph [ref=e86]: Blackjack
                    - paragraph [ref=e87]: "MAIN: 25 credits"
          - region "Seat 3" [ref=e88]:
            - generic [ref=e89]:
              - generic [ref=e90]:
                - 'img "Computer guest: Seraphine, Female Human Knight" [ref=e91]'
                - generic [ref=e92]:
                  - heading "Seraphine" [level=2] [ref=e93]
                  - paragraph [ref=e94]: Female Human Knight
                  - paragraph [ref=e95]: Seat 3 · Computer
              - group [ref=e96]:
                - article "Hand A" [ref=e97]:
                  - generic [ref=e98]:
                    - img "5 of hearts" [ref=e99]:
                      - generic [ref=e100]:
                        - text: "5"
                        - generic [aria-hidden] [ref=e101]: ♥
                      - generic [aria-hidden] [ref=e102]: ♥
                      - generic [aria-hidden] [ref=e103]: "5"
                    - img "2 of clubs" [ref=e104]:
                      - generic [ref=e105]:
                        - text: "2"
                        - generic [aria-hidden] [ref=e106]: ♣
                      - generic [aria-hidden] [ref=e107]: ♣
                      - generic [aria-hidden] [ref=e108]: "2"
                    - img "5 of diamonds" [ref=e109]:
                      - generic [ref=e110]:
                        - text: "5"
                        - generic [aria-hidden] [ref=e111]: ♦
                      - generic [aria-hidden] [ref=e112]: ♦
                      - generic [aria-hidden] [ref=e113]: "5"
                    - img "7 of diamonds" [ref=e114]:
                      - generic [ref=e115]:
                        - text: "7"
                        - generic [aria-hidden] [ref=e116]: ♦
                      - generic [aria-hidden] [ref=e117]: ♦
                      - generic [aria-hidden] [ref=e118]: "7"
                  - generic [ref=e119]:
                    - paragraph [ref=e120]: "19"
                    - paragraph [ref=e121]: Decisions complete
                    - paragraph [ref=e122]: "MAIN: 25 credits"
          - region "Seat 4" [active] [ref=e123]:
            - group "Your player HUD" [ref=e124]:
              - generic [ref=e125]:
                - generic [ref=e126]:
                  - 'img "Your avatar: Roland, Male Human Knight" [ref=e127]'
                  - generic [ref=e128]:
                    - paragraph [ref=e129]: YOU
                    - heading "Roland" [level=2] [ref=e130]: ▸ Roland
                    - paragraph [ref=e131]: Male Human Knight
                    - paragraph [ref=e132]: Seat 4 · You · Human
                - paragraph [ref=e133]: "MAIN: 100 credits"
              - article "Hand A" [ref=e135]:
                - generic [ref=e136]:
                  - heading "Hand A · Current hand" [level=3] [ref=e137]
                  - generic [ref=e138]: ACTIVE
                - generic [ref=e139]:
                  - img "9 of hearts" [ref=e140]:
                    - generic [ref=e141]:
                      - text: "9"
                      - generic [aria-hidden] [ref=e142]: ♥
                    - generic [aria-hidden] [ref=e143]: ♥
                    - generic [aria-hidden] [ref=e144]: "9"
                  - img "K of spades" [ref=e145]:
                    - generic [ref=e146]:
                      - text: K
                      - generic [aria-hidden] [ref=e147]: ♠
                    - generic [aria-hidden] [ref=e148]: ♠
                    - generic [aria-hidden] [ref=e149]: K
                - generic [ref=e150]:
                  - paragraph [ref=e151]:
                    - text: "Total:"
                    - strong [ref=e152]: "19"
                  - paragraph [ref=e153]: "Wager: 100 credits"
                  - paragraph [ref=e154]: Playing
          - region "Seat 5" [ref=e155]:
            - generic [ref=e156]:
              - generic [ref=e157]:
                - 'img "Computer guest: Alaric, Male Mage" [ref=e158]'
                - generic [ref=e159]:
                  - heading "Alaric" [level=2] [ref=e160]
                  - paragraph [ref=e161]: Male Mage
                  - paragraph [ref=e162]: Seat 5 · Computer
              - group [ref=e163]:
                - article "Hand A" [ref=e164]:
                  - generic [ref=e165]:
                    - img "4 of clubs" [ref=e166]:
                      - generic [ref=e167]:
                        - text: "4"
                        - generic [aria-hidden] [ref=e168]: ♣
                      - generic [aria-hidden] [ref=e169]: ♣
                      - generic [aria-hidden] [ref=e170]: "4"
                    - img "9 of spades" [ref=e171]:
                      - generic [ref=e172]:
                        - text: "9"
                        - generic [aria-hidden] [ref=e173]: ♠
                      - generic [aria-hidden] [ref=e174]: ♠
                      - generic [aria-hidden] [ref=e175]: "9"
                  - generic [ref=e176]:
                    - paragraph [ref=e177]: "13"
                    - paragraph [ref=e178]: Playing
                    - paragraph [ref=e179]: "MAIN: 25 credits"
          - region "Seat 6" [ref=e180]:
            - generic [ref=e181]:
              - generic [ref=e182]:
                - 'img "Computer guest: Nyra, Female Mage" [ref=e183]'
                - generic [ref=e184]:
                  - heading "Nyra" [level=2] [ref=e185]
                  - paragraph [ref=e186]: Female Mage
                  - paragraph [ref=e187]: Seat 6 · Computer
              - group [ref=e188]:
                - article "Hand A" [ref=e189]:
                  - generic [ref=e190]:
                    - img "5 of diamonds" [ref=e191]:
                      - generic [ref=e192]:
                        - text: "5"
                        - generic [aria-hidden] [ref=e193]: ♦
                      - generic [aria-hidden] [ref=e194]: ♦
                      - generic [aria-hidden] [ref=e195]: "5"
                    - img "Q of clubs" [ref=e196]:
                      - generic [ref=e197]:
                        - text: Q
                        - generic [aria-hidden] [ref=e198]: ♣
                      - generic [aria-hidden] [ref=e199]: ♣
                      - generic [aria-hidden] [ref=e200]: Q
                  - generic [ref=e201]:
                    - paragraph [ref=e202]: "15"
                    - paragraph [ref=e203]: Playing
                    - paragraph [ref=e204]: "MAIN: 25 credits"
          - region "Seat 7" [ref=e205]:
            - generic [ref=e206]:
              - generic [ref=e207]:
                - 'img "Computer guest: Lucien, Male Noble" [ref=e208]'
                - generic [ref=e209]:
                  - heading "Lucien" [level=2] [ref=e210]
                  - paragraph [ref=e211]: Male Noble
                  - paragraph [ref=e212]: Seat 7 · Computer
              - group [ref=e213]:
                - article "Hand A" [ref=e214]:
                  - generic [ref=e215]:
                    - img "8 of spades" [ref=e216]:
                      - generic [ref=e217]:
                        - text: "8"
                        - generic [aria-hidden] [ref=e218]: ♠
                      - generic [aria-hidden] [ref=e219]: ♠
                      - generic [aria-hidden] [ref=e220]: "8"
                    - img "10 of clubs" [ref=e221]:
                      - generic [ref=e222]:
                        - text: "10"
                        - generic [aria-hidden] [ref=e223]: ♣
                      - generic [aria-hidden] [ref=e224]: ♣
                      - generic [aria-hidden] [ref=e225]: "10"
                  - generic [ref=e226]:
                    - paragraph [ref=e227]: "18"
                    - paragraph [ref=e228]: Playing
                    - paragraph [ref=e229]: "MAIN: 25 credits"
      - region "Your gameplay controls" [ref=e230]:
        - generic [ref=e231]:
          - status [ref=e232]: Your turn
          - generic [ref=e233]: · Hand A
        - region "Primary actions" [ref=e234]:
          - generic [ref=e235]:
            - button "Hit" [ref=e236] [cursor=pointer]
            - button "Stand" [ref=e237] [cursor=pointer]
            - button "Double" [ref=e238] [cursor=pointer]
            - button "Split" [disabled] [ref=e239]
            - button "Surrender" [ref=e240] [cursor=pointer]
          - group [ref=e241]:
            - generic "Action guidance · Unavailable actions explained" [ref=e242] [cursor=pointer]
        - region "Your credits" [ref=e243]:
          - heading "Credits" [level=2] [ref=e244]
          - generic [ref=e245]:
            - generic [ref=e246]:
              - term [ref=e247]: Available
              - definition [ref=e248]: "900"
            - generic [ref=e249]:
              - term [ref=e250]: Reserved / current exposure
              - definition [ref=e251]: "100"
            - generic [ref=e252]:
              - term [ref=e253]: Pending return
              - definition [ref=e254]: "0"
    - paragraph [ref=e255]: Existing 6-deck shoe continues · Computer guests play with their own simulation credits.
  - complementary "Table preferences and demo tools" [ref=e256]:
    - generic [ref=e257]:
      - paragraph [ref=e258]: 7 players · 1 human · 6 computer guests
      - button "New table · reset to 1000 credits" [disabled] [ref=e259]
    - group [ref=e260]:
      - generic "Change Character · Roland" [ref=e261] [cursor=pointer]
      - option "Caelan · Male Elf"
      - option "Elaria · Female Elf"
      - option "Roland · Male Human Knight" [selected]
      - option "Seraphine · Female Human Knight"
      - option "Alaric · Male Mage"
      - option "Nyra · Female Mage"
      - option "Lucien · Male Noble"
      - option "Celestine · Female Noble · Dealer (reserved for this table)" [disabled]
      - option "Garruk · Male Half-Orc Warrior"
      - option "Vesha · Female Half-Orc Warrior"
      - option "Borin · Male Dwarf"
      - option "Brynja · Female Dwarf"
    - group [ref=e262]:
      - generic "Developer / demo tools" [ref=e263] [cursor=pointer]
      - option "Classic Blackjack" [selected]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { writeFileSync, mkdirSync } from 'node:fs';
  3   | 
  4   | test.use({ reducedMotion: 'no-preference' });
  5   | const seats: Record<number, number[]> = { 1: [4], 4: [1,3,4,6], 7: [1,2,3,4,5,6,7] };
  6   | type Trace = { arrivals: string[]; flights: string[]; duplicate: boolean; overlap: boolean; started: number; finished: number; paused: boolean; checkpoints: string[] };
  7   | async function setup(page: Page, count: number) {
  8   |   await page.goto('/?fixture=player-setup');
  9   |   await page.getByLabel('Total players', { exact: true }).selectOption(String(count));
  10  |   await page.getByRole('button', { name: 'Start table', exact: true }).click();
  11  |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  12  | }
  13  | async function observe(page: Page, checkpoints: string[] = []) {
  14  |   await page.evaluate(checkpoints => {
  15  |     const trace: Trace = { arrivals: [], flights: [], duplicate: false, overlap: false, started: performance.now(), finished: 0, paused: false, checkpoints };
  16  |     (window as unknown as { dealTrace: Trace }).dealTrace = trace;
  17  |     new MutationObserver(records => {
  18  |       for (const record of records) for (const node of record.addedNodes) if (node instanceof HTMLElement && node.dataset.initialDealFlight) {
  19  |         const target = node.dataset.dealTarget!;
  20  |         if (trace.flights.includes(target)) trace.duplicate = true;
  21  |         trace.flights.push(target);
  22  |         trace.overlap ||= document.querySelectorAll('[data-initial-deal-flight]').length > 1;
  23  |         if (trace.checkpoints.includes(target)) {
  24  |           node.getAnimations({ subtree: true }).forEach(animation => animation.pause()); trace.paused = true;
  25  |         }
  26  |       }
  27  |       for (const element of document.querySelectorAll<HTMLElement>('[data-card-slot][data-deal-visible="true"]')) {
  28  |         const key = element.dataset.cardSlot!;
  29  |         if (Number(key.slice(key.lastIndexOf(':') + 1)) < 2 && !trace.arrivals.includes(key)) trace.arrivals.push(key);
  30  |       }
  31  |       if (document.querySelector('[data-initial-deal-running="false"]') && trace.flights.length) trace.finished = performance.now();
  32  |     }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-deal-visible','data-initial-deal-running'] });
  33  |   }, checkpoints);
  34  | }
  35  | const trace = (page: Page) => page.evaluate(() => (window as unknown as { dealTrace: Trace }).dealTrace);
  36  | for (const count of [1,4,7]) test(`[T06-B01-${count}] real FULL_MOTION two-pass order, one clone, no premature arrival`, async ({ page }, info) => {
  37  |   await setup(page, count); await observe(page);
  38  |   const dealer = await page.locator('[data-dealer-character]').getAttribute('data-dealer-character');
  39  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  40  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  41  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-presentation-state', 'DEALING');
  42  |   await expect(page.locator('[data-card-slot][data-deal-visible="true"]')).toHaveCount(0);
  43  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  44  |   const result = await trace(page), order = [0,1].flatMap(index => [...seats[count].map(seat => `round-1/seat-${seat}:${index}`), `dealer:${index}`]);
  45  |   expect(result.flights).toEqual(order); expect(result.arrivals).toEqual(order);
  46  |   expect(result.duplicate).toBe(false); expect(result.overlap).toBe(false);
  47  |   expect(result.finished - result.started).toBeLessThan(4000);
  48  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  49  |   await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toHaveCount(1);
  50  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  51  |   writeFileSync(info.outputPath('sequence.json'), JSON.stringify(result, null, 2));
  52  | });
  53  | 
  54  | for (const [count,width,height] of [[1,1280,900],[4,1280,900],[7,1280,900],[7,768,1024],[7,320,720]]) test(`[T06-B02-${count}-${width}] checkpoint captures actual start/first/second/settled`, async ({ page }) => {
  55  |   const root = 'docs/M10_T06_EVIDENCE/screenshots'; mkdirSync(root, { recursive: true });
  56  |     await page.setViewportSize({ width, height }); await setup(page, count);
  57  |     const checkpoints = [`round-1/seat-${seats[count][0]}:0`, 'dealer:0', `round-1/seat-${seats[count][Math.floor(count/2)]}:1`];
  58  |     await observe(page, checkpoints); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  59  |     for (const [index,target] of checkpoints.entries()) {
> 60  |       await expect.poll(async () => (await trace(page)).paused && await page.locator(`[data-deal-target="${target}"]`).count() === 1).toBe(true);
      |                                                                                                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  61  |       await page.screenshot({ path: `${root}/${count}-${width}-${['start','end-first-pass','mid-second-pass'][index]}.png`, fullPage: true });
  62  |       await page.evaluate(() => {
  63  |         const trace = (window as unknown as { dealTrace: Trace }).dealTrace;
  64  |         trace.paused = false; document.querySelectorAll<HTMLElement>('[data-initial-deal-flight]').forEach(element => element.getAnimations({ subtree: true }).forEach(animation => animation.play()));
  65  |       });
  66  |     }
  67  |     await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  68  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  69  |     await page.screenshot({ path: `${root}/${count}-${width}-settled.png`, fullPage: true });
  70  |     writeFileSync(`${root}/${count}-${width}-sequence.json`, JSON.stringify(await trace(page), null, 2));
  71  | });
  72  | 
  73  | test('[T06-B03] skip/keyboard legal action settles before dispatch; new round/new table never replay stale cards', async ({ page }) => {
  74  |   await page.goto('/?fixture=player-split'); await observe(page);
  75  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  76  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  77  |   await page.getByRole('button', { name: 'Split', exact: true }).focus(); await page.keyboard.press('Enter');
  78  |   await expect(page.locator('#player-hand article')).toHaveCount(2); await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  79  |   await expect(page.locator('#player-hand [data-deal-visible="false"]')).toHaveCount(0);
  80  |   for (let index = 0; index < 2; index++) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  81  |   const dealer = await page.locator('.dealer-zone').getAttribute('data-dealer-character');
  82  |   await page.getByRole('button', { name: /^Repeat Bet/ }).click();
  83  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  84  |   await page.getByRole('button', { name: 'Skip animations', exact: true }).click();
  85  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  86  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  87  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  88  |   if (await page.getByRole('button', { name: 'Decline', exact: true }).count()) await page.getByRole('button', { name: 'Decline', exact: true }).click();
  89  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  90  |   await page.getByRole('button', { name: 'New table · reset to 1000 credits', exact: true }).click();
  91  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0); await expect(page.locator('[data-card-slot]')).toHaveCount(0);
  92  | });
  93  | 
  94  | test('[T06-B04] resize/background/text200 settle safely, keep native focus and bounded geometry', async ({ page }) => {
  95  |   await setup(page, 7); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  96  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(1);
  97  |   await page.setViewportSize({ width: 768, height: 1024 });
  98  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  99  |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  100 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  101 |   await page.goto('/?fixture=player-split'); await page.addStyleTag({ content: 'html {font-size: 200%}' });
  102 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  103 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange')); });
  104 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  105 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  106 |   const stand = page.getByRole('button', { name: 'Stand', exact: true }); await stand.focus(); await expect(stand).toBeFocused();
  107 |   const box = await stand.boundingBox(); expect(box!.width).toBeGreaterThanOrEqual(44); expect(box!.height).toBeGreaterThanOrEqual(44);
  108 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  109 | });
  110 | 
  111 | test('[T06-B05] reduced preference settles without flights; IMMEDIATE uses the identical authoritative result', async ({ page }) => {
  112 |   await page.emulateMedia({ reducedMotion: 'reduce' }); await setup(page, 7); await observe(page);
  113 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  114 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  115 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  116 |   expect((await trace(page)).flights).toEqual([]);
  117 |   const result = await page.evaluate(async () => {
  118 |     const fixtureUrl = '/tests/browser/fixtures.ts', providerUrl = '/src/ui/PresentationProvider.tsx';
  119 |     const { createFixtureController } = await import(fixtureUrl), { createPresentationRuntime, connectPresentation } = await import(providerUrl);
  120 |     const receipts = [];
  121 |     for (const mode of ['IMMEDIATE','REDUCED_MOTION']) {
  122 |       const controller = createFixtureController('player'), runtime = createPresentationRuntime();
  123 |       const disconnect = connectPresentation(controller.presentation, runtime, mode);
  124 |       controller.dispatch({ type: 'DEAL', amount: 200 });
  125 |       receipts.push({ authority: controller.getSnapshot(), projection: runtime.initialDeal.getSnapshot().pending, active: runtime.timeline.getSnapshot().activeId });
  126 |       disconnect();
  127 |     }
  128 |     return receipts;
  129 |   });
  130 |   expect(result[0]).toEqual(result[1]); expect(result[0].active).toBeNull(); expect(result[0].projection).toEqual([]);
  131 |   await page.screenshot({ path: 'docs/M10_T06_EVIDENCE/reduced-seven-settled.png', fullPage: true });
  132 | });
  133 | 
  134 | test('[T06-B06] real Provider unmount cancels the active flight, leaves authority and late callbacks unchanged', async ({ page }) => {
  135 |   await page.goto('/?fixture=player');
  136 |   const result = await page.evaluate(async () => {
  137 |     const providerUrl = '/src/ui/PresentationProvider.tsx', cardsUrl = '/src/ui/Cards.tsx', fixtureUrl = '/tests/browser/fixtures.ts';
  138 |     const reactUrl = '/node_modules/.vite/deps/react.js', rootUrl = '/node_modules/.vite/deps/react-dom_client.js';
  139 |     const { PresentationProvider, usePresentationAnchor, usePresentationRuntime } = await import(providerUrl), { Cards, HiddenDealerCard } = await import(cardsUrl);
  140 |     const { createFixtureController } = await import(fixtureUrl), { default: React } = await import(reactUrl), { default: ReactDOM } = await import(rootUrl);
  141 |     const controller = createFixtureController('player-split'); controller.dispatch({ type: 'DEAL', amount: 200 });
  142 |     const authority = JSON.stringify(controller.getSnapshot()), hand = controller.getSnapshot().round.seats.find((seat: { seatNumber: number }) => seat.seatNumber === 4).hands[0];
  143 |     const host = document.createElement('div'); document.body.append(host); const root = ReactDOM.createRoot(host);
  144 |     let runtime: ReturnType<typeof usePresentationRuntime>;
  145 |     function Probe() {
  146 |       runtime = usePresentationRuntime(); const origin = usePresentationAnchor('deal-origin');
  147 |       return React.createElement('div', null, React.createElement('div', { ref: origin }, 'Shoe'), React.createElement(Cards, { cards: hand.cards, ownerId: hand.handId }), React.createElement(HiddenDealerCard));
  148 |     }
  149 |     const started = new Promise<void>(resolve => {
  150 |       const observer = new MutationObserver(() => { if (document.querySelector('[data-initial-deal-flight]')) { observer.disconnect(); resolve(); } });
  151 |       observer.observe(document.body, { subtree: true, childList: true });
  152 |     });
  153 |     root.render(React.createElement(PresentationProvider, { feed: controller.presentation }, React.createElement(Probe))); await started;
  154 |     const active = runtime!.timeline.getSnapshot().activeId; root.unmount(); host.remove();
  155 |     await Promise.resolve();
  156 |     return { active, remaining: document.querySelectorAll('[data-initial-deal-flight]').length, snapshot: runtime!.timeline.getSnapshot(), same: JSON.stringify(controller.getSnapshot()) === authority };
  157 |   });
  158 |   expect(result.active).not.toBeNull(); expect(result.remaining).toBe(0); expect(result.snapshot).toMatchObject({ activeId: null, pending: 0 }); expect(result.same).toBe(true);
  159 | });
  160 | 
```