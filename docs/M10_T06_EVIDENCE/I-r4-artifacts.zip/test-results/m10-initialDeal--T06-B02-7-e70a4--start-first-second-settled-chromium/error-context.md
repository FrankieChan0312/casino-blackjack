# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m10\initialDeal.spec.ts >> [T06-B02-7-768] checkpoint captures actual start/first/second/settled
- Location: tests\browser\m10\initialDeal.spec.ts:55:103

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-deal-target="round-1/seat-1:0"]')
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('[data-deal-target="round-1/seat-1:0"]') with timeout 5000ms
  - waiting for locator('[data-deal-target="round-1/seat-1:0"]')
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- main [ref=e3]:
  - link "Skip to your hand and actions" [ref=e4] [cursor=pointer]:
    - /url: "#player-decisions"
  - region "Blackjack game scene" [ref=e5]:
    - generic [ref=e6]:
      - generic [ref=e7]:
        - paragraph [ref=e8]: An evening at the table
        - heading "Casino Blackjack" [level=1] [ref=e9]
      - paragraph [ref=e10]: Simulation credits only — no real-money gambling.Credits have no redemption value.
    - generic [ref=e11]:
      - region "Blackjack table" [ref=e12]:
        - region "Dealer" [ref=e13]:
          - 'img "Dealer: Celestine" [ref=e14]'
          - heading "Dealer" [level=2] [ref=e15]
          - group "Dealer hand" [ref=e16]:
            - generic [ref=e17]:
              - img "4 of spades" [ref=e19]:
                - generic [ref=e20]:
                  - text: "4"
                  - generic [aria-hidden] [ref=e21]: ♠
                - generic [aria-hidden] [ref=e22]: ♠
                - generic [aria-hidden] [ref=e23]: "4"
              - img "Hidden dealer card" [ref=e24]: ◆
            - paragraph [ref=e25]: "Visible total: 4"
            - paragraph [ref=e26]: Hole card hidden
          - group "Shoe and deal origin" [ref=e27]:
            - paragraph [ref=e29]:
              - text: Shoe · Deal origin
              - generic [ref=e30]: 6 decks
          - paragraph [ref=e31]:
            - text: BLACKJACK PAYS 3:2
            - generic [ref=e32]: DEALER STANDS ON ALL 17
        - generic [ref=e33]:
          - region "Seat 1" [ref=e34]:
            - generic [ref=e35]:
              - generic [ref=e36]:
                - 'img "Computer guest: Caelan, Male Elf" [ref=e37]'
                - generic [ref=e38]:
                  - heading "Caelan" [level=2] [ref=e39]
                  - paragraph [ref=e40]: Male Elf
                  - paragraph [ref=e41]: Seat 1 · Computer
              - group [ref=e42]:
                - article "Hand A" [ref=e43]:
                  - generic [ref=e44]:
                    - img "J of hearts" [ref=e45]:
                      - generic [ref=e46]:
                        - text: J
                        - generic [aria-hidden] [ref=e47]: ♥
                      - generic [aria-hidden] [ref=e48]: ♥
                      - generic [aria-hidden] [ref=e49]: J
                    - img "6 of diamonds" [ref=e50]:
                      - generic [ref=e51]:
                        - text: "6"
                        - generic [aria-hidden] [ref=e52]: ♦
                      - generic [aria-hidden] [ref=e53]: ♦
                      - generic [aria-hidden] [ref=e54]: "6"
                    - img "3 of spades" [ref=e55]:
                      - generic [ref=e56]:
                        - text: "3"
                        - generic [aria-hidden] [ref=e57]: ♠
                      - generic [aria-hidden] [ref=e58]: ♠
                      - generic [aria-hidden] [ref=e59]: "3"
                  - generic [ref=e60]:
                    - paragraph [ref=e61]: "19"
                    - paragraph [ref=e62]: Decisions complete
                    - paragraph [ref=e63]: "MAIN: 25 credits"
          - region "Seat 2" [ref=e64]:
            - generic [ref=e65]:
              - generic [ref=e66]:
                - 'img "Computer guest: Elaria, Female Elf" [ref=e67]'
                - generic [ref=e68]:
                  - heading "Elaria" [level=2] [ref=e69]
                  - paragraph [ref=e70]: Female Elf
                  - paragraph [ref=e71]: Seat 2 · Computer
              - group [ref=e72]:
                - article "Hand A" [ref=e73]:
                  - generic [ref=e74]:
                    - img "A of hearts" [ref=e75]:
                      - generic [ref=e76]:
                        - text: A
                        - generic [aria-hidden] [ref=e77]: ♥
                      - generic [aria-hidden] [ref=e78]: ♥
                      - generic [aria-hidden] [ref=e79]: A
                    - img "K of clubs" [ref=e80]:
                      - generic [ref=e81]:
                        - text: K
                        - generic [aria-hidden] [ref=e82]: ♣
                      - generic [aria-hidden] [ref=e83]: ♣
                      - generic [aria-hidden] [ref=e84]: K
                  - generic [ref=e85]:
                    - paragraph [ref=e86]: "21"
                    - paragraph [ref=e87]: Blackjack
                    - paragraph [ref=e88]: "MAIN: 25 credits"
          - region "Seat 3" [ref=e89]:
            - generic [ref=e90]:
              - generic [ref=e91]:
                - 'img "Computer guest: Seraphine, Female Human Knight" [ref=e92]'
                - generic [ref=e93]:
                  - heading "Seraphine" [level=2] [ref=e94]
                  - paragraph [ref=e95]: Female Human Knight
                  - paragraph [ref=e96]: Seat 3 · Computer
              - group [ref=e97]:
                - article "Hand A" [ref=e98]:
                  - generic [ref=e99]:
                    - img "5 of hearts" [ref=e100]:
                      - generic [ref=e101]:
                        - text: "5"
                        - generic [aria-hidden] [ref=e102]: ♥
                      - generic [aria-hidden] [ref=e103]: ♥
                      - generic [aria-hidden] [ref=e104]: "5"
                    - img "2 of clubs" [ref=e105]:
                      - generic [ref=e106]:
                        - text: "2"
                        - generic [aria-hidden] [ref=e107]: ♣
                      - generic [aria-hidden] [ref=e108]: ♣
                      - generic [aria-hidden] [ref=e109]: "2"
                    - img "5 of diamonds" [ref=e110]:
                      - generic [ref=e111]:
                        - text: "5"
                        - generic [aria-hidden] [ref=e112]: ♦
                      - generic [aria-hidden] [ref=e113]: ♦
                      - generic [aria-hidden] [ref=e114]: "5"
                    - img "7 of diamonds" [ref=e115]:
                      - generic [ref=e116]:
                        - text: "7"
                        - generic [aria-hidden] [ref=e117]: ♦
                      - generic [aria-hidden] [ref=e118]: ♦
                      - generic [aria-hidden] [ref=e119]: "7"
                  - generic [ref=e120]:
                    - paragraph [ref=e121]: "19"
                    - paragraph [ref=e122]: Decisions complete
                    - paragraph [ref=e123]: "MAIN: 25 credits"
          - region "Seat 4" [active] [ref=e124]:
            - group "Your player HUD" [ref=e125]:
              - generic [ref=e126]:
                - generic [ref=e127]:
                  - 'img "Your avatar: Roland, Male Human Knight" [ref=e128]'
                  - generic [ref=e129]:
                    - paragraph [ref=e130]: YOU
                    - heading "Roland" [level=2] [ref=e131]: ▸ Roland
                    - paragraph [ref=e132]: Male Human Knight
                    - paragraph [ref=e133]: Seat 4 · You · Human
                - paragraph [ref=e134]: "MAIN: 100 credits"
              - article "Hand A" [ref=e136]:
                - generic [ref=e137]:
                  - heading "Hand A · Current hand" [level=3] [ref=e138]
                  - generic [ref=e139]: ACTIVE
                - generic [ref=e140]:
                  - img "9 of hearts" [ref=e141]:
                    - generic [ref=e142]:
                      - text: "9"
                      - generic [aria-hidden] [ref=e143]: ♥
                    - generic [aria-hidden] [ref=e144]: ♥
                    - generic [aria-hidden] [ref=e145]: "9"
                  - img "K of spades" [ref=e146]:
                    - generic [ref=e147]:
                      - text: K
                      - generic [aria-hidden] [ref=e148]: ♠
                    - generic [aria-hidden] [ref=e149]: ♠
                    - generic [aria-hidden] [ref=e150]: K
                - generic [ref=e151]:
                  - paragraph [ref=e152]:
                    - text: "Total:"
                    - strong [ref=e153]: "19"
                  - paragraph [ref=e154]: "Wager: 100 credits"
                  - paragraph [ref=e155]: Playing
          - region "Seat 5" [ref=e156]:
            - generic [ref=e157]:
              - generic [ref=e158]:
                - 'img "Computer guest: Alaric, Male Mage" [ref=e159]'
                - generic [ref=e160]:
                  - heading "Alaric" [level=2] [ref=e161]
                  - paragraph [ref=e162]: Male Mage
                  - paragraph [ref=e163]: Seat 5 · Computer
              - group [ref=e164]:
                - article "Hand A" [ref=e165]:
                  - generic [ref=e166]:
                    - img "4 of clubs" [ref=e167]:
                      - generic [ref=e168]:
                        - text: "4"
                        - generic [aria-hidden] [ref=e169]: ♣
                      - generic [aria-hidden] [ref=e170]: ♣
                      - generic [aria-hidden] [ref=e171]: "4"
                    - img "9 of spades" [ref=e172]:
                      - generic [ref=e173]:
                        - text: "9"
                        - generic [aria-hidden] [ref=e174]: ♠
                      - generic [aria-hidden] [ref=e175]: ♠
                      - generic [aria-hidden] [ref=e176]: "9"
                  - generic [ref=e177]:
                    - paragraph [ref=e178]: "13"
                    - paragraph [ref=e179]: Playing
                    - paragraph [ref=e180]: "MAIN: 25 credits"
          - region "Seat 6" [ref=e181]:
            - generic [ref=e182]:
              - generic [ref=e183]:
                - 'img "Computer guest: Nyra, Female Mage" [ref=e184]'
                - generic [ref=e185]:
                  - heading "Nyra" [level=2] [ref=e186]
                  - paragraph [ref=e187]: Female Mage
                  - paragraph [ref=e188]: Seat 6 · Computer
              - group [ref=e189]:
                - article "Hand A" [ref=e190]:
                  - generic [ref=e191]:
                    - img "5 of diamonds" [ref=e192]:
                      - generic [ref=e193]:
                        - text: "5"
                        - generic [aria-hidden] [ref=e194]: ♦
                      - generic [aria-hidden] [ref=e195]: ♦
                      - generic [aria-hidden] [ref=e196]: "5"
                    - img "Q of clubs" [ref=e197]:
                      - generic [ref=e198]:
                        - text: Q
                        - generic [aria-hidden] [ref=e199]: ♣
                      - generic [aria-hidden] [ref=e200]: ♣
                      - generic [aria-hidden] [ref=e201]: Q
                  - generic [ref=e202]:
                    - paragraph [ref=e203]: "15"
                    - paragraph [ref=e204]: Playing
                    - paragraph [ref=e205]: "MAIN: 25 credits"
          - region "Seat 7" [ref=e206]:
            - generic [ref=e207]:
              - generic [ref=e208]:
                - 'img "Computer guest: Lucien, Male Noble" [ref=e209]'
                - generic [ref=e210]:
                  - heading "Lucien" [level=2] [ref=e211]
                  - paragraph [ref=e212]: Male Noble
                  - paragraph [ref=e213]: Seat 7 · Computer
              - group [ref=e214]:
                - article "Hand A" [ref=e215]:
                  - generic [ref=e216]:
                    - img "8 of spades" [ref=e217]:
                      - generic [ref=e218]:
                        - text: "8"
                        - generic [aria-hidden] [ref=e219]: ♠
                      - generic [aria-hidden] [ref=e220]: ♠
                      - generic [aria-hidden] [ref=e221]: "8"
                    - img "10 of clubs" [ref=e222]:
                      - generic [ref=e223]:
                        - text: "10"
                        - generic [aria-hidden] [ref=e224]: ♣
                      - generic [aria-hidden] [ref=e225]: ♣
                      - generic [aria-hidden] [ref=e226]: "10"
                  - generic [ref=e227]:
                    - paragraph [ref=e228]: "18"
                    - paragraph [ref=e229]: Playing
                    - paragraph [ref=e230]: "MAIN: 25 credits"
      - region "Your gameplay controls" [ref=e231]:
        - generic [ref=e232]:
          - status [ref=e233]: Your turn
          - generic [ref=e234]: · Hand A
        - region "Primary actions" [ref=e235]:
          - generic [ref=e236]:
            - button "Hit" [ref=e237] [cursor=pointer]
            - button "Stand" [ref=e238] [cursor=pointer]
            - button "Double" [ref=e239] [cursor=pointer]
            - button "Split" [disabled] [ref=e240]
            - button "Surrender" [ref=e241] [cursor=pointer]
          - group [ref=e242]:
            - generic "Action guidance · Unavailable actions explained" [ref=e243] [cursor=pointer]
        - region "Your credits" [ref=e244]:
          - heading "Credits" [level=2] [ref=e245]
          - generic [ref=e246]:
            - generic [ref=e247]:
              - term [ref=e248]: Available
              - definition [ref=e249]: "900"
            - generic [ref=e250]:
              - term [ref=e251]: Reserved / current exposure
              - definition [ref=e252]: "100"
            - generic [ref=e253]:
              - term [ref=e254]: Pending return
              - definition [ref=e255]: "0"
    - paragraph [ref=e256]: Existing 6-deck shoe continues · Computer guests play with their own simulation credits.
  - complementary "Table preferences and demo tools" [ref=e257]:
    - generic [ref=e258]:
      - paragraph [ref=e259]: 7 players · 1 human · 6 computer guests
      - button "New table · reset to 1000 credits" [disabled] [ref=e260]
    - group [ref=e261]:
      - generic "Change Character · Roland" [ref=e262] [cursor=pointer]
      - option "Caelan · Male Elf"
      - option "Elaria · Female Elf"
      - option "Roland · Male Human Knight" [selected]
      - option "Seraphine · Female Human Knight"
      - option "Alaric · Male Mage"
      - option "Nyra · Female Mage"
      - option "Lucien · Male Noble"
      - option "Celestine · Female Noble · Dealer (reserved for this table)" [disabled]
      - option "Garruk · Male Half-Orc Warrior"
      - option "Vesha · Female Half-Orc Warrior"
      - option "Borin · Male Dwarf"
      - option "Brynja · Female Dwarf"
    - group [ref=e263]:
      - generic "Developer / demo tools" [ref=e264] [cursor=pointer]
      - option "Classic Blackjack" [selected]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { writeFileSync, mkdirSync } from 'node:fs';
  3   | import { Buffer } from 'node:buffer';
  4   | 
  5   | test.use({ reducedMotion: 'no-preference' });
  6   | const seats: Record<number, number[]> = { 1: [4], 4: [1,3,4,6], 7: [1,2,3,4,5,6,7] };
  7   | type Trace = { arrivals: string[]; flights: string[]; duplicate: boolean; overlap: boolean; started: number; finished: number; paused: boolean; checkpoints: string[] };
  8   | async function setup(page: Page, count: number) {
  9   |   await page.goto('/?fixture=player-setup');
  10  |   await page.getByLabel('Total players', { exact: true }).selectOption(String(count));
  11  |   await page.getByRole('button', { name: 'Start table', exact: true }).click();
  12  |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  13  | }
  14  | async function observe(page: Page, checkpoints: string[] = []) {
  15  |   await page.evaluate(checkpoints => {
  16  |     const trace: Trace = { arrivals: [], flights: [], duplicate: false, overlap: false, started: performance.now(), finished: 0, paused: false, checkpoints };
  17  |     (window as unknown as { dealTrace: Trace }).dealTrace = trace;
  18  |     new MutationObserver(records => {
  19  |       for (const record of records) for (const node of record.addedNodes) if (node instanceof HTMLElement && node.dataset.initialDealFlight) {
  20  |         const target = node.dataset.dealTarget!;
  21  |         if (trace.flights.includes(target)) trace.duplicate = true;
  22  |         trace.flights.push(target);
  23  |         trace.overlap ||= document.querySelectorAll('[data-initial-deal-flight]').length > 1;
  24  |         if (trace.checkpoints.includes(target)) {
  25  |           node.getAnimations({ subtree: true }).forEach(animation => animation.pause()); trace.paused = true;
  26  |         }
  27  |       }
  28  |       for (const element of document.querySelectorAll<HTMLElement>('[data-card-slot][data-deal-visible="true"]')) {
  29  |         const key = element.dataset.cardSlot!;
  30  |         if (Number(key.slice(key.lastIndexOf(':') + 1)) < 2 && !trace.arrivals.includes(key)) trace.arrivals.push(key);
  31  |       }
  32  |       if (document.querySelector('[data-initial-deal-running="false"]') && trace.flights.length) trace.finished = performance.now();
  33  |     }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-deal-visible','data-initial-deal-running'] });
  34  |   }, checkpoints);
  35  | }
  36  | const trace = (page: Page) => page.evaluate(() => (window as unknown as { dealTrace: Trace }).dealTrace);
  37  | for (const count of [1,4,7]) test(`[T06-B01-${count}] real FULL_MOTION two-pass order, one clone, no premature arrival`, async ({ page }, info) => {
  38  |   await setup(page, count); await observe(page);
  39  |   const dealer = await page.locator('[data-dealer-character]').getAttribute('data-dealer-character');
  40  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  41  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  42  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-presentation-state', 'DEALING');
  43  |   await expect(page.locator('[data-card-slot][data-deal-visible="true"]')).toHaveCount(0);
  44  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  45  |   const result = await trace(page), order = [0,1].flatMap(index => [...seats[count].map(seat => `round-1/seat-${seat}:${index}`), `dealer:${index}`]);
  46  |   expect(result.flights).toEqual(order); expect(result.arrivals).toEqual(order);
  47  |   expect(result.duplicate).toBe(false); expect(result.overlap).toBe(false);
  48  |   expect(result.finished - result.started).toBeLessThan(4000);
  49  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  50  |   await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toHaveCount(1);
  51  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  52  |   writeFileSync(info.outputPath('sequence.json'), JSON.stringify(result, null, 2));
  53  | });
  54  | 
  55  | for (const [count,width,height] of [[1,1280,900],[4,1280,900],[7,1280,900],[7,768,1024],[7,320,720]]) test(`[T06-B02-${count}-${width}] checkpoint captures actual start/first/second/settled`, async ({ page }) => {
  56  |   const root = 'docs/M10_T06_EVIDENCE/screenshots'; mkdirSync(root, { recursive: true });
  57  |     await page.setViewportSize({ width, height }); await setup(page, count);
  58  |     const checkpoints = count === 1 ? ['round-1/seat-4:0','dealer:0','round-1/seat-4:1','dealer:1']
  59  |       : [`round-1/seat-${seats[count][0]}:0`, `round-1/seat-${seats[count][Math.floor(count/2)]}:0`, `round-1/seat-${seats[count][0]}:1`, `round-1/seat-${seats[count][Math.floor(count/2)]}:1`];
  60  |     await observe(page, checkpoints); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  61  |     for (const [index,target] of checkpoints.entries()) {
  62  |       await expect.poll(async () => (await trace(page)).paused && await page.locator(`[data-deal-target="${target}"]`).count() === 1).toBe(true);
  63  |       const cdp = await page.context().newCDPSession(page);
  64  |       const clip = await page.evaluate(() => ({ x: 0, y: 0, width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight, scale: 1 }));
  65  |       const capture = await cdp.send('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: true, clip });
  66  |       await cdp.detach();
  67  |       writeFileSync(`${root}/${count}-${width}-${['start','mid-first-pass','end-first-pass','mid-second-pass'][index]}.png`, Buffer.from(capture.data, 'base64'));
> 68  |       await expect(page.locator(`[data-deal-target="${target}"]`)).toHaveCount(1);
      |                                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  69  |       await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  70  |       await page.evaluate(() => {
  71  |         const trace = (window as unknown as { dealTrace: Trace }).dealTrace;
  72  |         trace.paused = false; document.querySelectorAll<HTMLElement>('[data-initial-deal-flight]').forEach(element => element.getAnimations({ subtree: true }).forEach(animation => animation.play()));
  73  |       });
  74  |     }
  75  |     await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  76  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  77  |     await page.screenshot({ path: `${root}/${count}-${width}-settled.png`, fullPage: true });
  78  |     writeFileSync(`${root}/${count}-${width}-sequence.json`, JSON.stringify(await trace(page), null, 2));
  79  | });
  80  | 
  81  | test('[T06-B03] skip/keyboard legal action settles before dispatch; new round/new table never replay stale cards', async ({ page }) => {
  82  |   await page.goto('/?fixture=player-split'); await observe(page);
  83  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  84  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  85  |   await page.getByRole('button', { name: 'Split', exact: true }).focus(); await page.keyboard.press('Enter');
  86  |   await expect(page.locator('#player-hand article')).toHaveCount(2); await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  87  |   await expect(page.locator('#player-hand [data-deal-visible="false"]')).toHaveCount(0);
  88  |   for (let index = 0; index < 2; index++) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  89  |   const dealer = await page.locator('.dealer-zone').getAttribute('data-dealer-character');
  90  |   await page.getByRole('button', { name: /^Repeat Bet/ }).click();
  91  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  92  |   await page.getByRole('button', { name: 'Skip animations', exact: true }).click();
  93  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  94  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  95  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  96  |   if (await page.getByRole('button', { name: 'Decline', exact: true }).count()) await page.getByRole('button', { name: 'Decline', exact: true }).click();
  97  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  98  |   await page.getByRole('button', { name: 'New table · reset to 1000 credits', exact: true }).click();
  99  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0); await expect(page.locator('[data-card-slot]')).toHaveCount(0);
  100 | });
  101 | 
  102 | test('[T06-B04] resize/background/text200 settle safely, keep native focus and bounded geometry', async ({ page }) => {
  103 |   await setup(page, 7); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  104 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(1);
  105 |   await page.setViewportSize({ width: 768, height: 1024 });
  106 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  107 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  108 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  109 |   await page.goto('/?fixture=player-split'); await page.addStyleTag({ content: 'html {font-size: 200%}' });
  110 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  111 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange')); });
  112 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  113 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  114 |   const stand = page.getByRole('button', { name: 'Stand', exact: true }); await stand.focus(); await expect(stand).toBeFocused();
  115 |   const box = await stand.boundingBox(); expect(box!.width).toBeGreaterThanOrEqual(44); expect(box!.height).toBeGreaterThanOrEqual(44);
  116 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  117 | });
  118 | 
  119 | test('[T06-B05] reduced preference settles without flights; IMMEDIATE uses the identical authoritative result', async ({ page }) => {
  120 |   await page.emulateMedia({ reducedMotion: 'reduce' }); await setup(page, 7); await observe(page);
  121 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  122 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  123 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  124 |   expect((await trace(page)).flights).toEqual([]);
  125 |   const result = await page.evaluate(async () => {
  126 |     const fixtureUrl = '/tests/browser/fixtures.ts', providerUrl = '/src/ui/PresentationProvider.tsx';
  127 |     const { createFixtureController } = await import(fixtureUrl), { createPresentationRuntime, connectPresentation } = await import(providerUrl);
  128 |     const receipts = [];
  129 |     for (const mode of ['IMMEDIATE','REDUCED_MOTION']) {
  130 |       const controller = createFixtureController('player'), runtime = createPresentationRuntime();
  131 |       const disconnect = connectPresentation(controller.presentation, runtime, mode);
  132 |       controller.dispatch({ type: 'DEAL', amount: 200 });
  133 |       receipts.push({ authority: controller.getSnapshot(), projection: runtime.initialDeal.getSnapshot().pending, active: runtime.timeline.getSnapshot().activeId });
  134 |       disconnect();
  135 |     }
  136 |     return receipts;
  137 |   });
  138 |   expect(result[0]).toEqual(result[1]); expect(result[0].active).toBeNull(); expect(result[0].projection).toEqual([]);
  139 |   await page.screenshot({ path: 'docs/M10_T06_EVIDENCE/reduced-seven-settled.png', fullPage: true });
  140 | });
  141 | 
  142 | test('[T06-B06] real Provider unmount cancels the active flight, leaves authority and late callbacks unchanged', async ({ page }) => {
  143 |   await page.goto('/?fixture=player');
  144 |   const result = await page.evaluate(async () => {
  145 |     const providerUrl = '/src/ui/PresentationProvider.tsx', cardsUrl = '/src/ui/Cards.tsx', fixtureUrl = '/tests/browser/fixtures.ts';
  146 |     const reactUrl = '/node_modules/.vite/deps/react.js', rootUrl = '/node_modules/.vite/deps/react-dom_client.js';
  147 |     const { PresentationProvider, usePresentationAnchor, usePresentationRuntime } = await import(providerUrl), { Cards, HiddenDealerCard } = await import(cardsUrl);
  148 |     const { createFixtureController } = await import(fixtureUrl), { default: React } = await import(reactUrl), { default: ReactDOM } = await import(rootUrl);
  149 |     const controller = createFixtureController('player-split'); controller.dispatch({ type: 'DEAL', amount: 200 });
  150 |     const authority = JSON.stringify(controller.getSnapshot()), hand = controller.getSnapshot().round.seats.find((seat: { seatNumber: number }) => seat.seatNumber === 4).hands[0];
  151 |     const host = document.createElement('div'); document.body.append(host); const root = ReactDOM.createRoot(host);
  152 |     let runtime: ReturnType<typeof usePresentationRuntime>;
  153 |     function Probe() {
  154 |       runtime = usePresentationRuntime(); const origin = usePresentationAnchor('deal-origin');
  155 |       return React.createElement('div', null, React.createElement('div', { ref: origin }, 'Shoe'), React.createElement(Cards, { cards: hand.cards, ownerId: hand.handId }), React.createElement(HiddenDealerCard));
  156 |     }
  157 |     const started = new Promise<void>(resolve => {
  158 |       const observer = new MutationObserver(() => { if (document.querySelector('[data-initial-deal-flight]')) { observer.disconnect(); resolve(); } });
  159 |       observer.observe(document.body, { subtree: true, childList: true });
  160 |     });
  161 |     root.render(React.createElement(PresentationProvider, { feed: controller.presentation }, React.createElement(Probe))); await started;
  162 |     const active = runtime!.timeline.getSnapshot().activeId; root.unmount(); host.remove();
  163 |     await Promise.resolve();
  164 |     return { active, remaining: document.querySelectorAll('[data-initial-deal-flight]').length, snapshot: runtime!.timeline.getSnapshot(), same: JSON.stringify(controller.getSnapshot()) === authority };
  165 |   });
  166 |   expect(result.active).not.toBeNull(); expect(result.remaining).toBe(0); expect(result.snapshot).toMatchObject({ activeId: null, pending: 0 }); expect(result.same).toBe(true);
  167 | });
  168 | 
```