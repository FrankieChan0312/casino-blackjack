# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m10\initialDeal.spec.ts >> [T06-B01-7] real FULL_MOTION two-pass order, one clone, no premature arrival
- Location: tests\browser\m10\initialDeal.spec.ts:36:30

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 30000ms exceeded.
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { writeFileSync, mkdirSync } from 'node:fs';
  3   | 
  4   | test.use({ reducedMotion: 'no-preference' });
  5   | const seats: Record<number, number[]> = { 1: [4], 4: [1,3,4,6], 7: [1,2,3,4,5,6,7] };
  6   | type Trace = { arrivals: string[]; flights: string[]; duplicate: boolean; overlap: boolean; started: number; finished: number; paused: boolean; checkpoints: string[] };
  7   | async function setup(page: Page, count: number) {
  8   |   await page.goto('/?fixture=player-setup');
> 9   |   await page.getByLabel('Total players', { exact: true }).selectOption(String(count));
      |                                                           ^ Error: locator.selectOption: Test timeout of 30000ms exceeded.
  10  |   await page.getByRole('button', { name: 'Start table', exact: true }).click();
  11  |   await page.getByLabel('Your main wager', { exact: false }).fill('100');
  12  | }
  13  | async function observe(page: Page, checkpoints: string[] = []) {
  14  |   await page.evaluate(checkpoints => {
  15  |     const trace: Trace = { arrivals: [], flights: [], duplicate: false, overlap: false, started: performance.now(), finished: 0, paused: false, checkpoints };
  16  |     (window as unknown as { dealTrace: Trace }).dealTrace = trace;
  17  |     new MutationObserver(records => {
  18  |       for (const record of records) for (const node of record.addedNodes) if (node instanceof HTMLElement && node.dataset.initialDealFlight) {
  19  |         const target = node.dataset.dealTarget!;
  20  |         if (trace.flights.includes(target)) trace.duplicate = true;
  21  |         trace.flights.push(target);
  22  |         trace.overlap ||= document.querySelectorAll('[data-initial-deal-flight]').length > 1;
  23  |         if (trace.checkpoints.includes(target)) {
  24  |           node.getAnimations({ subtree: true }).forEach(animation => animation.pause()); trace.paused = true;
  25  |         }
  26  |       }
  27  |       for (const element of document.querySelectorAll<HTMLElement>('[data-card-slot][data-deal-visible="true"]')) {
  28  |         const key = element.dataset.cardSlot!;
  29  |         if (Number(key.slice(key.lastIndexOf(':') + 1)) < 2 && !trace.arrivals.includes(key)) trace.arrivals.push(key);
  30  |       }
  31  |       if (document.querySelector('[data-initial-deal-running="false"]') && trace.flights.length) trace.finished = performance.now();
  32  |     }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-deal-visible','data-initial-deal-running'] });
  33  |   }, checkpoints);
  34  | }
  35  | const trace = (page: Page) => page.evaluate(() => (window as unknown as { dealTrace: Trace }).dealTrace);
  36  | for (const count of [1,4,7]) test(`[T06-B01-${count}] real FULL_MOTION two-pass order, one clone, no premature arrival`, async ({ page }, info) => {
  37  |   await setup(page, count); await observe(page);
  38  |   const dealer = await page.locator('[data-dealer-character]').getAttribute('data-dealer-character');
  39  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  40  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  41  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-presentation-state', 'DEALING');
  42  |   await expect(page.locator('[data-card-slot][data-deal-visible="true"]')).toHaveCount(0);
  43  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  44  |   const result = await trace(page), order = [0,1].flatMap(index => [...seats[count].map(seat => `round-1/seat-${seat}:${index}`), `dealer:${index}`]);
  45  |   expect(result.flights).toEqual(order); expect(result.arrivals).toEqual(order);
  46  |   expect(result.duplicate).toBe(false); expect(result.overlap).toBe(false);
  47  |   expect(result.finished - result.started).toBeLessThan(4000);
  48  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  49  |   await expect(page.getByRole('img', { name: 'Hidden dealer card', exact: true })).toHaveCount(1);
  50  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  51  |   writeFileSync(info.outputPath('sequence.json'), JSON.stringify(result, null, 2));
  52  | });
  53  | 
  54  | test('[T06-B02] checkpoint captures actual start/first/second/settled 1/4/7 and tablet/mobile', async ({ page }) => {
  55  |   const root = 'docs/M10_T06_EVIDENCE/screenshots'; mkdirSync(root, { recursive: true });
  56  |   for (const [count,width,height] of [[1,1280,900],[4,1280,900],[7,1280,900],[7,768,1024],[7,320,720]]) {
  57  |     await page.setViewportSize({ width, height }); await setup(page, count);
  58  |     const checkpoints = [`round-1/seat-${seats[count][0]}:0`, 'dealer:0', `round-1/seat-${seats[count][Math.floor(count/2)]}:1`];
  59  |     await observe(page, checkpoints); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  60  |     for (const [index,target] of checkpoints.entries()) {
  61  |       await expect.poll(async () => (await trace(page)).paused && await page.locator(`[data-deal-target="${target}"]`).count() === 1).toBe(true);
  62  |       await page.screenshot({ path: `${root}/${count}-${width}-${['start','end-first-pass','mid-second-pass'][index]}.png`, fullPage: true });
  63  |       await page.evaluate(() => {
  64  |         const trace = (window as unknown as { dealTrace: Trace }).dealTrace;
  65  |         trace.paused = false; document.querySelectorAll<HTMLElement>('[data-initial-deal-flight]').forEach(element => element.getAnimations({ subtree: true }).forEach(animation => animation.play()));
  66  |       });
  67  |     }
  68  |     await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  69  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  70  |     await page.screenshot({ path: `${root}/${count}-${width}-settled.png`, fullPage: true });
  71  |     writeFileSync(`${root}/${count}-${width}-sequence.json`, JSON.stringify(await trace(page), null, 2));
  72  |   }
  73  | });
  74  | 
  75  | test('[T06-B03] skip/keyboard legal action settles before dispatch; new round/new table never replay stale cards', async ({ page }) => {
  76  |   await page.goto('/?fixture=player-split'); await observe(page);
  77  |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  78  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  79  |   await page.getByRole('button', { name: 'Split', exact: true }).focus(); await page.keyboard.press('Enter');
  80  |   await expect(page.locator('#player-hand article')).toHaveCount(2); await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  81  |   await expect(page.locator('#player-hand [data-deal-visible="false"]')).toHaveCount(0);
  82  |   for (let index = 0; index < 2; index++) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  83  |   const dealer = await page.locator('.dealer-zone').getAttribute('data-dealer-character');
  84  |   await page.getByRole('button', { name: 'Repeat Bet', exact: true }).click();
  85  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'true');
  86  |   await page.getByRole('button', { name: 'Skip animations', exact: true }).click();
  87  |   await expect(page.locator('.game-scene')).toHaveAttribute('data-initial-deal-running', 'false');
  88  |   await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character', dealer!);
  89  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  90  |   if (await page.getByRole('button', { name: 'Decline', exact: true }).count()) await page.getByRole('button', { name: 'Decline', exact: true }).click();
  91  |   while (await page.getByRole('button', { name: 'Stand', exact: true }).count()) await page.getByRole('button', { name: 'Stand', exact: true }).click();
  92  |   await page.getByRole('button', { name: 'New table · reset to 1000 credits', exact: true }).click();
  93  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0); await expect(page.locator('[data-card-slot]')).toHaveCount(0);
  94  | });
  95  | 
  96  | test('[T06-B04] resize/background/text200 settle safely, keep native focus and bounded geometry', async ({ page }) => {
  97  |   await setup(page, 7); await page.getByRole('button', { name: 'Deal', exact: true }).click();
  98  |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(1);
  99  |   await page.setViewportSize({ width: 768, height: 1024 });
  100 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  101 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  102 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  103 |   await page.goto('/?fixture=player-split'); await page.addStyleTag({ content: 'html {font-size: 200%}' });
  104 |   await page.getByRole('button', { name: 'Deal', exact: true }).click();
  105 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange')); });
  106 |   await expect(page.locator('[data-initial-deal-flight]')).toHaveCount(0);
  107 |   await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  108 |   const stand = page.getByRole('button', { name: 'Stand', exact: true }); await stand.focus(); await expect(stand).toBeFocused();
  109 |   const box = await stand.boundingBox(); expect(box!.width).toBeGreaterThanOrEqual(44); expect(box!.height).toBeGreaterThanOrEqual(44);
```