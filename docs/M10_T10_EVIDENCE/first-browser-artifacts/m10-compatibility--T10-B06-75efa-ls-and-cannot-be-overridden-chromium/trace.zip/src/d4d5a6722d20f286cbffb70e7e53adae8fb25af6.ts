import { test, expect, type Page } from '@playwright/test';
import { mkdirSync, writeFileSync } from 'node:fs';
import { Buffer } from 'node:buffer';

test.use({reducedMotion:'no-preference'});
const modes=['FULL_MOTION','REDUCED_MOTION','IMMEDIATE'] as const;
const overlays='[data-initial-deal-flight],[data-action-card-flight],[data-split-flight],[data-dealer-reveal],[data-wager-flight]';
async function open(page:Page,fixture:string,mode:typeof modes[number]='FULL_MOTION') {
  await page.emulateMedia({reducedMotion:mode==='REDUCED_MOTION'?'reduce':'no-preference'});
  await page.goto(`/?fixture=${fixture}${mode==='IMMEDIATE'?'&motion=IMMEDIATE':''}`);
  await expect(page.locator('.game-scene')).toHaveAttribute('data-presentation-mode',mode);
}
async function settled(page:Page) {
  for(const flag of ['initial-deal','player-actions','dealer-actions','wagers']) await expect(page.locator('.game-scene')).toHaveAttribute(`data-${flag}-running`,'false');
  await expect(page.locator(overlays)).toHaveCount(0);
}
async function deal(page:Page) {
  await page.getByLabel('Your main wager',{exact:false}).fill('100');await page.getByRole('button',{name:'Deal',exact:true}).click();
  await settled(page);
}
async function finish(page:Page) {
  for(let index=0;index<10 && !await page.getByRole('button',{name:'Deal Again',exact:true}).count();index++) {
    const decline=page.getByRole('button',{name:'Decline',exact:true});
    if(await decline.count()) await decline.click(); else await page.getByRole('button',{name:'Stand',exact:true}).click();
  }
  await expect(page.getByRole('button',{name:'Deal Again',exact:true})).toBeEnabled();await settled(page);
}
async function capture(page:Page,path:string) {
  const cdp=await page.context().newCDPSession(page),shot=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});
  await cdp.detach();writeFileSync(path,Buffer.from(shot.data,'base64'));
}
for(const [count,width,height] of [[1,1280,900],[4,768,1024],[7,320,720]] as const)test(`[T10-B01-${count}] actual ${count}-player three-mode replay/package/audit equality and round/table lifecycle`,async({page})=>{
  const receipts=[];
  for(const mode of modes) {
    await page.setViewportSize({width,height});await open(page,'player-setup',mode);
    await page.getByLabel('Total players',{exact:true}).selectOption(String(count));await page.getByRole('button',{name:'Start table',exact:true}).click();
    const dealer=await page.locator('.dealer-zone').getAttribute('data-dealer-character');
    await page.evaluate(()=>{
      const timing:{start:number|null;end:number|null;flights:number}={start:null,end:null,flights:0};(window as unknown as {initialTiming:typeof timing}).initialTiming=timing;
      new MutationObserver(records=>{for(const record of records){for(const node of record.addedNodes)if(node instanceof HTMLElement&&node.dataset.initialDealFlight){timing.start??=performance.now();timing.flights++;}
        if(record.type==='attributes'&&record.target instanceof HTMLElement&&record.target.dataset.initialDealRunning==='false'&&timing.start!==null) timing.end??=performance.now();
      }}).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-initial-deal-running']});
    });
    await deal(page);await expect(page.locator('[data-seat-anchor]')).toHaveCount(count);
    const timing=await page.evaluate(()=>(window as unknown as {initialTiming:{start:number|null;end:number|null;flights:number}}).initialTiming);
    if(mode==='FULL_MOTION'){expect(timing.flights).toBe(count===1?4:count===4?10:16);expect(timing.end!-timing.start!).toBeLessThanOrEqual(2500);}else expect(timing.flights).toBe(0);
    const root=`docs/M10_T10_EVIDENCE/browser/${Date.now()}-${count}-${mode}`;mkdirSync(root,{recursive:true});await capture(page,`${root}/initial-settled.png`);
    await finish(page);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
    await page.screenshot({path:`${root}/round-settled.png`,fullPage:true});
    const credits=await page.getByRole('region',{name:'Your credits',exact:true}).locator('dd').allTextContents();
    const cards=await page.locator('[data-card-slot]').evaluateAll(elements=>elements.map(element=>[element.getAttribute('data-card-slot'),element.getAttribute('aria-label'),getComputedStyle(element).opacity]));
    await page.getByText('Developer / demo tools',{exact:true}).click();await page.getByRole('button',{name:'View replay package',exact:true}).click();
    const packet=JSON.parse(await page.getByLabel('Completed replay JSON',{exact:true}).inputValue());
    await page.getByRole('button',{name:'Replay completed session',exact:true}).click();await expect(page.getByRole('region',{name:'Replay result',exact:true})).toBeVisible();
    const fingerprint=await page.locator('.replay-result > p').first().textContent(),audit=await page.locator('.audit-list').textContent();
    await expect(page.locator(overlays)).toHaveCount(0);receipts.push({credits,cards,packet,fingerprint,audit,dealer});
    writeFileSync(`${root}/receipt.json`,JSON.stringify({count,mode,viewport:{width,height},initialTiming:timing,credits,fingerprint,replay:'immediate terminal summary; original live table preserved',files:['initial-settled.png','round-settled.png']},null,2));
    await page.getByRole('button',{name:'Deal Again',exact:true}).click();await settled(page);
    await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character',dealer!);await expect(page.locator('[data-seat-anchor]')).toHaveCount(count);
    await page.getByRole('button',{name:'New table · reset to 1000 credits',exact:true}).click();await settled(page);
    await expect(page.locator('[data-card-slot]')).toHaveCount(0);await page.getByLabel('Total players',{exact:true}).selectOption(String(count));
    await page.getByRole('button',{name:'Start table',exact:true}).click();await settled(page);
    await expect(page.locator('.dealer-zone')).not.toHaveAttribute('data-dealer-character',dealer!);await expect(page.locator('[data-seat-anchor]')).toHaveCount(count);
  }
  expect(receipts[1]).toEqual(receipts[0]);expect(receipts[2]).toEqual(receipts[0]);
});
for(const mode of modes)test(`[T10-B02-${mode}] one-player forced Double, two Dealer draws and exact final credits`,async({page})=>{
  await open(page,'player-one-actions',mode);await deal(page);await page.getByRole('button',{name:'Double',exact:true}).click();await settled(page);
  await expect(page.locator('#player-hand [data-card-slot]')).toHaveCount(3);await expect(page.locator('.dealer-zone [data-card-slot]')).toHaveCount(4);
  await expect(page.locator('.dealer-total')).toHaveText('Total: 21');await expect(page.getByRole('region',{name:'Your credits',exact:true}).locator('dd')).toHaveText(['800','0','0']);
});
for(const mode of modes)test(`[T10-B03-${mode}] four RSA leaves and Insurance/Even Money settle without stale cards or money`,async({page})=>{
  await open(page,'player-rsa-cap',mode);await deal(page);
  for(let index=0;index<3;index++) await page.getByRole('button',{name:'Split',exact:true}).click();await settled(page);
  await expect(page.locator('.hud-hand')).toHaveCount(4);await expect(page.locator('#player-hand [data-card-slot]')).toHaveCount(8);
  await expect(page.getByRole('region',{name:'Your credits',exact:true}).locator('dd')).toHaveText(['600','0','0']);
  await open(page,'player-ace',mode);await deal(page);await page.getByRole('button',{name:'Buy Insurance',exact:true}).click();await settled(page);
  await expect(page.locator('[data-card-slot="dealer:1"]')).toHaveAttribute('aria-label','Hidden dealer card');await finish(page);
  await expect(page.getByRole('region',{name:'Your credits',exact:true}).locator('dd')).toHaveText(['850','0','0']);
  await open(page,'player-even-money',mode);await deal(page);await page.getByRole('button',{name:'Take Even Money',exact:true}).click();await settled(page);
  await expect(page.getByRole('region',{name:'Your credits',exact:true}).locator('dd')).toHaveText(['1,100','0','0']);
});
async function pausePhase(page:Page,phase:string) {
  await page.evaluate(phase=>{
    const observer=new MutationObserver(()=>{
      const selector=phase==='initial'?'[data-initial-deal-flight]':phase==='split'?'[data-split-flight]':phase==='reveal'?'[data-dealer-reveal]':phase==='draw'?'[data-action-card-flight][data-action-reason="DEALER"]':phase==='settlement'?'[data-wager-flight][data-wager-stage="SETTLE_RESULT"][data-wager-seat="4"]':'[data-action-card-flight]';
      const element=document.querySelector(selector);if(element){element.getAnimations({subtree:true}).forEach(animation=>{animation.pause();animation.currentTime=45;});observer.disconnect();}
    });observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-dealer-reveal']});
  },phase);
}
for(const phase of ['initial','Hit','Double','split','reveal','draw','settlement'])test(`[T10-B04-${phase}] native mid-sequence skip removes every overlay and presents exact current state`,async({page})=>{
  await open(page,phase==='split'?'player-split':phase==='draw'?'player-dealer-multi':'player-loss');
  if(phase==='initial'){await pausePhase(page,phase);await page.getByRole('button',{name:'Deal',exact:true}).click();}
  else{await deal(page);await pausePhase(page,phase);await page.getByRole('button',{name:phase==='split'?'Split':['reveal','draw','settlement'].includes(phase)?'Stand':phase,exact:true}).click();}
  const selector=phase==='initial'?'[data-initial-deal-flight]':phase==='split'?'[data-split-flight]':phase==='reveal'?'[data-dealer-reveal]':phase==='draw'?'[data-action-card-flight][data-action-reason="DEALER"]':phase==='settlement'?'[data-wager-flight][data-wager-stage="SETTLE_RESULT"][data-wager-seat="4"]':'[data-action-card-flight]';
  await expect(page.locator(selector)).toHaveCount(1);const dealer=await page.locator('.dealer-zone').getAttribute('data-dealer-character');
  await page.getByRole('button',{name:'Skip animations',exact:true}).click();await settled(page);
  await expect(page.locator('.dealer-zone')).toHaveAttribute('data-dealer-character',dealer!);await expect(page.locator('[data-deal-visible="false"]')).toHaveCount(0);
  if(phase==='Hit'||phase==='Double') await expect(page.locator('#player-hand [data-card-slot]')).toHaveCount(3);
  if(phase==='split') await expect(page.locator('.hud-hand')).toHaveCount(2);
  if(phase==='draw') await expect(page.locator('.dealer-total')).toHaveText('Total: 17');
});
test('[T10-B05] session preference flushes native Hit, uses a 44px keyboard target and persists across round/table',async({page})=>{
  await open(page,'player-loss');await deal(page);await pausePhase(page,'Hit');await page.getByRole('button',{name:'Hit',exact:true}).click();await expect(page.locator('[data-action-card-flight]')).toHaveCount(1);
  const before=await page.getByRole('region',{name:'Your credits',exact:true}).locator('dd').allTextContents();const audit=await page.locator('.audit-list').textContent();
  const checkbox=page.getByLabel('Reduce motion',{exact:true});await checkbox.focus();await page.keyboard.press('Space');await expect(checkbox).toBeChecked();await settled(page);
  await expect(page.locator('.game-scene')).toHaveAttribute('data-presentation-mode','REDUCED_MOTION');expect(await page.getByRole('region',{name:'Your credits',exact:true}).locator('dd').allTextContents()).toEqual(before);
  expect(await page.locator('.audit-list').textContent()).toBe(audit);expect(await checkbox.locator('..').evaluate(element=>element.getBoundingClientRect().height)).toBeGreaterThanOrEqual(44);
  await finish(page);await page.getByRole('button',{name:'Deal Again',exact:true}).click();await settled(page);await expect(checkbox).toBeChecked();
  await page.getByRole('button',{name:'New table · reset to 1000 credits',exact:true}).click();await settled(page);await expect(checkbox).toBeChecked();await checkbox.uncheck();await expect(page.locator('.game-scene')).toHaveAttribute('data-presentation-mode','FULL_MOTION');
});
test('[T10-B06] actual media preference mid-Double clears all native controls and cannot be overridden',async({page})=>{
  await open(page,'player-loss');await deal(page);await pausePhase(page,'Double');await page.getByRole('button',{name:'Double',exact:true}).click();await expect(page.locator('[data-action-card-flight]')).toHaveCount(1);
  await page.emulateMedia({reducedMotion:'reduce'});await settled(page);await expect(page.getByLabel('Reduce motion',{exact:true})).toBeChecked();await expect(page.getByLabel('Reduce motion',{exact:true})).toBeDisabled();
  await expect(page.locator('#player-hand [data-card-slot]')).toHaveCount(3);await expect(page.getByRole('region',{name:'Your credits',exact:true}).locator('dd')).toHaveText(['800','0','0']);
});
test('[T10-B07] synthetic visibility suspension handles subsequent accepted Stand before resume without a stale flip/payout',async({page})=>{
  await open(page,'player-loss');await deal(page);await pausePhase(page,'Hit');await page.getByRole('button',{name:'Hit',exact:true}).click();await expect(page.locator('[data-action-card-flight]')).toHaveCount(1);
  await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));});await settled(page);
  await page.getByRole('button',{name:'Stand',exact:true}).click();await settled(page);await expect(page.locator('[data-card-slot="dealer:1"]')).toHaveAttribute('aria-label','9 of diamonds');
  await page.evaluate(()=>{delete (document as unknown as {hidden?:boolean}).hidden;document.dispatchEvent(new Event('visibilitychange'));});await settled(page);
  await expect(page.getByRole('region',{name:'Your credits',exact:true}).locator('dd')).toHaveText(['900','0','0']);
});
test('[T10-B08] real secondary App unmount cancels native transfer; later accepted commands create no ghost DOM',async({page})=>{
  await open(page,'player-loss');await settled(page);
  const result=await page.evaluate(async()=>{
    const appUrl='/src/ui/App.tsx',fixtureUrl='/tests/browser/fixtures.ts',reactUrl='/node_modules/.vite/deps/react.js',rootUrl='/node_modules/.vite/deps/react-dom_client.js';
    const {App}=await import(appUrl),{createFixtureController}=await import(fixtureUrl),{default:React}=await import(reactUrl),{default:ReactDOM}=await import(rootUrl);
    const c=createFixtureController('player-loss'),host=document.createElement('div');document.body.append(host);const root=ReactDOM.createRoot(host);
    let signal!:()=>void;let acknowledged=new Promise<void>(resolve=>{signal=resolve;});const acknowledge=c.presentation.acknowledge;c.presentation.acknowledge=(revision:number)=>{acknowledge(revision);signal();};
    root.render(React.createElement(App,{controller:c}));await acknowledged;
    acknowledged=new Promise<void>(resolve=>{signal=resolve;});c.dispatch({type:'DEAL',amount:200});await acknowledged;
    const before=JSON.stringify(c.getSnapshot()),active=document.querySelectorAll('[data-wager-flight],[data-initial-deal-flight]').length;
    root.unmount();await Promise.resolve();const unchanged=JSON.stringify(c.getSnapshot())===before,empty=host.childNodes.length===0;
    const accepted=c.dispatch({type:'ACT',action:'HIT',handId:'round-1/seat-4'});await Promise.resolve();host.remove();
    return{active,unchanged,empty,accepted,overlays:document.querySelectorAll('[data-wager-flight],[data-initial-deal-flight],[data-action-card-flight],[data-split-flight],[data-dealer-reveal]').length};
  });expect(result.active).toBeGreaterThan(0);expect(result).toMatchObject({unchanged:true,empty:true,accepted:true,overlays:0});
});
