const fs=require('node:fs'),path=require('node:path');
const [task,phase]=process.argv.slice(2),dir='docs/'+task+'_EVIDENCE',r=JSON.parse(fs.readFileSync(dir+'/'+phase+'.json','utf8'));
fs.mkdirSync(dir+'/screenshots',{recursive:true});const images=[];
for(const f of r.testScopedOutputs){if(!f.path.endsWith('.png'))continue;const name=path.basename(f.path);if(/^(setup|table|active|desktop|tablet|mobile|complete|edge|text)-/.test(name)){fs.copyFileSync(dir+'/'+f.retainedAt,dir+'/screenshots/'+name);images.push({name,source:f.path,sha256:f.sha256});}}
fs.writeFileSync(dir+'/screenshots/index.json',JSON.stringify({phase,images},null,2)+'\n');console.log(images.length);
