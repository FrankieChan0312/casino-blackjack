const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const [task,message,mode='implementation']=process.argv.slice(2),dir='docs/'+task+'_EVIDENCE';
const stamp=()=>cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-Date -Format "yyyy-MM-dd HH:mm:ss K"'],{encoding:'utf8'}).trim();
const git=(...args)=>cp.execFileSync('git',args,{encoding:'utf8',maxBuffer:32*1024*1024,stdio:['ignore','pipe','pipe']}).trim();
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
if(git('branch','--show-current')!=='main'||git('remote','get-url','origin')!=='https://github.com/FrankieChan0312/casino-blackjack.git')throw Error('Unauthorized target');
for(const f of JSON.parse(fs.readFileSync(dir+'/executed-version.json','utf8')).files)if(hash(fs.readFileSync(f.path))!==f.sha256)throw Error('Executed-version drift: '+f.path);
const scope=task==='M10A_T10'?['README.md','docs/STATE.md','docs/PLAN.md','docs/DEVELOPMENT_LOG.md','docs/LAB_MANUAL.md','docs/M10A_T07.md','docs/M10A_T08.md','docs/M10A_T09.md','docs/M10A_T10.md','docs/M10_OVERNIGHT2_AUTHORIZATION.md','docs/M10_OVERNIGHT2_HANDOFF.md']:JSON.parse(fs.readFileSync(dir+'/scope.json','utf8')).allowed.concat(['docs/'+task+'.md','docs/M10_OVERNIGHT2_HANDOFF.md']);
const records=fs.existsSync(dir+'/raw-log-archives.json')?JSON.parse(fs.readFileSync(dir+'/raw-log-archives.json','utf8')):{logs:[]};
for(const name of fs.readdirSync(dir)){if(!name.endsWith('.log'))continue;const p=dir+'/'+name,raw=fs.readFileSync(p),packed=zlib.gzipSync(raw);fs.writeFileSync(p+'.gz',packed);if(hash(zlib.gunzipSync(packed))!==hash(raw))throw Error('Lossless log mismatch');records.logs.push({path:name+'.gz',originalSha256:hash(raw),compressedSha256:hash(packed),bytes:raw.length});fs.unlinkSync(p);}
records.timestamp=stamp();fs.writeFileSync(dir+'/raw-log-archives.json',JSON.stringify(records,null,2)+'\n');
const changed=cp.execFileSync('git',['status','--porcelain','-uall'],{encoding:'utf8'}).trimEnd().split('\n').filter(Boolean).map(s=>s.slice(3).replace(/^"|"$/g,''));for(const p of changed)if(!scope.includes(p)&&!p.startsWith(dir+'/'))throw Error('Unknown work: '+p);
git('add','--',...scope.filter(p=>fs.existsSync(p)),dir);
const diff=git('diff','--cached','--stat');fs.writeFileSync('.git/batch2-'+task+'-'+mode+'-stat.txt',diff+'\n');
const check=cp.spawnSync('git',['diff','--cached','--check'],{encoding:'utf8'});fs.writeFileSync('.git/batch2-'+task+'-'+mode+'-whitespace.txt',check.stdout+check.stderr);if(check.status!==0)throw Error('Staged whitespace check failed: '+check.stdout+check.stderr);
const start=stamp();const commit=cp.spawnSync('git',['commit','-m',message],{encoding:'utf8',maxBuffer:32*1024*1024});fs.writeFileSync('.git/batch2-'+task+'-'+mode+'-commit.txt',commit.stdout+commit.stderr);if(commit.status!==0)throw Error('Commit failed');
const head=git('rev-parse','HEAD'),push=cp.spawnSync('git',['push','origin','main'],{encoding:'utf8'});fs.writeFileSync('.git/batch2-'+task+'-'+mode+'-push.txt',push.stdout+push.stderr);if(push.status!==0)throw Error('Push failed');
git('fetch','origin','main');const remote=git('ls-remote','origin','refs/heads/main').split(/\s/)[0],parity=git('rev-list','--left-right','--count','HEAD...origin/main');if(remote!==head||git('rev-parse','origin/main')!==head||parity!=='0\t0'||git('status','--porcelain','-uall'))throw Error('Post-publication parity/clean gate failed');
const r={start,end:stamp(),task,mode,status:'PASS',exitCode:0,branch:'main',head,remote,ahead:0,behind:0,workingTree:'CLEAN',untracked:0,commitExit:commit.status,pushExit:push.status};fs.writeFileSync('.git/batch2-'+task+'-'+mode+'-publication.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify(r));
